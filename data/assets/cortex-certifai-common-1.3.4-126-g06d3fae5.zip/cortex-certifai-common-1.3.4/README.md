# CERTIFAI Common
**Counterfactual Explanations for Robustness, Transparency, Interpretability, and Fairness of Artificial Intelligence models**

This package contains common utilities and definitions used across Certifai packages, such as logging and configuration
utils, common exception types, etc.

This repository is using [pkgutil-style namespace packges](https://packaging.python.org/guides/packaging-namespace-packages/#pkgutil-style-namespace-packages),
under the `certifai` namespace. Example usage would be:

```
from certifai.common.utils import get_logger
from certifai.common.errors import CertifaiException

log = get_logger()

...
```

## Development

You can rely on the provided `Makefile` during development. For descriptions of make targets use: `make help`.

### Installation

`make install`

This will build the package and install `certifai-common` in the `c12e-certifai` conda environment. If you have already
built the package (using `make setup_build_space && make build`), you can instead run `make install_only`.

### Tests

`make test` # uses: tox and pytest
