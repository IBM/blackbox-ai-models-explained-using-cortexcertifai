import os
try:
    from adlfs import AzureBlobFileSystem
except ModuleNotFoundError:
    raise ModuleNotFoundError(
        'To use the certifai.common.file.azure module, install cortex-certifai-common with the "azure" '
        'extra flag.\nFor example, "pip install cortex-certifai-common[azure]"'
    )

from azure.storage.blob import BlobPrefix
from azure.common import AzureMissingResourceHttpError
from typing import Iterable, NamedTuple

from certifai.common.file.interface import *
from certifai.common.file import azure_blob_filesystem_type
from certifai.common.utils.utils import prepend_element_to_generator
from certifai.common.utils.file_utils import extract_path_from_fullpath, protocol_from_path


__all__ = [
    'AzureData',
    'AzurePath',
    'azure_blob_filesystem_type'
]


def ls_patched(
    self,
    path: str,
    detail: bool = False,
    invalidate_cache: bool = True,
    delimiter: str = "/",
    **kwargs,
):
    """
    This is a PATCHED version of the `adlfs.AzureBlobFileSystem.ls` method.

    The original version contains a bug that assumes that the root directory (container) name is the first item of the list of results returned
    by `BlockBlobService.list_blobs` (https://github.com/dask/adlfs/blob/master/adlfs/core.py#L368-L373).

    The items returned are actually a list of all file and subdirectory (subcontainer) names in the directory (container).
    """
    try:
        blobs = self.blob_fs.list_blobs(
            container_name=self.container_name, prefix=path, delimiter=delimiter
        )
    except AzureMissingResourceHttpError:
        raise FileNotFoundError('Directory "abfs://'
                                f'{self.container_name}"'
                                ' does not exist') from None
    blobs_ = list(blobs)
    if len(blobs_) == 1 and isinstance(blobs_[0], BlobPrefix):
        path = blobs_[0].name
        return self.ls(path, detail=detail, delimiter=delimiter)

    if detail is False:
        pathlist = [blob.name for blob in blobs]
        return pathlist
    else:
        pathlist = []
        for blob in blobs:
            data = {}
            data["name"] = blob.name
            data["container_name"] = self.container_name
            try:
                data["size"] = blob.properties.content_length
                data["last_modified"] = blob.properties.last_modified
                if blob.properties.content_settings.content_type is not None:
                    data["type"] = "file"
                else:
                    data["type"] = "directory"
            except AttributeError:
                if path == blob.name.rstrip("/"):
                    self.ls(blob.name, detail=detail, delimiter=None)
                elif isinstance(blob, BlobPrefix):
                    data["type"] = "directory"
                    data["size"] = 0
                    data["last_modified"] = None
                else:
                    raise AttributeError(
                        f"AzureBlobFileSystem.ls() method unable to assign attributes for {blob}!"
                    )
            pathlist.append(data)
        return pathlist


class AzureData:
    def __init__(self, account_name: str, path: str = None, container_name: str = None,
                 directory_delimiter: str = '/', **kwargs) -> None:
        # monkeypatch `ls`. See note above for why.
        AzureBlobFileSystem.ls = ls_patched
        self.__delimiter = directory_delimiter
        if container_name:
            container_name = container_name.strip(self.__delimiter)
        else:
            # get container_name from path; assume it is the first component of the path
            _path = path.strip(self.__delimiter)
            container_name = _path[:_path.index(self.__delimiter)] if self.__delimiter in _path else _path
        self.container_name = container_name
        self.__fs = AzureBlobFileSystem(account_name=account_name, container_name=container_name, **kwargs)

    def __convert_path(self, path):
        """
        Converts given path to a format consumable by AzureBlobFileSystem methods.

        Strip leading and trailing delimiters from the given path, as well as the container name
        if it exists at the front of the path string.
        """
        _path = path.lstrip(self.__delimiter)
        return _path[len(self.container_name) + 1:] if _path.startswith(self.container_name) else _path

    def __build_path(self, path):
        """
        return path with delimiter + container_name prepended to it
        """
        return self.__delimiter + self.container_name + self.__delimiter + path.lstrip(self.__delimiter)

    def read_blob(self, path: FilePath):
        return self.__fs._open(self.__convert_path(path))

    def write_blob(self, path: str):
        return self.__fs._open(self.__convert_path(path), mode='wb')

    def blob_size(self, path: FilePath) -> SizeBytes:
        return SizeBytes(self.__fs.info(self.__convert_path(path))['size'])

    def last_modified(self, path: FilePath) -> LastModified:
        """
        Return the last modified or updated property of the specified file, as a timezone aware datetime
        """
        return LastModified(self.__fs.info(self.__convert_path(path))['last_modified'])

    def list_blobs(self, directory: DirectoryPath) -> Iterable[FilePath]:
        """
        List all blobs under the current directory.

        A note about `AzureBlobFileSystem.ls` output:
        - non-direct descendant files with empty directories in their path will be included in `ls` output.
        - For nested directories (with delimiters in their path), the following applies for `ls` output:
            - paths returned for files will be relative to top-level (root) directory and not the passed path.
        """
        _directory = self.__convert_path(directory)
        if len(_directory) > 0 and _directory[-1] != self.__delimiter:
            _directory = _directory + self.__delimiter


        def file_list_generator():
            if len(self.__fs.ls(_directory, detail=True)) != 0:
                ls_output = (f for f in self.__fs.ls(_directory, detail=True))
                found_one = False
                for obj in ls_output:
                    found_one = True
                    obj_name = obj.get('name')

                    # If we are not in top-level, ignore any file with a delimiter in its name
                    # as it is a nested file with empty directories in its path.
                    if obj.get('type') == 'file' and obj_name.find(self.__delimiter, len(_directory)) == -1:
                        yield self.__build_path(obj_name)

                if not found_one:
                    raise FileNotFoundError('Directory "abfs://'
                                            f'{directory}"'
                                            ' does not exist')

        gen = file_list_generator()
        try:
            first = next(gen)
            return prepend_element_to_generator(first, gen)
        except StopIteration:
            return iter([])

    def list_directories(self, directory: DirectoryPath) -> Iterable [FilePath]:
        """
        List all direct sub-directories under a directory path.

        A note about `AzureBlobFileSystem.ls` output:
        - non-direct descendant files with empty directories in their path will be included in `ls` output.
        - For nested directories (with delimiters in their path), the following applies for `ls` output:
            - paths returned for files will be relative to top-level (root) directory and not the passed path.
        """
        _directory = self.__convert_path(directory)
        if len(_directory) > 0 and _directory[-1] != self.__delimiter:
            _directory = _directory + self.__delimiter


        def directory_lister_gen():
            if len(self.__fs.ls(_directory, detail=True)) != 0:
                ls_output = (f['name'] for f in self.__fs.ls(_directory, detail=True))
                directories = set([])
                for name in ls_output:
                    delimiter_idx = name.find(self.__delimiter, len(_directory))
                    if delimiter_idx == len(name) - 1:
                        # it is a directory
                        if name not in directories:
                            directories.add(name)
                            yield self.__build_path(name)
                    elif delimiter_idx >= 0 and delimiter_idx < len(name) - 1:
                        # it is a file with empty directories in its path;
                        # extract the directory name from the file's path.
                        directory_name = name[:delimiter_idx + 1]
                        if directory_name not in directories:
                            directories.add(directory_name)
                            yield self.__build_path(directory_name)


        gen = directory_lister_gen()
        try:
            first = next(gen)   # Execute once just to make sure the current directory exists
            return prepend_element_to_generator(first, gen)
        except StopIteration:
            return iter([])

    def join(self,
             parent: DirectoryPath,
             child: FSEntity) -> FSEntity:
        if child.startswith(self.__delimiter):
            return child
        elif child.startswith(azure_blob_filesystem_type + ':'):
            return self.__delimiter + extract_path_from_fullpath(azure_blob_filesystem_type, child).lstrip(self.__delimiter)
        else:
            protocol = protocol_from_path(child)
            if protocol and protocol != azure_blob_filesystem_type:
                raise ValueError(f'Cannot join path of type \'{protocol}\' to type \'{azure_blob_filesystem_type}\'')
            return parent.rstrip(self.__delimiter) + self.__delimiter + child     # type: ignore

    def isfile(self, path: FSEntity):
        return self.__fs.isfile(self.__convert_path(path))

    def delete(self, path: FSEntity):
        raise NotImplementedError

    def get_normalized_path(self, name: FSEntity):
        """
        Get normalized name of a file or directory
        :param name: Path to normalize
        :return: Normalized name
        """
        return name.replace(self.__delimiter, '/')


class AzurePath(NamedTuple):
    """AzurePath(container: str, key: str)

    A unique identifier for an object stored in Azure.
    """
    container: str
    """The name of the Azure Blob Storage container that contains the object."""

    key: str
    """The key of the Azure blob."""

    def as_uri(self) -> str:
        """Return this Azure path as a URI of the form "abfs://[container]/[key]"."""
        return f'abfs://{self.container}/{self.key}'

    @staticmethod
    def parse(path: str, delimiter: str = '/') -> 'AzurePath':
        """Attempt to parse an :obj:`AzurePath` from `path`.

        Args:
            path: A string of the form "{abfs:/}/[container]{/key}", where "{}"
                indicates an optional value and "[]" indicates a required value.
            delimiter: The character to use to delimit "directories".

        Raises:
            ValueError: `path` is not a valid Azure path or `delimiter` is not
                one character long.
        """
        if not path.startswith('abfs://') and not path.startswith(delimiter):
            raise ValueError(
                f'Azure path "{path}" is invalid. '
                f'Paths must either begin with "{delimiter}" or "abfs://"'
            )
        if path.startswith(delimiter) and path[1:].startswith(delimiter):
            raise ValueError(
                f'Azure path "{path}" is invalid. '
                'Paths may not begin with two subsequent delimiters'
            )

        components = (
            path[7:].split('/') if path.startswith('abfs://') else
            path[1:].split('/')
        )

        return AzurePath(
            container = components[0],
            key    = '/'.join(components[1:])
        )


def azure_blob_filesystem(path: str):
    data = AzureData(path=path, **_read_abfs_service_config())
    return FileSystem(azure_blob_filesystem_type,
                      data.read_blob,
                      data.write_blob,
                      data.blob_size,
                      data.last_modified,
                      data.list_blobs,
                      data.list_directories,
                      data.join,
                      data.isfile,
                      data.delete,
                      data.get_normalized_path)


AZURE_ACCOUNT_NAME = 'AZURE_ACCOUNT_NAME'
AZURE_ACCOUNT_KEY = 'AZURE_ACCOUNT_KEY'
AZURE_CONNECTION_STRING = 'AZURE_CONNECTION_STRING'
AZURE_SAS_TOKEN = 'AZURE_SAS_TOKEN'
AZURE_CUSTOM_DOMAIN = 'AZURE_CUSTOM_DOMAIN'
AZURE_ENDPOINT = 'AZURE_ENDPOINT'


def _read_abfs_service_config():
    """Check for endpoint and credential overrides in the environment"""
    result = {}
    if os.environ.get(AZURE_ACCOUNT_NAME) is not None:
        result['account_name'] = os.environ.get(AZURE_ACCOUNT_NAME)
    if os.environ.get(AZURE_ACCOUNT_KEY) is not None:
        result['account_key'] = os.environ.get(AZURE_ACCOUNT_KEY)
    if os.environ.get(AZURE_CONNECTION_STRING) is not None:
        result['connection_string'] = os.environ.get(AZURE_CONNECTION_STRING)
    if os.environ.get(AZURE_SAS_TOKEN) is not None:
        result['sas_token'] = os.environ.get(AZURE_SAS_TOKEN)
    if os.environ.get(AZURE_CUSTOM_DOMAIN) is not None:
        result['custom_domain'] = os.environ.get(AZURE_CUSTOM_DOMAIN)
    if os.environ.get(AZURE_ENDPOINT) is not None:
        result['endpoint_suffix'] = os.environ.get(AZURE_ENDPOINT)

    return result


def abfs_entity_locater(path: str) -> FSLocater:
    """
    :path str: a path in the format of `container_name/directory`
               where directory is optional.
               We assume that this path does not have a protocol prefix.
    """
    return FSLocater(azure_blob_filesystem(path), path)    # type: ignore
