"""This module defines abstractions for interacting with file-like objects.

Using the interfaces defined in this module, it is possible to write code that
is more easily portable between a local filesystem and some other, possibly
network-based mechanism for accessing data.

For example, rather than using Python's built-in `open` function, code that
requires access to persistent data can declare a dependency on a
:data:`FileReader` instance::

    >>> import pandas as pd
    >>> def my_code(input_file: str, reader: certifai.common.file.interface.FileReader):
    ...     with reader(input_file) as fin:
    ...         df = pd.read_csv(fin)
    ...         # and so on...

When running `my_code` locally, a filesystem-based implementation of `reader`
can be provided::

    >>> from certifai.common.file import local
    >>> my_code('/path/to/my-data-set.csv', local.read_file)

When running in Amazon EC2, for example, an S3-based implementation of the
reader can be used::

    >>> from certifai.common.file.s3 import S3Data
    >>> my_code('/my-bucket/my-data-set.csv', S3Data().read_object)

Attributes:
    DirectoryPath: A string that encodes the path to a directory. Used during
        type-checking to ensure that file paths are not used where directory
        paths are expected, and vice versa.

        Example::

            >>> path = DirectoryPath('/usr/lib')

    FilePath: A string that encodes the path to a file. Used during
        type-checking to ensure that directory paths are not used where file
        paths are expected, and vice versa.

        Example::

            >>> path = FilePath('/home/freddie/.bashrc')

    SizeBytes: An integer that encodes a number of bytes. Used in function
        signatures to indicate the meaning of integer parameters.

        Example::

            >>> def get_size(of_file: str) -> SizeBytes:
            ...    # ...
            ...
            >>> def create_buffer(of_size: SizeBytes) -> bytes:
            ...    # ...

    LastModified: A timezone aware datetime of the last modified or updated property of a file.  Used
        to sort and make decisions against.

        Example::

            >>> def get_last_modified(of_file: FilePath) -> LastModified:
            ...    # ...
            ...
            >>> print (get_last_modified(FilePath("/path/to/file.txt")) < datetime.now(tz=timezone.utc))
            True

    FileLister (Callable[[DirectoryPath], Iterable[FilePath]]): A callable that
        returns an iterable of files available within a directory.

        Note that the file paths returned by a :obj:`FileLister` implementation
        should be unique with respect to the "file system" on which they reside.
        That is, they should be absolute, *not* relative to the specified
        directory path.

        Example::

            >>> def print_files(explorer: FileLister, directory: DirectoryPath):
            ...     for file_name in explorer(directory):
            ...         print(file_name)
            ...
            >>> print_files(local_explorer, DirectoryPath("/path/to/my_dir"))
            /path/to/my_dir/file01.txt
            /path/to/my_dir/file02.txt
            /path/to/my_dir/file03.txt
            etc...

    DirectoryLister (Callable[[DirectoryPath], Iterable[DirectoryPath]]): A
        callable that returns an iterable of subdirectories within a directory.

        Note that the directory paths returned by a :obj:`DirectoryLister`
        implementation should be unique with respect to the "file system" on
        which they reside. That is, they should be absolute, *not* relative to
        the specified directory path.

        Example::

            >>> def print_directories(explorer: DirectoryLister, prefix: DirectoryPath):
            ...     for directory_name in explorer(prefix):
            ...         print(directory_name)
            ...
            >>> print_directories(local_explorer, DirectoryPath("/path/to/my_dir"))
            /path/to/my_dir/my_sub_dir_01/
            /path/to/my_dir/my_sub_dir_02/
            /path/to/my_dir/my_sub_dir_03/
            etc...

    FileReader (Callable[[FilePath], ContextManager[BinaryInput]]): A callable
        that yields a context-managed readable stream-like object.

        `FileReader` implementations should raise :obj:`FileNotFoundError` if
        invoked with an identifier for a non-existent resource. Attempts to
        access resources for which the process does not have adequate
        permissions should result in a :obj:`PermissionError`.

        `FileReader` implementations are used for reading resources as raw byte
        streams. Resources can be read as text streams by wrapping the stream
        provided by the reader in an :obj:`io.TextIOWrapper` instance::

            >>> from io import TextIOWrapper
            >>> def read_as_text(reader: FileReader, file_path: FilePath):
            ...     with reader(file_path) as fin:
            ...         text_reader = TextIOWrapper(fin, encoding = 'utf_8')
            ...         return text_reader.read()

    FileWriter (Callable[[FilePath], ContextManager[BinaryOutput]]): A callable
        that yields a context-managed writable stream-like object.

        `FileWriter` implementations should raise :obj:`FileNotFoundError` if
        invoked with an identifier that includes a a non-existent directory.
        Attempts to access resources for which the process does not have
        adequate permissions should result in a :obj:`PermissionError`.

        If a `FileWriter` is used to obtain a binary stream for a resource that
        already exists, that resource should be deleted and replaced by the data
        written to the new stream.

        `FileWriter` implementations are used for writing raw byte streams. Text
        can be written by wrapping the stream provided by the writer in an
        :obj:`io.TextIOWrapper` instance::

            >>> from io import TextIOWrapper
            >>> def write_as_text(writer: FileWriter, file_path: FilePath):
            ...     with writer(file_path) as fout:
            ...         text_writer = TextIOWrapper(fout, encoding = 'utf_8')
            ...         text_writer.write('Some text')

    FileSizeGetter (Callable[[FilePath], SizeBytes]): Implementations of
        :obj:`FileSizeGetter` should raise :obj:`FileNotFoundError` if the
        specified file does not exist. Attempts to access resources for which
        the process does not have adequate permissions result in a
        :obj:`PermissionError`.

    FileLastModifiedGetter (Callable[[FilePath], LastModified]): Implementations of
        :obj:`FileLastModifiedGetter` should raise :obj:`FileNotFoundError` if the
        specified file does not exist. Attempts to access resources for which
        the process does not have adequate permissions result in a
        :obj:`PermissionError`.
"""
from typing import Callable, Iterable, Union, NewType, ContextManager, NamedTuple
from typing_extensions import Protocol
from io import TextIOWrapper
import os
from datetime import datetime


__all__ = [
    'DirectoryPath',
    'FilePath',
    'FSEntity',
    'SizeBytes',
    'LastModified',
    'BinaryInput',
    'BinaryOutput',
    'FileLister',
    'DirectoryLister',
    'FileReader',
    'FileWriter',
    'FileSizeGetter',
    'FileLastModifiedGetter',
    'TextFileReader',
    'TextFileWriter',
    'FileSystem',
    'FSLocater',
    'text_reader',
    'text_writer'
]


class BinaryInput(Protocol):
    """A "stream-like" object that can be used for reading bytes.

    Note that this class is an instance of :obj:`typing_extensions.Protocol`. As
    such, it is not necessary for an object to have a type that inherits from
    this class in order for that object to type-check as a `BinaryInput`.

    In other words, this class merely defines the "shape" that any object must
    have in order to be a valid `BinaryInput`. The object returned by Python's
    built-in `open` function has this shape, since it has a method called `read`
    whose signature matches :meth:`BinaryInput.read`.
    """

    def read(self, max_bytes: int=-1) -> bytes:
        """Read at most `max_bytes` from a stream.

        Arguments:
            max_bytes: The maximum number of bytes to return.

        Returns:
            A `bytes` instance that contains 0 to `max_bytes` bytes.
        """
        ...

    def readline(self) -> bytes:
        """Read one line from a stream (only really meaningful if the current offset is actually text).

        Returns:
            A `bytes` instance
        """
        ...

    def readable(self) -> bool:
        """Should return True"""
        ...

    def writeable(self) -> bool:
        """Should return False"""
        ...

    def seekable(self) -> bool:
        """Return True iff the stream is seekable"""
        ...

    @property
    def closed(self) -> bool:
        """Return True iff the stream is closed"""
        ...


class BinaryOutput(Protocol):
    """A "stream-like" object that can be used for writing bytes.

    Note that this class is an instance of :obj:`typing_extensions.Protocol`. As
    such, it is not necessary for an object to have a type that inherits from
    this class in order for that object to type-check as a `BinaryOutput`.

    In other words, this class merely defines the "shape" that any object must
    have in order to be a valid `BinaryOutput`. The object returned by Python's
    built-in `open` function has this shape, since it has a method called
    `write` whose signature matches :meth:`BinaryOutput.write`.
    """

    def write(self, s: Union[bytes, bytearray, memoryview]) -> int:
        """Write `s` bytes to a stream.

        Arguments:
            s: The bytes to write to the stream.

        Returns:
            The actual number of bytes written to the stream. May be from 0 to
            the number of bytes in `s`.
        """
        ...

    def readable(self) -> bool:
        """Should return False"""
        ...

    def writeable(self) -> bool:
        """Should return True"""
        ...

    def seekable(self) -> bool:
        """Return True iff the stream is seekable"""
        ...

    @property
    def closed(self) -> bool:
        """Return True iff the stream is closed"""
        ...


DirectoryPath = NewType('DirectoryPath', str)
FilePath      = NewType('FilePath'     , str)
SizeBytes     = NewType('SizeBytes'    , int)
LastModified  = NewType('LastModified' , datetime)

FSEntity = Union[FilePath, DirectoryPath]

FileLister              = Callable[[DirectoryPath], Iterable[FilePath]]
DirectoryLister         = Callable[[DirectoryPath], Iterable[DirectoryPath]]
FileReader              = Callable[[FilePath     ], ContextManager[BinaryInput]]
FileSizeGetter          = Callable[[FilePath     ], SizeBytes]
FileLastModifiedGetter  = Callable[[FilePath     ], LastModified]
FileWriter              = Callable[[FilePath     ], ContextManager[BinaryOutput]]
PathJoiner              = Callable[[DirectoryPath , FSEntity], FSEntity]
IsFile                  = Callable[[FSEntity]     , bool]
FSDelete                = Callable[[FSEntity]     , None]
NameNormalizer          = Callable[[FSEntity]     , FSEntity]

TextFileReader          = Callable[[FilePath     ], ContextManager[TextIOWrapper]]
TextFileWriter          = Callable[[FilePath     ], ContextManager[TextIOWrapper]]


class _ContextWrapper(ContextManager):
    def __init__(self, transform, underlying: ContextManager, on_exit=None):
        self.transform = transform
        self.on_exit = on_exit
        self.underlying = underlying
        self.transformed = None

    def __enter__(self):
        self.transformed = self.transform(self.underlying.__enter__())
        return self.transformed

    def __exit__(self, exc_type, exc_val, exc_tb):
        if self.on_exit is not None:
            self.on_exit(self.transformed)
        return self.underlying.__exit__(exc_type, exc_val, exc_tb)


def text_reader(reader: FileReader, encoding: str='utf-8') -> TextFileReader:
    """Turn a FileReader into a TextFileReader

    :param FileReader reader: reader (binary IO) to wrap
    :param str encoding: Encoding to use (default utf-8)
    :return: reader (text IO)
    :rtype: TextFileReader
    """
    def f(path: FilePath):
        return _ContextWrapper(lambda x: TextIOWrapper(x, encoding=encoding), reader(path))
    return f


def text_writer(writer: FileWriter, encoding: str='utf-8') -> TextFileWriter:
    """Turn a FileWriter into a TextFileWriter

    :param FileWriter writer: reader (binary IO) to wrap
    :param str encoding: Encoding to use (default utf-8)
    :return: writer (text IO)
    :rtype: TextFileWriter
    """
    def f(path: FilePath):
        return _ContextWrapper(lambda x: TextIOWrapper(x, encoding=encoding, write_through=True), writer(path))

    return f


def get_basename(path: FSEntity):
    """
    Returns the final component of a pathname
    :param path: path
    :return: Component name
    """
    return os.path.basename(path)


class FileSystem(NamedTuple):
    """Encapsulated abstract filesystem interface

    :param FileReader reader: opener for read of binary streams
    :param FileWriter writer: opener for write of binary streams
    :param FileSizeGetter sizer: return the size of a file
    :param FileLastModifiedGetter last_modified_getter: return the last modified datetime of a file
    :param FileLister file_lister: enumerator of files in a directory
    :param DirectoryLister directory_lister: enumerator of sub-directories in a directory
    :param PathJoiner join: join leaf to stem names
    :param IsFile isfile: returns True if the specified path is a file (throws if it does not exist)
    :param FSDelete delete: delete a file or directory (implies recursive for directories)

    Note - deletion may not be supported on all storage systems and attempts to delete in
      such cases will raise NotImplementedError
    """
    type_name:              str
    reader:                 FileReader
    writer:                 FileWriter
    sizer:                  FileSizeGetter
    last_modified_getter:   FileLastModifiedGetter
    file_lister:            FileLister
    directory_lister:       DirectoryLister
    join:                   PathJoiner
    isfile:                 IsFile
    delete:                 FSDelete
    normalized_name:        NameNormalizer


class FSLocater(NamedTuple):
    """Fully determined file locater (name + filesystem the name is relative to)

    :param FileSystem filesystem: What filesystem the file is located within
    :param FSEntity name: Full path of the file
    """
    filesystem: FileSystem
    name:       FSEntity

    def reader(self) -> ContextManager[BinaryInput]:
        return self.filesystem.reader(self.name)    # type: ignore

    def writer(self) -> ContextManager[BinaryOutput]:
        return self.filesystem.writer(self.name)    # type: ignore

    def text_reader(self, encoding: str='utf-8') -> ContextManager[TextIOWrapper]:
        return text_reader(self.filesystem.reader, encoding=encoding)(self.name)    # type: ignore

    def text_writer(self, encoding: str='utf-8') -> ContextManager[TextIOWrapper]:
        return text_writer(self.filesystem.writer, encoding=encoding)(self.name)    # type: ignore

    def size(self) -> SizeBytes:
        return self.filesystem.sizer(self.name)    # type: ignore

    def last_modified(self) -> LastModified:
        return self.filesystem.last_modified_getter(self.name)    # type: ignore

    def file_lister(self) -> Iterable[FilePath]:
        """ Returns an iterable with filenames (not directories) within path of the FSLocater (direct descendants, one level deep only). """
        return self.filesystem.file_lister(self.name)    # type: ignore

    def directory_lister(self) -> Iterable[DirectoryPath]:
        """ Same as file_lister but includes also directory names. """
        return self.filesystem.directory_lister(self.name)    # type: ignore

    def delete(self):
        """ NOTE: Not implemented for all FS (possibly only S3 and local). """
        return self.filesystem.delete(self.name)

    def isfile(self) -> bool:
        return self.filesystem.isfile(self.name)    # type: ignore

    def join(self, child: FSEntity) -> 'FSLocater':
        return FSLocater(self.filesystem, self.filesystem.join(self.name, child))  # type: ignore

    def get_normalized_name(self) -> str:
        return self.filesystem.normalized_name(self.name)
