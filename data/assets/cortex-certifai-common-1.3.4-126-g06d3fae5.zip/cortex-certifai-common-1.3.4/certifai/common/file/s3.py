"""AWS S3 implementations for the data interfaces defined in
:mod:`certifai.common.file.interface`.

The class :obj:`certifai.common.file.s3.S3Data` defines methods that implement each of the
interfaces defined in :mod:`certifai.common.file.interface`.

For example, an S3 implementation of :data:`certifai.common.file.interface.FileReader` can
be provided by constructing an `S3Data` object and passing its
`read_object` method, which conforms to the `FileReader` interface, as follows::

    >>> def needs_reader(reader: certifai.common.file.interface.FileReader) -> None:
    ...     # read some data
    ...
    >>> s3 = S3Data()
    >>> needs_reader(s3.read_object)

TODO - implement an `s3_filesystem` instance of :class:`FileSystem`
"""
import json
import types
import time
import os
from contextlib import contextmanager
from typing import Iterable, Optional, List, Dict, Any, NamedTuple, Callable, \
    Union, cast

from toolz import get_in, partial

try:
    import boto3
    from botocore.exceptions import ClientError
    from botocore.response import StreamingBody
    import warnings

    # Suppress InsecureRequestWarning from urllib3 (we will warn once ourselves if cert verification is disabled)
    import urllib3
    urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

    # S3 StreamingBody does not fully implement IOBase and in particular the `closed`
    # property is required so we add it at the class level since it is generic and this
    # is the easiest way to achieve this
    setattr(StreamingBody, 'closed', property(fget=lambda s: s._raw_stream.closed))
except ModuleNotFoundError:
    raise ModuleNotFoundError(
        'To use the certifai.common.file.s3 module, install cortex-certifai-common with the "s3" '
        'extra flag.\nFor example, "pip install cortex-certifai-common[s3]"'
    )

from certifai.common.file.interface import *
from certifai.common.file.streaming import StreamView
from certifai.common.file import s3_filesystem_type
from certifai.common.utils.utils import prepend_element_to_generator, empty_generator
from certifai.common.utils.file_utils import extract_path_from_fullpath, protocol_from_path


__all__ = [
    'S3Data',
    'S3Path',
    'UnexpectedS3Error',
    '_BufferedS3Writer',
    's3_filesystem_type',
    's3_filesystem',
    's3_entity_locater'
]


MINIMUM_MP_UPLOAD_SIZE = 5242880


class _S3BinaryInput(BinaryInput):
    def __init__(self, stream: StreamingBody):
        """Wrapper to provide more control over auto-lose behavior, needed because
        Ceph auto-closes streams on reading to EOF
        """
        self.underlying = stream
        self._closed = False

    def __iter__(self):
        return self

    def __next__(self):
        result = self.read(1)
        if len(result) == 0:
            raise StopIteration
        return result

    def read(self, *args) -> bytes:
        if (not self._closed) and self.underlying.closed:
            return bytes()
        return self.underlying.read(*args)

    def readline(self) -> bytes:
        if (not self._closed) and self.underlying.closed:
            return bytes()
        return self.underlying.readline()

    def readable(self) -> bool:
        return True

    def writeable(self) -> bool:
        return False

    # This one is here because there seems to be inconsistent naming between ecosystems and this is a safety net
    def writable(self) -> bool:
        return False

    def seekable(self) -> bool:
        return False

    @property
    def closed(self) -> bool:
        return self._closed

    def close(self):
        if not self.underlying.closed:
            self.underlying.close()
            self._closed = True


class S3Data:
    """Implements interfaces defined in :mod:`certifai.common.file.interface` for AWS S3.

    Arguments:
        session: Optional :obj:`boto3.Session` to use to interact with S3.
            If not specified, the default session returned by the `boto3`
            library is used.
        directory_delimiter: The character to use to delimit "directories".
            Since S3 does not have a built-in notion of a "directory", it is
            up to developers to define a character that delimits segments in
            some hierarchical structure. Usually, the familiar forward slash
            is used.
    """

    def __init__(self,
                 session: Optional[boto3.Session] = None,
                 endpoint_url: Optional[str] = None,
                 access_key: Optional[str] = None,
                 token: Optional[str] = None,
                 verify_cert: Optional[bool] = None,
                 directory_delimiter: str = '/') -> None:
        """|  (session: Optional[boto3.Session] = None,
           |   directory_delimiter: str = '/') -> None
        """
        self.__session   = session or boto3
        session_based_config = (endpoint_url is None) and (access_key is None) and (token is None)
        if (not session_based_config) and (session is not None):
            raise ValueError("Illegal configuration parameters - may not combine 'session' with other options")

        if not session_based_config:
            config_args = {}
            if endpoint_url is not None:
                config_args['endpoint_url'] = endpoint_url
            if access_key is not None:
                config_args['aws_access_key_id'] = access_key
            if token is not None:
                config_args['aws_secret_access_key'] = token
            if verify_cert is not None:
                config_args['verify'] = verify_cert
                if not verify_cert:
                    warnings.warn("Running with SSL certification verification disabled")
            self.__s3_client = boto3.client('s3',
                                            **config_args)
        else:
            self.__s3_client = self.__session.client('s3')
        self.__delimiter = directory_delimiter

    def _clean_dir_path(self, directory: DirectoryPath) -> 'S3Path':
        """
        Cleans directory path
        :param directory: Path of the directory
        :return: S3Path
        """
        internal_dir = str(directory).lstrip(self.__delimiter)
        if not internal_dir.endswith(self.__delimiter):
            internal_dir += self.__delimiter

        return S3Path.parse(self.__delimiter + internal_dir, self.__delimiter)

    @contextmanager
    def read_object(self, path: FilePath):
        """read_object(path: FilePath) -> ContextManager[BinaryInput]

        Provide a context-managed binary stream for reading data from an object
        stored in S3.

        Arguments:
            path: An S3 URI or path-like string. See :func:`S3Path.parse` for
                valid path strings.

        Raises:
            ValueError: `path` is not a valid S3 path.
            FileNotFoundError: `path` does not exist.
            PermissionError: The system denied the process permission to open
                `path` for reading.

        Example::

            >>> def print_object(s3: S3Data):
            ...     path = FilePath('s3://my-bucket/my-key')
            ...     # path could also be FilePath('/my-bucket/my-key')
            ...     with s3.read_object(path) as fin:
            ...         print(fin.read())
            ...
            b'Some contents'
        """
        s3_path = S3Path.parse(path, self.__delimiter)
        try:
            object_stream = _S3BinaryInput(self.__s3_client.get_object(
                Bucket = s3_path.bucket,
                Key    = s3_path.key
            )['Body'])

        except ClientError as e:
            raise _s3_error(e, s3_path, 'Object') from None

        yield object_stream

        if not object_stream.closed:
            object_stream.close()

    def object_size(self, path: FilePath) -> SizeBytes:
        """object_size(path: FilePath) -> SizeBytes

        Get the size of an S3 object in bytes.

        Arguments:
            path: An S3 URI or path-like string. See :func:`S3Path.parse` for
                valid path strings.

        Raises:
            ValueError: `path` is not a valid S3 path.
            FileNotFoundError: `path` does not exist.
            PermissionError: The system denied the process permission to access
                `path`.

        Example::

            >>> def print_object_size(s3: S3Data):
            ...     path = FilePath('s3://my-bucket/my-key')
            ...     # path could also be FilePath('/my-bucket/my-key')
            ...     print(s3.object_size(path))
            ...
            13
        """
        s3_path = S3Path.parse(path, self.__delimiter)
        try:
            response = self.__s3_client.head_object(
                Bucket = s3_path.bucket,
                Key    = s3_path.key
            )
            return response['ContentLength']
        except ClientError as e:
            raise _s3_error(e, s3_path, 'Object')

    def last_modified(self, path: FilePath) -> LastModified:
        """last_modified(file_path: FilePath) -> LastModified

        Return the last modified or updated property of the specified file, as a timezone aware datetime

        Args:
            path: An S3 URI or path-like string. See :func:`S3Path.parse` for
                valid path strings.

        Raises:
            ValueError: `path` is not a valid S3 path.
            FileNotFoundError: `path` does not exist.
            PermissionError: The system denied the process permission to access
                `path`.

        Example::

            >>> def print_last_modified(s3: S3Data):
            ...     path = FilePath('s3://my-bucket/my-key')
            ...     # path could also be FilePath('/my-bucket/my-key')
            ...     print(s3.last_modified(path))
            ...
            2020-06-11 02:48:14+00:00
        """
        s3_path = S3Path.parse(path, self.__delimiter)
        try:
            response = self.__s3_client.head_object(
                Bucket = s3_path.bucket,
                Key    = s3_path.key
            )
            return LastModified(response['LastModified'])
        except ClientError as e:
            raise _s3_error(e, s3_path, 'Object')

    def list_objects(self, directory: DirectoryPath) -> Iterable[FilePath]:
        """list_objects(directory: DirectoryPath) -> Iterable[FilePath]

        Return an iterable of files contained in the specified directory.

        Args:
            directory: The path of the directory to list files within.

        Returns:
            An iterable of the absolute paths of all files contained in
            `directory`.

        Raises:
            FileNotFoundError: `directory` does not exist.
            PermissionError: The system denied the process permission to access
                `directory`.

        Example::

            >>> s3 = S3Data()
            >>> path = DirectoryPath('s3://my-bucket/my-directory')
            >>> for object_key in s3.list_objects(path):
            ...     print(object_key)
            ...
            s3://my-bucket/my-directory/my-object-1
            s3://my-bucket/my-directory/my-object-2
            s3://my-bucket/my-directory/my-object-3
        """
        s3_path = self._clean_dir_path(directory)

        def objects_from_page(page):
            if 'Contents' not in page:
                # it's empty, which is valid at a bucket root if the KeyCount is present and 0
                if page.get('KeyCount', 0) == 0:
                    raise FileNotFoundError(
                        'Directory "s3://'
                        f'{s3_path.bucket}/{s3_path.key}"'
                        ' does not exist'
                    )
            else:
                for metadata in page['Contents']:
                    key = metadata['Key']

                    # Exclude object when object is exactly the source directory
                    if key.strip(self.__delimiter) == os.path.basename(directory.strip(self.__delimiter)):
                        continue

                    yield f'/{s3_path.bucket}/{key}'

        def file_lister_gen():
            for o in self._paged_list(
                    s3_path      = s3_path,
                    list_page    = objects_from_page,
                    on_exception = partial(
                        _s3_error,
                        path   = s3_path,
                        entity = 'Directory')):
                yield FilePath(o)

        gen = file_lister_gen()
        try:
            first = next(gen)   # Execute once just to make sure the current directory exists
        except StopIteration:
            return empty_generator()
        return prepend_element_to_generator(first, gen)

    def list_directories(self,
                         directory: DirectoryPath) -> Iterable[DirectoryPath]:
        """list_directories(directory: DirectoryPath) -> Iterable[DirectoryPath]

        Return an iterable of all of the subdirectories within `directory`.

        Raises:
            FileNotFoundError: `directory` does not exist.
            PermissionError: The system denied the process permission to access
                `directory`.
            ValueError: `directory` is not a valid S3 path.

        Example::

            >>> s3 = S3Data()
            >>> path = DirectoryPath('s3://my-bucket/my-directory')
            >>> for object_key in s3.list_objects(path):
            ...     print(object_key)
            ...
            s3://my-bucket/my-directory/my-subdirectory-1
            s3://my-bucket/my-directory/my-subdirectory-2
            s3://my-bucket/my-directory/my-subdirectory-3
        """
        s3_path = self._clean_dir_path(directory)

        def directories_from_page(page):
            if 'CommonPrefixes' not in page:
                if 'Contents' not in page:
                    if s3_path.key != '':
                        raise FileNotFoundError(
                            'Directory "s3://'
                            f'{s3_path.bucket}/{s3_path.key}"'
                            ' does not exist'
                        )
                    else:
                        print(page)
                        return
            else:
                for metadata in page['CommonPrefixes']:
                    yield f'/{s3_path.bucket}/{metadata["Prefix"]}'

        def directory_lister_gen():
            for o in self._paged_list(
                s3_path   = s3_path,
                list_page = directories_from_page,
                on_exception = partial(
                    _s3_error,
                    path   = s3_path,
                    entity = 'Directory')):
                yield DirectoryPath(o)

        gen = directory_lister_gen()
        try:
            first = next(gen)   # Execute once just to make sure the current directory exists
        except StopIteration:
            return empty_generator()
        return prepend_element_to_generator(first, gen)


    @contextmanager
    def write_object(self, path: FilePath):
        """write_object(path: FilePath) -> ContextManager[BinaryOutput]

        Return a context-managed writable binary stream for writing to an S3
        object.

        Arguments:
            path: An S3 URI or path-like string. See :func:`S3Path.parse` for
                valid path strings.

        Raises:
            FileNotFoundError: One or more directories that are part of the
                `path` do not exist.
            PermissionError: The system denied the process permission to open
                `path` for writing.

        Example::

            >>> path = FilePath('s3://my-bucket/my-key')
            >>> with S3Data().write_object(path) as fout:
            ...     fout.write(b'Some contents')
            ...     fout.write(b'Some more contents')
        """
        s3_path = S3Path.parse(path, self.__delimiter)
        bucket  = _get_bucket(s3_path.bucket, session=self.__session, client=self.__s3_client)
        writer  = _s3_data_writer(bucket, s3_path.key)

        yield writer

        writer.close()

    def _paged_list(self,
                    s3_path     : 'S3Path',
                    list_page   : Callable[[Dict[str, Any]], Iterable[str]],
                    on_exception: Callable[[ClientError], Exception]) \
            -> Iterable[str]:
        objects_paginator = self.__s3_client.get_paginator('list_objects_v2')
        pages = objects_paginator.paginate(
            Bucket    = s3_path.bucket,
            Prefix    = s3_path.key,
            Delimiter = self.__delimiter
        )
        try:
            for page in pages:
                for l in list_page(page):
                    yield l
        except self.__s3_client.exceptions.NoSuchBucket:
            raise FileNotFoundError(f'Bucket "{s3_path.bucket}" does not exist')
        except ClientError as e:
            raise on_exception(e)

    def join(self,
             parent: DirectoryPath,
             child: FSEntity) -> FSEntity:
        """Join a child path to a parent directory

        :param DirectoryPath parent: parent dir to from the base the child is relative to
        :param FSEntity child: child to add on
        :return: composite path
        """
        if child.startswith(self.__delimiter):
            return child
        elif child.startswith(s3_filesystem_type + ':'):
            return self.__delimiter + extract_path_from_fullpath(s3_filesystem_type, child).lstrip(self.__delimiter)
        else:
            protocol = protocol_from_path(child)
            if protocol and protocol != s3_filesystem_type:
                raise ValueError(f'Cannot join path of type \'{protocol}\' to type \'{s3_filesystem_type}\'')
            return parent.rstrip(self.__delimiter) + self.__delimiter + child     # type: ignore

    def get_normalized_name(self, name: FSEntity):
        """
        Get normalized name of a file or directory
        :param name: Path to normalize
        :return: Normalized name
        """
        return name.replace(self.__delimiter, '/')

    def isfile(self,
               path: FSEntity):
        try:
            self.object_size(cast(FilePath, path))
            return True
        except (FileNotFoundError, ClientError):
            for _ in self.list_directories(cast(DirectoryPath, path)):
                break
            return False

    def delete(self,
               path: FilePath):
        raise NotImplementedError


class S3Path(NamedTuple):
    """S3Path(bucket: str, key: str)

    A unique identifier for an object stored in AWS S3.
    """
    bucket: str
    """The name of the S3 bucket that contains the object."""

    key: str
    """The key of the S3 object."""

    def as_uri(self) -> str:
        """Return this S3 path as a URI of the form "s3://[bucket]/[key]"."""
        return f's3://{self.bucket}/{self.key}'

    @staticmethod
    def parse(path: str, delimiter: str = '/') -> 'S3Path':
        """Attempt to parse an :obj:`S3Path` from `path`.

        Args:
            path: A string of the form "{s3:/}/[bucket]{/key}", where "{}"
                indicates an optional value and "[]" indicates a required value.
            delimiter: The character to use to delimit "directories".

        Raises:
            ValueError: `path` is not a valid S3 path or `delimiter` is not
                one character long.
        """
        if not path.startswith('s3://') and not path.startswith(delimiter):
            raise ValueError(
                f'S3 path "{path}" is invalid. '
                f'Paths must either begin with "{delimiter}" or "s3://"'
            )
        if path.startswith(delimiter) and path[1:].startswith(delimiter):
            raise ValueError(
                f'S3 path "{path}" is invalid. '
                'Paths may not begin with two subsequent delimiters'
            )

        components = (
            path[5:].split('/') if path.startswith('s3://') else
            path[1:].split('/')
        )

        return S3Path(
            bucket = components[0],
            key    = '/'.join(components[1:])
        )


class UnexpectedS3Error(Exception):
    """An unanticipated error returned by AWS S3.

    Whenever possible, more specific errors will be raised by the functions and
    classes defined in this module. This error is raised only in cases where the
    HTTP response from AWS S3 is of a form that does not correspond to some
    specific operational error.
    """
    pass


def _s3_error(error : ClientError,
              path  : S3Path,
              entity: str) -> Exception:
    code = _error_code(error)
    return (
        FileNotFoundError(
            f'{entity} "{path.as_uri()}" does not exist'
        ) if code == '404' or code == 'NoSuchBucket' or code == 'NoSuchKey' else
        PermissionError(
            f'Access to {entity.lower()} "{path.as_uri()}" forbidden'
        ) if code == '403' or code == 'InvalidAccessKeyId' else
        UnexpectedS3Error(
            f'Unexpected error while accessing "{path.as_uri()}": '
            f'S3 returned {code}: '
            f'"{_error_message(error) or "No error message returned by S3"}" ' +
            json.dumps(error.response, indent=2)
        )
    )


def _error_message(client_error: ClientError) -> Optional[str]:
    """Get the value of the error message field from an error returned by an AWS
    call.

    Returns:
        The value of `client_error["Error"]["Message"]`, if such a field exists;
        `None`, otherwise.
    """
    return get_in(("Error", "Message"), client_error.response)


def _error_code(client_error: ClientError) -> str:
    """Get the value of the error code field from an error returned by an AWS
    call.

    Returns:
        The value of `client_error["Error"]["Code"]`, if such a field exists;
        `None`, otherwise.
    """
    return get_in(("Error", "Code"), client_error.response)


def _get_bucket(bucket_name: str,
                session: Optional[boto3.Session] = None,
                client = None):
    s3_resource = (session or boto3).resource("s3")
    s3_client = client or s3_resource.meta.client
    # This feels hacky but I cannot find any clean way in the boto3 API
    # to obtain a Bucket instance with anything but the default client, so
    # we need it to use a client that has non-default endpoints (i.e. - not AWS)
    s3_resource.meta.client = s3_client
    try:
        s3_client.head_bucket(Bucket = bucket_name)
        return s3_resource.Bucket(bucket_name)
    except ClientError as e:
        raise _s3_error(e, S3Path(bucket_name, ''), 'Bucket')


def _safe_abort(multipart_upload):
    """Abort the specified multipart upload and ensure that all of its parts are
    removed.

    This method will block until an exception is raised by
    `multipart_upload.abort()` or until all parts in the multipart upload have
    been deleted.

    Raises:
        UnexpectedS3Error: A call to the abort method on the multipart upload
        resulted in an exception.
    """
    def parts_count():
        return len(list(multipart_upload.parts.all() or []))

    def abort_success():
        try:
            multipart_upload.abort()
        except ClientError as err:
            if _error_code(err) == 'NoSuchUpload':
                return True
            else:
                raise _s3_error(err, S3Path(multipart_upload.bucket_name, multipart_upload.object_key), 'Object')
        return False

    while multipart_upload is not None and parts_count() != 0 and not abort_success():
        time.sleep(1)


class _BufferedS3Writer:
    """Append-only, stream-like interface for writing an AWS S3 object."""

    def __init__(self,
                 s3_object,
                 buffer_size: int) -> None:
        self.__object = s3_object
        self.__buffer = bytearray(buffer_size)
        self.__offset = 0
        self.__multipart_upload: Optional[Any] = None
        self.__closed = False
        self.__parts: List[Dict[str, Any]] = []

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        if exc_type is not None:
            self.__abort()
            return False
        else:
            self.close()
            return True

    def write(self, b: Union[bytes, bytearray]) -> int:
        """Write bytes to an S3 object.

        Args:
            b: The bytes or byte-array object to write.

        Returns:
            int number of bytes written.

        Raises:
            :obj:`ValueError`: This writer is closed.
        """
        if self.__closed:
            raise ValueError("I/O operation on closed S3 writer")

        written = 0
        to_write = len(b)
        buffer = memoryview(self.__buffer)
        vbytes = memoryview(b)

        while written < to_write:
            num_remaining_bytes = to_write - written
            chunk_size = min(
                len(self.__buffer) - self.__offset,
                num_remaining_bytes
            )

            buffer[self.__offset: self.__offset + chunk_size] = \
                vbytes[written: written + chunk_size]

            self.__offset += chunk_size

            if len(buffer) == self.__offset:
                try:
                    self.__write_part()
                except ClientError as e:
                    raise _s3_error(
                        e,
                        S3Path(self.__object.bucket_name, self.__object.key),
                        'Object'
                    )

            written += chunk_size

        return written

    def __write_part(self):
        if self.__multipart_upload is None:
            self.__multipart_upload = self.__object.initiate_multipart_upload()

        part_number = len(self.__parts) + 1
        part = self.__multipart_upload.Part(part_number)

        response = part.upload(
            Body = StreamView(self.__buffer, self.__offset)
        )

        self.__offset = 0
        self.__parts.append({
            "ETag": response["ETag"],
            "PartNumber": part_number
        })

    def close(self) -> None:
        """Flush remaining bytes in buffer and complete the creation of S3
        object.
        """
        if self.__closed:
            return
        self.__closed = True

        try:
            if self.__multipart_upload is None:
                self.__object.put(
                    Body = StreamView(
                        self.__buffer,
                        self.__offset
                    )
                )
            else:
                if self.__offset != 0:
                    self.__write_part()

                self.__multipart_upload.complete(
                    MultipartUpload = {
                        "Parts": self.__parts
                    }
                )
        except ClientError as e:
            raise _s3_error(
                e,
                S3Path(self.__object.bucket_name, self.__object.key),
                'Object'
            )

    def flush(self):
        # Multi-part upload doesn't permit meaningful flushing part way through
        # Eventual close will fully flush
        pass

    def readable(self) -> bool:
        return True

    def writable(self) -> bool:
        return True

    def seekable(self) -> bool:
        return False

    @property
    def closed(self) -> bool:
        return self.__closed

    def __abort(self):
        """Abort upload. Make sure that all parts have been deleted. This method
        will repeatedly invoke MPU.abort until either a ClientError with code
        'NoSuchUpload' is raised or the list of parts is empty.

        For further details:
        https://docs.aws.amazon.com/AmazonS3/latest/API/mpUploadAbort.html
        """
        if self.__closed:
            return
        self.__closed = True

        _safe_abort(self.__multipart_upload)


def _s3_data_writer(bucket,
                    object_key: str,
                    buffer_size: Optional[int] = None) -> _BufferedS3Writer:
    """Create an instance of :obj:`BufferedS3Writer` for the specified S3
    object.

    Args:
        bucket: A `boto3.Bucket` resource.
        object_key: The key of the S3 object to write.
        buffer_size: Size of the buffer, in bytes, to use for the buffered
            writer. Default is :obj:`MINIMUM_MP_UPLOAD_SIZE`.

    Raises:
        :obj:`ValueError`: `buffer_size` is less than the minimum allowable
            buffer size, :obj:`MINIMUM_MP_UPLOAD_SIZE`.
        :obj:`FileNotFoundError`: Key does not exist
        :obj: `PermissionError`: Access is denied to the specified S3 object, or S3 returned an error during an access test.
    """
    buffer_size = buffer_size or MINIMUM_MP_UPLOAD_SIZE
    if buffer_size < MINIMUM_MP_UPLOAD_SIZE:
        raise ValueError(
            "Buffer size must be at least %d bytes." % MINIMUM_MP_UPLOAD_SIZE)

    try:
        s3_object = bucket.Object(object_key)
        multipart_upload = s3_object.initiate_multipart_upload()
        _safe_abort(multipart_upload)
    except ClientError as e:
        raise _s3_error(e, S3Path(bucket.name, object_key), 'Object')

    return _BufferedS3Writer(s3_object, buffer_size)



"""The S3 filesystem as a :class:`FileSystem`
"""


def s3_filesystem(session: Optional[boto3.Session]):
    if session is None:
        data = _get_default_s3_data()
    else:
        data = S3Data(session=session)
    return FileSystem(s3_filesystem_type,
                      data.read_object,
                      data.write_object,
                      data.object_size,
                      data.last_modified,
                      data.list_objects,
                      data.list_directories,
                      data.join,
                      data.isfile,
                      data.delete,
                      data.get_normalized_name)


_session_free_s3_data = None


# Environment variables used to source non-boto-default config for the
# service endpoint and authentication keys
S3_ENDPOINT_VAR = 'BUCKET_ENDPOINT'
S3_ACCESS_KEY_VAR = 'BUCKET_ACCESS_KEY'
S3_TOKEN_VAR = 'BUCKET_SECRET_KEY'
S3_CERT_VERIFICATION = 'VERIFY_CERT'


def _to_bool(s: str) -> bool:
    return s.lower() in ('1', 'true')


def _read_s3_service_config():
    """Check for endpoint and credential overrides in the environment"""
    result = {}
    if os.environ.get(S3_ENDPOINT_VAR) is not None:
        result['endpoint_url'] = os.environ.get(S3_ENDPOINT_VAR)
    if os.environ.get(S3_ACCESS_KEY_VAR) is not None:
        result['access_key'] = os.environ.get(S3_ACCESS_KEY_VAR)
    if os.environ.get(S3_TOKEN_VAR) is not None:
        result['token'] = os.environ.get(S3_TOKEN_VAR)
    if os.environ.get(S3_CERT_VERIFICATION) is not None:
        result['verify_cert'] = _to_bool(os.environ.get(S3_TOKEN_VAR))
    return result


def _get_default_s3_data():
    global _session_free_s3_data
    if _session_free_s3_data is None:
        _session_free_s3_data = S3Data(**_read_s3_service_config())
    return _session_free_s3_data


def s3_entity_locater(path: str, session: Optional[boto3.Session]=None) -> FSLocater:
    return FSLocater(s3_filesystem(session=session), path)    # type: ignore
