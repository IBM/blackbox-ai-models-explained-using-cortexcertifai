"""
Filesystem abstractions that provide general facilities for accessing data in a
portable manner.

To get started with this package, check out the documentation for the
:mod:`certifai.common.file.interface` module.

:mod:`.interface`
^^^^^^^^^^^^^^^^^

.. currentmodule:: certifai.common.file.interface

.. autosummary::

    DirectoryPath
    FilePath
    FSEntity
    SizeBytes
    BinaryInput
    BinaryOutput
    FileLister
    DirectoryLister
    FileReader
    FileWriter
    FileSizeGetter
    FileLastModifiedGetter
    TextFileReader
    TextFileWriter
    FileSystem
    FSLocater
    text_reader
    text_writer


:mod:`.local`
^^^^^^^^^^^^^

.. currentmodule:: certifai.common.file.local

.. autosummary::

    local_filesystem
    local_entity_locater


:mod:`.memory`
^^^^^^^^^^^^^^

.. currentmodule:: certifai.common.file.memory

.. autosummary::

    memory_filesystem
    memory_entity_locater


:mod:`.s3`
^^^^^^^^^^

.. currentmodule:: certifai.common.file.s3

.. autosummary::

    S3Data
    S3Path
    UnexpectedS3Error
    _BufferedS3Writer


:mod:`.streaming`
^^^^^^^^^^^^^^^^^

.. currentmodule:: certifai.common.file.streaming

.. autosummary::

    pipe
    StreamView

"""
from certifai.common.file.interface import *
from certifai.common.file.interface import FileSystem

local_filesystem_type = 'local'
memory_filesystem_type = 'mem'
s3_filesystem_type = "s3"
gcp_filesystem_type = "gs"
azure_blob_filesystem_type = "abfs"
