from certifai.common.file.interface import FSLocater
from certifai.common.file import local_filesystem_type, memory_filesystem_type, s3_filesystem_type, gcp_filesystem_type, azure_blob_filesystem_type
from certifai.common.file.local import local_entity_locater
from certifai.common.file.memory import memory_entity_locater
from certifai.common.utils.file_utils import protocol_from_path
import re
try:
    from certifai.common.file.gcp import gcp_entity_locater
    gcp_loaded = True
except ModuleNotFoundError:
    gcp_loaded = False
try:
    from certifai.common.file.s3 import s3_entity_locater
    s3_loaded = True
except ModuleNotFoundError:
    s3_loaded = False
try:
    from certifai.common.file.azure import abfs_entity_locater
    abfs_loaded = True
except ModuleNotFoundError:
    abfs_loaded = False



def locater_type_name(locater: FSLocater) -> str:
    """Retrieve the filesystem type a locater is with reference to

    :param FSLocater locater: locater to determine the filesystem type of
    :return: Name of the filesystem type
    """
    return locater.filesystem.type_name


def make_locater(type_name: str, path: str) -> FSLocater:
    """Instantiate a locater given a filesystem type name and path

    :param str type_name: Type name of the filesystem to instantiate for
    :param str path: Path of the entity the locater is to reference
    :return: An FSLocater for the path on the correct filesystem type
    """
    if type_name == local_filesystem_type:
        return local_entity_locater(path)
    elif type_name == memory_filesystem_type:
        return memory_entity_locater(path)
    elif type_name == s3_filesystem_type:
        if s3_loaded:
            return s3_entity_locater(path)
        else:
            raise ModuleNotFoundError(
                'To use the certifai.common.file.s3 module, install cortex-certifai-common with the "s3" '
                'extra flag.\nFor example, "pip install cortex-certifai-common[s3]"'
            )
    elif type_name == gcp_filesystem_type:
        if gcp_loaded:
            return gcp_entity_locater(path)
        else:
            raise ModuleNotFoundError(
                'To use the certifai.common.file.gcp module, install cortex-certifai-common with the "gcp" '
                'extra flag.\nFor example, "pip install cortex-certifai-common[gcp]"'
            )
    elif type_name == azure_blob_filesystem_type:
        if abfs_loaded:
            return abfs_entity_locater(path)
        else:
            raise ModuleNotFoundError(
                'To use the certifai.common.file.azure module, install cortex-certifai-common with the "azure" '
                'extra flag.\nFor example, "pip install cortex-certifai-common[azure]"'
            )
    raise ValueError("Unknown filesystem type '{}'".format(type_name))




def locater_to_path(locater: FSLocater) -> str:
    return locater.filesystem.type_name + "://" + locater.name


def make_generic_locater(path: str) -> FSLocater:
    """Instantiate a locater given a filesystem type name and path

    :param str path: Path of the entity the locater is to reference (including protocol if not local)
    :return: An FSLocater for the path on the correct filesystem type
    """
    protocol = protocol_from_path(path)
    if protocol is None:
        # No protocol specified - treat as local path
        fs_type = local_filesystem_type
        p_relative = path
    else:
        if protocol == 's3':
            fs_type = s3_filesystem_type
        elif protocol == 'gs':
            fs_type = gcp_filesystem_type
        elif protocol == 'abfs':
            fs_type = azure_blob_filesystem_type
        elif protocol == 'file':
            fs_type = local_filesystem_type
        elif protocol == 'mem':
            fs_type = memory_filesystem_type
        else:
            raise ValueError(f"Unknown filesystem protocol '{protocol}'")

        p_relative = path[len(protocol)+1:]
        if p_relative.startswith('//'):
            p_relative = p_relative[1:]

    return make_locater(fs_type, p_relative)
