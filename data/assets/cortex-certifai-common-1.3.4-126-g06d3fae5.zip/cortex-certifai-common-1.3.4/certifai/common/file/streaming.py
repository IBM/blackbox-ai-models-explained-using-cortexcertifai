"""Tools for synchronous streaming of binary data."""
import io
from typing import Iterable, Optional, Union

from toolz import excepts, take

from certifai.common.file.interface import BinaryInput, BinaryOutput


__all__ = [
    'pipe',
    'StreamView'
]


class _ReadIntoWrapper(object):
    """Provides stream-like objects that have a `read` method, but no `readinto`
    method, with a `readinto` method."""
    def __init__(self, stream):
        self.__stream = stream

    def readinto(self, bytes_like):
        data = self.__stream.read(len(bytes_like))
        bytes_like[0:len(data)] = data
        return len(data)


# TODO: Tune buffer size automatically to optimize throughput
def pipe(input_stream : Union[BinaryInput, _ReadIntoWrapper],
         output_stream: BinaryOutput,
         buffer_size  : int = 2097152) -> Iterable[int]:
    """Read bytes from an input stream and write them to an output stream while
    reporting transfer progress.

    Note that the iterable returned by this function *must* be iterated over for
    data transfer to actually occur. The total number of bytes *actually* piped
    between the input and output streams is equal to the maximum value yielded
    by the iterable.

    Args:
        input_stream: A readable binary stream-like object that has, at a
            minimum, a `read` method, and, ideally, a `readinto` method.
        output_stream: A writable binary stream-like object that has, at a
            minimum, a `write` method.
        buffer_size: Number of bytes to request for each chunk transferred.

    Returns:
        A generator that yields the total number of bytes transferred.
        The generator exits only after reaching the end of `instream`.

    Raises:
        :obj:`io.UnsupportedOperation`: `input_stream` is write-only or
            `output_stream` is read-only.
        :obj:`ValueError`: `input_stream` or `output_stream` is closed.

    Example::

        with open('input-file', 'rb') as fin, open('output-file', 'wb') as fout:
            for progress in pipe(fin, fout):
                print(f'Copied {progress} bytes')
    """
    _buffer = bytearray(buffer_size)
    buffer  = memoryview(_buffer)
    bytes_transferred = 0

    if not hasattr(input_stream, 'readinto'):
        i_stream: Union[BinaryInput, _ReadIntoWrapper] = _ReadIntoWrapper(input_stream)
    else:
        i_stream = input_stream

    while True:
        chunk_size = excepts(
            io.BlockingIOError,
            i_stream.readinto,  # type: ignore
            lambda: None
        )(buffer)

        if chunk_size is None:
            # Data not yet available
            # (See https://docs.python.org/3.6/library/io.html)
            continue
        elif chunk_size == 0:
            # End of stream
            # (See https://docs.python.org/3.6/library/io.html)
            break

        bytes_written = 0
        while bytes_written < chunk_size:
            try:
                bytes_written += output_stream.write(
                    buffer[bytes_written:chunk_size]
                ) or 0
            except io.BlockingIOError:
                # Non-blocking stream that inherits BufferedIOBase could not
                # accept data without blocking
                # (See https://docs.python.org/3.6/library/io.html)
                pass

        bytes_transferred += chunk_size

        yield bytes_transferred


class StreamView:
    """Provides a read-only, stream-like view of an in-memory collection of
    bytes.

    Example::

        def pipe_data_out(data: bytearray, output_file: str):
            data_stream = StreamView(data)
            with open(output_file, 'wb') as fout:
                for progress in pipe(data_stream, fout):
                    print(f'{progress} bytes written')
    """

    def __init__(self,
                 buffer: Union[bytes, bytearray],
                 length: Optional[int] = None) -> None:
        """Create a new :obj:`StreamView` instance.

        Args:
            buffer: A :obj:`bytes` or :obj:`bytearray` instance.
            length: The maximum number of bytes to read from `buffer`.

        `buffer` is not copied. If it is a mutable :obj:`bytearray`, then any
        changes to it will be reflected in the bytes read by this stream view.
        """
        self.__buffer   = buffer
        self.__position = 0
        self.__closed   = False
        self.__length   = (
            min(length, len(buffer)) if length is not None else
            len(buffer)
        )

    @property
    def closed(self):
        return self.__closed

    def close(self):
        self.__closed = True

    def __enter__(self):
        if self.closed:
            raise ValueError('I/O operation on closed file')
        return self

    def __exit__(self, _, __, ___):
        self.close()

    def flush(self):
        if self.closed:
            raise ValueError('I/O operation on closed file')

    def isatty(self):
        if self.closed:
            raise ValueError('I/O operation on closed file')
        return False

    def readable(self):
        if self.closed:
            raise ValueError('I/O operation on closed file')
        return True

    def __iter__(self):
        return self

    def __next__(self):
        if self.closed:
            raise ValueError('I/O operation on closed file')

        if self.__position >= self.__length:
            raise StopIteration()
        else:
            return self.readline()

    def read(self, size=-1):
        if self.closed:
            raise ValueError('I/O operation on closed file')

        upper_limit = (
            self.__length if size is None or size < 0 else
            max(0, min(self.__position + size, self.__length))
        )
        value = self.__buffer[self.__position:upper_limit]
        self.__position += len(value)
        return value

    def read1(self, size=-1):
        return self.read(size)

    def readinto(self, b):
        if self.closed:
            raise ValueError('I/O operation on closed file')

        read_count = max(0, min(self.__length - self.__position, len(b)))
        b[:read_count] = self.__buffer[self.__position:read_count]
        self.__position += read_count
        return read_count

    def readinto1(self, b):
        return self.readinto(b)

    def readline(self, size = -1) -> bytes:
        if self.closed:
            raise ValueError('I/O operation on closed file')

        upper_limit = (
            self.__length if size is None or size < 0 else
            max(0, min(self.__position + size, self.__length))
        )
        read_until = self.__buffer.find(b'\n', self.__position, upper_limit)

        if read_until == -1:
            read_until = upper_limit
        else:
            read_until += 1

        line = self.__buffer[self.__position:read_until]
        self.__position += len(line)

        return line

    def readlines(self, hint=-1):
        if self.closed:
            raise ValueError('I/O operation on closed file')

        return list(
            self if hint < 0 else
            take(hint, self)
        )

    def seekable(self):
        if self.closed:
            raise ValueError('I/O operation on closed file')

        return True

    def tell(self):
        if self.closed:
            raise ValueError('I/O operation on closed file')

        return self.__position

    def writable(self):
        if self.closed:
            raise ValueError('I/O operation on closed file')

        return False

    def seek(self, offset, whence = 0):
        if self.closed:
            raise ValueError('I/O operation on closed file')

        if whence == io.SEEK_SET:
            if offset < 0:
                raise ValueError(f'negative seek value {offset}')
            self.__position = offset
        elif whence == io.SEEK_CUR:
            self.__position = max(0, self.__position + offset)
        elif whence == io.SEEK_END:
            self.__position = max(0, self.__length + offset)

        return self.__position

    def truncate(self, _ = None):
        if self.closed:
            raise ValueError('I/O operation on closed file')

        raise OSError('Read-only stream cannot be truncated')

    def writelines(self, _):
        if self.closed:
            raise ValueError('I/O operation on closed file')

        raise OSError('Invalid operation on read-only stream')

    def __del__(self):
        self.close()

    def fileno(self):
        raise io.UnsupportedOperation('fileno')
