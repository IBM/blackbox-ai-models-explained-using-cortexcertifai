"""Local filesystem implementations for the data interfaces defined in
:mod:`certifai.common.file.interface`.

Functions defined in this module are not intended to be used directly. Rather,
the power of this module is in its conformance to the interfaces defined in the
:mod:`certifai.common.file.interface` module.

For example, if you find yourself needing to read a file in a certain part of
your code, you can declare a dependence of that part of the code on a reader of
type :obj:`certifai.common.file.interface.FileReader`. If you need to read a file as part
of a particular function, for example, then you can add an argument to that
function of type `FileReader`::

    from certifai.common.file.interface import FileReader

    def my_function(my_argument   : int
                    other_argument: str,
                    read_file     : FileReader)
        # ...

        # part of code that needs to read a file
        with read_file(path_to_file) as handle:
            ...

If you need to read a file in a particular class, then perhaps it makes sense to
require a `FileReader` to be provided to the constructor of your class::

    from certifai.common.file.interface import FileReader

    class MyClass:

        def __init__(self,
                     my_parameter: int,
                     file_reader : FileReader):
            self.__file_reader = file_reader
            # ...

        def some_method(self,
                        some_argument: int) -> str:
            # ...

            # part of code that needs to read a file
            with self.__file_reader(path_to_file) as handle:
               ...

Code that depends on a `FileReader` is decoupled from any particular
implementation of `FileReader`. That is, you can provide one implementation
during local testing and another in production::

    from certifai.common.file import local, s3

    actual_reader = (
        local.read_file if running_locally else
        s3.S3Data().read_object
    )

    my_function(5, 'other argument', actual_reader)

    # ...

    my_class = MyClass(42, actual_reader)
    my_class.some_method(35151)
"""
import os
from typing import Iterable, cast
from pathlib import PureWindowsPath
from datetime import datetime, timezone

from certifai.common.file.interface import *
from certifai.common.file import local_filesystem_type
from certifai.common.utils.file_utils import extract_path_from_fullpath, protocol_from_path

__all__ = [
    'local_filesystem_type',
    'local_filesystem',
    'local_entity_locater'
]


def list_files(directory: DirectoryPath) -> Iterable[FilePath]:
    """list_files(directory: DirectoryPath) -> Iterable[FilePath]

    Return an iterable of files contained in the specified directory.
    Note that the absolute paths of the files are returned (i.e. they
    *include* `directory` in their paths).

    Args:
        directory: The path of the directory to list files within.

    Returns:
        An iterable of the absolute paths of all files contained in `directory`.

    Raises:
        FileNotFoundError: `directory` does not exist.
        PermissionError: The system denied the process permission to access
            `directory`.

    Example::

        >>> for file in list_files(DirectoryPath('/usr/lib')):
        ...     print(file)
        ...
        /usr/lib/liba.dylib
        /usr/lib/libb.dylib
        etc...
    """
    return (
        FilePath(os.path.abspath(os.path.join(directory, filename)))
        for filename in os.listdir(directory)
        if os.path.isfile(os.path.join(directory, filename))
    )


def list_directories(directory: DirectoryPath) -> Iterable[DirectoryPath]:
    """list_directories(directory: DirectoryPath) -> Iterable[DirectoryPath]

    Return an iterable of the subdirectories contained in the specified
    directory. Note that the absolute paths of the subdirectories are returned
    (i.e. they *include* `directory` in their paths).

    Args:
        directory: The path of the directory to list directories within.

    Returns:
        An iterable of the absolute paths of all directories contained in
        `directory`.

    Raises:
        FileNotFoundError: `directory` does not exist.
        PermissionError: The system denied the process permission to access
            `directory`.

    Example::

        >>> for directory in list_directories(DirectoryPath('/opt')):
        ...     print(directory)
        ...
        /opt/X11
        /opt/jc
        etc...
    """
    return (
        DirectoryPath(os.path.abspath(os.path.join(directory, dirname)))
        for dirname in os.listdir(directory)
        if os.path.isdir(os.path.join(directory, dirname))
    )


def read_file(file_path: FilePath):
    """read_file(file_path: FilePath) -> ContextManager[BinaryInput]

    Return a context-managed, read-only binary stream that reads data from the
    specified file.

    Args:
        file_path: The absolute path of a file on the local file system.

    Raises:
        FileNotFoundError: `file_path` does not exist.
        PermissionError: The system denied the process permission to open
            `file_path` for reading.

    Example::

        with read_file(FilePath('/path/to/my-file')) as fin:
            my_file_data = fin.read()
    """
    return open(file_path, 'rb')


def file_size(file_path: FilePath) -> SizeBytes:
    """file_size(file_path: FilePath) -> SizeBytes

    Return the size of the specified file, in bytes.

    Args:
        file_path: The absolute path of a file on the local file system.

    Raises:
        FileNotFoundError: `file_path` does not exist.
        PermissionError: The system denied the process permission to access
            `file_path`.

    Example::

        >>> path = FilePath('/path/to/my-file')
        >>> print(file_size(path))
        1250124
    """
    return SizeBytes(os.path.getsize(file_path))


def last_modified(file_path: FilePath) -> LastModified:
    """last_modified(file_path: FilePath) -> LastModified

    Return the last modified or updated property of the specified file, as a timezone aware datetime

    Args:
        file_path: The absolute path of a file on the local file system.

    Raises:
        FileNotFoundError: `file_path` does not exist.
        PermissionError: The system denied the process permission to access
            `file_path`.

    Example::

        >>> path = FilePath('/path/to/my-file')
        >>> print(last_modified(path))
        2020-06-11 02:48:14+00:00
    """
    return LastModified(datetime.fromtimestamp(os.path.getmtime(file_path)).astimezone(tz=timezone.utc))


def _ensure_ancestors(path):
    parent = os.path.dirname(path)
    if parent != '':
        os.makedirs(parent, exist_ok=True)


def write_file(file_path: FilePath):
    """write_file(file_path: FilePath) -> ContextManager[BinaryOutput]

    Return a context-managed, write-only binary stream that writes data to the
    specified file. Note that if the specified file already exists, it will be
    overwritten.

    Args:
        file_path: The absolute path of a file on the local file system.

    Raises:
        PermissionError: The system denied the process permission to open
            `file_path` for writing.

    Example::

        with write_file(FilePath('/path/to/my-file')) as fout:
            fout.write(b'Some data')
            fout.write(b'Some more data')
    """
    _ensure_ancestors(file_path)
    return open(file_path, 'wb')


def join(parent: DirectoryPath, child: FSEntity) -> FSEntity:
    """Join a child path to a parent directory

    :param DirectoryPath parent: parent dir to from the base the child is relative to
    :param FSEntity child: child to add on
    :return: composite path
    """
    delimeter = '/'
    local_protocol = 'file'
    if child.startswith(f'{local_protocol}:'):
        return delimeter + extract_path_from_fullpath(local_protocol, child).lstrip(delimeter)
    protocol = protocol_from_path(child)
    if protocol and protocol != local_protocol:
        raise ValueError(f'Cannot join path of type \'{protocol}\' to type \'{local_protocol}\'')
    return os.path.join(parent, child)  # type: ignore


def isfile(path: FSEntity):
    """Determine iof a path string refers to a file

    :param path: path to test
    :return: True if the path exists and is a file
    :raise `FileNotFoundError` if the entity does not exist
    """
    if not os.path.exists(path):
        raise FileNotFoundError

    return os.path.isfile(path)


def delete(path: FSEntity):
    """Determine iof a path string refers to a file

    :param path: path to delete
    :raise `FileNotFoundError` if the entity does not exist
    """
    if isfile(path):
        os.unlink(path)
    else:
        for d in list_directories(cast(DirectoryPath, path)):
            delete(d)
        for f in list_files(cast(DirectoryPath, path)):
            os.unlink(f)
        os.rmdir(path)


def get_normalized_name(name: FSEntity):
    """
    Get normalized name of a file or directory
    :param name: Path to normalize
    :return: Normalized name
    """
    return PureWindowsPath(name).as_posix()


"""The local filesystem as a :class:`FileSystem`
"""
local_filesystem = FileSystem(local_filesystem_type,
                              read_file,
                              write_file,
                              file_size,
                              last_modified,
                              list_files,
                              list_directories,
                              join,
                              isfile,
                              delete,
                              get_normalized_name)


def local_entity_locater(path: str) -> FSLocater:
    return FSLocater(local_filesystem, path)    # type: ignore
