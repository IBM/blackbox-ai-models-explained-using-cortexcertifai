from contextlib import contextmanager
from typing import Iterable, NamedTuple
from datetime import datetime, timezone

try:
    from gcsfs import GCSFileSystem
except ModuleNotFoundError:
    raise ModuleNotFoundError(
        'To use the certifai.common.file.gcp module, install cortex-certifai-common with the "gcp" '
        'extra flag.\nFor example, "pip install cortex-certifai-common[gcp]"'
    )

from certifai.common.file.interface import *
from certifai.common.file import gcp_filesystem_type
from certifai.common.utils.file_utils import extract_path_from_fullpath, protocol_from_path


__all__ = [
    'GCPData',
    'GCPPath',
    'gcp_filesystem_type',
    'gcp_entity_locater'
]

UPDATED_STR_FORMAT = '%Y-%m-%dT%H:%M:%S.%fZ'

class GCPData:
    """Implements interfaces defined in :mod:`certifai.common.file.interface` for GCP.
    """
    def __init__(self, token = None, directory_delimiter: str = '/') -> None:
        self.__fs = GCSFileSystem(token=token, cache_timeout=0)
        self.__delimiter = directory_delimiter

    def __convert_path(self, path):
        """
        Converts given path to a format consumable by GCSFileSystem individual file read / write methods.

        Validates the path and strips leading and trailing delimiters from it.
        """
        return path.strip(self.__delimiter)

    def __build_path(self, path):
        """
        return path with delimiter + container_name prepended to it
        """
        return f'{self.__delimiter}{path}' if not path.startswith(self.__delimiter) else path

    def _check_directory_exists(self, path):
        """
        Raises FileNotFoundError if no directory / file exists as the path.
        """
        try:
            self.__fs.info(self.__convert_path(path))
        except FileNotFoundError:
            raise FileNotFoundError(
                'Directory "gs://'
                f'{self.__build_path(path)}"'
                ' does not exist'
            )

    def read_object(self, path: FilePath):
        """read_object(path: FilePath) -> ContextManager[BinaryInput]

        Provide a context-managed binary stream for reading data from an object
        stored in GCP.

        Arguments:
            path: An GCP URI or path-like string. See :func:`GCPPath.parse` for
                valid path strings.

        Raises:
            ValueError: `path` is not a valid GCP path.
            FileNotFoundError: `path` does not exist.
            PermissionError: The system denied the process permission to open
                `path` for reading.

        Example::

            >>> def print_object(gs: GCPData):
            ...     path = FilePath('gs://my-bucket/my-key')
            ...     # path could also be FilePath('/my-bucket/my-key')
            ...     with gs.read_object(path) as fin:
            ...         print(fin.read())
            ...
            b'Some contents'
        """
        return self.__fs.open(self.__convert_path(path))

    def object_size(self, path: FilePath) -> SizeBytes:
        return SizeBytes(self.__fs.info(self.__convert_path(path))['size'])

    def last_modified(self, path: FilePath) -> LastModified:
        """last_modified(file_path: FilePath) -> LastModified

        Return the last modified or updated property of the specified file, as a timezone aware datetime

        Args:
            path: An GCP URI or path-like string. See :func:`GCPPath.parse` for
                valid path strings.

        Raises:
            ValueError: `path` is not a valid GCP path.
            FileNotFoundError: `path` does not exist.
            PermissionError: The system denied the process permission to open
                `path` for reading.

        Example::

            >>> def print_last_modified(gs: GCPData):
            ...     path = FilePath('gs://my-bucket/my-key')
            ...     # path could also be FilePath('/my-bucket/my-key')
            ...     print(gs.last_modified(path))
            ...
            2020-06-11 02:48:14+00:00
        """
        return LastModified(datetime.strptime(self.__fs.info(self.__convert_path(path))['updated'], UPDATED_STR_FORMAT)
                            .astimezone(tz=timezone.utc))

    def list_objects(self, directory: DirectoryPath) -> Iterable[FilePath]:
        """list_objects(directory: DirectoryPath) -> Iterable[FilePath]

        Return an iterable of files contained in the specified directory.

        Args:
            directory: The path of the directory to list files within.

        Returns:
            An iterable of the absolute paths of all files contained in
            `directory`.

        Raises:
            FileNotFoundError: `directory` does not exist.

        Example::

            >>> gs = GCPData()
            >>> path = DirectoryPath('gs://my-bucket/my-directory')
            >>> for object_key in gs.list_objects(path):
            ...     print(object_key)
            ...
            gs://my-bucket/my-directory/my-object-1
            gs://my-bucket/my-directory/my-object-2
            gs://my-bucket/my-directory/my-object-3
        """
        self.__fs.invalidate_cache()
        ls_output = self.__fs.ls(directory, detail=True)
        if len(ls_output) == 0:
            self._check_directory_exists(directory)
        return (self.__build_path(f['name']) for f in ls_output if f['type'] == 'file')

    def list_directories(self,
                         directory: DirectoryPath) -> Iterable[DirectoryPath]:
        """list_directories(directory: DirectoryPath) -> Iterable[DirectoryPath]

        Return an iterable of all of the subdirectories within `directory`.

        Raises:
            FileNotFoundError: `directory` does not exist.

        Example::

            >>> gcp = GCPData()
            >>> path = DirectoryPath('gs://my-bucket/my-directory')
            >>> for object_key in gcp.list_objects(path):
            ...     print(object_key)
            ...
            gs://my-bucket/my-directory/my-subdirectory-1
            gs://my-bucket/my-directory/my-subdirectory-2
            gs://my-bucket/my-directory/my-subdirectory-3
        """
        self.__fs.invalidate_cache()
        ls_output = self.__fs.ls(directory, detail=True)
        if len(ls_output) == 0:
            self._check_directory_exists(directory)
        return (self.__build_path(f['name']) for f in ls_output \
                if f['type'] == 'directory')

    def write_object(self, path: FilePath):
        """write_object(path: FilePath) -> ContextManager[BinaryOutput]

        Return a context-managed writable binary stream for writing to an GCP
        object.

        Arguments:
            path: An GCP URI or path-like string. See :func:`GCPPath.parse` for
                valid path strings.

        Raises:
            FileNotFoundError: One or more directories that are part of the
                `path` do not exist.
            PermissionError: The system denied the process permission to open
                `path` for writing.

        Example::

            >>> path = FilePath('gs://my-bucket/my-key')
            >>> with GCPData().write_object(path) as fout:
            ...     fout.write(b'Some contents')
            ...     fout.write(b'Some more contents')
        """
        return self.__fs.open(self.__convert_path(path), 'wb')

    def join(self,
             parent: DirectoryPath,
             child: FSEntity) -> FSEntity:
        if child.startswith(self.__delimiter):
            return child
        elif child.startswith(gcp_filesystem_type + ':'):
            return self.__delimiter + extract_path_from_fullpath(gcp_filesystem_type, child).lstrip(self.__delimiter)
        else:
            protocol = protocol_from_path(child)
            if protocol and protocol != gcp_filesystem_type:
                raise ValueError(f'Cannot join path of type \'{protocol}\' to type \'{gcp_filesystem_type}\'')
            return parent.rstrip(self.__delimiter) + self.__delimiter + child     # type: ignore

    def isfile(self, path: FSEntity):
        try:
            return self.__fs.info(self.__convert_path(path))['type'] == 'file'
        except FileNotFoundError:
            return False

    def delete(self, path: FSEntity):
        _path = self.__convert_path(path)
        _type = self.__fs.info(_path)['type']
        if _type == 'directory':
            self.__fs.rm(_path, recursive=True)
        elif _type == 'file':
            self.__fs.rm(_path)

    def get_normalized_path(self, name: FSEntity):
        """
        Get normalized name of a file or directory
        :param name: Path to normalize
        :return: Normalized name
        """
        return name.replace(self.__delimiter, '/')


class GCPPath(NamedTuple):
    """GCPPath(bucket: str, key: str)

    A unique identifier for an object stored in GCP.
    """
    bucket: str
    """The name of the GCP bucket that contains the object."""

    key: str
    """The key of the GCP object."""

    def as_uri(self) -> str:
        """Return this GCP path as a URI of the form "gs://[bucket]/[key]"."""
        return f'gs://{self.bucket}/{self.key}'

    @staticmethod
    def parse(path: str, delimiter: str = '/') -> 'GCPPath':
        """
        Attempt to parse an :obj:`GCPPath` from `path`.

        Args:
            path: A string of the form "{gs:/}/[bucket]{/key}", where "{}"
                indicates an optional value and "[]" indicates a required value.
            delimiter: The character to use to delimit "directories".

        Raises:
            ValueError: `path` is not a valid GCP path or `delimiter` is not
                one character long.
        """
        if not path.startswith('gs://') and not path.startswith(delimiter):
            raise ValueError(
                f'GCP path "{path}" is invalid. '
                f'Paths must either begin with "{delimiter}" or "gs://"'
            )
        if path.startswith(delimiter) and path[1:].startswith(delimiter):
            raise ValueError(
                f'GCP path "{path}" is invalid. '
                'Paths may not begin with two subsequent delimiters'
            )

        components = (
            path[5:].split('/') if path.startswith('gs://') else
            path[1:].split('/')
        )

        return GCPPath(
            bucket = components[0],
            key    = '/'.join(components[1:])
        )


def gcp_filesystem():
    data = GCPData()
    return FileSystem(gcp_filesystem_type,
                      data.read_object,
                      data.write_object,
                      data.object_size,
                      data.last_modified,
                      data.list_objects,
                      data.list_directories,
                      data.join,
                      data.isfile,
                      data.delete,
                      data.get_normalized_path)


def gcp_entity_locater(path: str) -> FSLocater:
    return FSLocater(gcp_filesystem(), path)    # type: ignore
