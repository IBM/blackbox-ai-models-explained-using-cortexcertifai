"""In-memory implementation of the :class:`FileSystem` abstraction.

This is useful in niche circumstances such as where temporary artifacts
need to be stored in-memory but with ease of switching to a true filesystem
at scale.

*Notes*:
    - Creating a file implicitly creates any necessary parent directories
    - this implementation does NOT support overlapped read and write access
      to the same file

Often useful in testing
"""
from typing import Iterable, Dict, Union, Optional, List
from datetime import datetime, timezone

from certifai.common.file.interface import *
from certifai.common.file import memory_filesystem_type

__all__ = [
    'memory_filesystem',
    'reset_memory_filesystem',
    'memory_entity_locater'
]

class _Content:
    def __init__(self):
        self.value: bytes = bytes()


_root: Dict[str, Union[str, _Content, dict]] = {}


def _find(path: FSEntity, create: bool=False, remove=False) -> Optional[Union[FSEntity, _Content]]:
    global _root

    def make_file(parent, name) -> _Content:
        parent[name] = _Content()
        return parent[name]

    def make_dir(parent, name) -> dict:
        parent[name] = {}
        return parent[name]

    def find_in(parent: Dict[str, Union[str, _Content, dict]], path: List[str]):
        if len(path) == 0:
            return _root
        elif len(path) == 1:
            if len(path[0]) == 0:
                return _root
            else:
                result = parent.get(path[0])
                if result is None:
                    if create:
                        result = make_file(parent, path[0])
                    return result
                elif create and isinstance(result, dict):
                    raise PermissionError

                if remove:
                    parent.pop(path[0], None)
                    return None
                else:
                    return result
        else:
            child = parent.get(path[0])
            if child is None:
                if create:
                    child = make_dir(parent, path[0])
                    return find_in(child, path[1:])
                else:
                    return None
            elif isinstance(child, dict):
                return find_in(child, path[1:])
            elif create:
                raise PermissionError
            else:
                return None
    return find_in(_root, path.strip('/').split('/'))


class _MemoryReader(BinaryInput):
    def __init__(self, content: Union[bytes, bytearray, memoryview]):
        self._content = memoryview(content)
        self._offset = 0

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        if exc_type is not None:
            return False
        else:
            return True

    def __iter__(self):
        self._offset = 0
        return self

    def __next__(self):
        result = self.read(max_bytes=1)
        if len(result) == 0:
            raise StopIteration
        else:
            return result

    def read(self, max_bytes: int=-1) -> bytes:
        """Read at most `max_bytes` from a stream.

        Arguments:
            max_bytes: The maximum number of bytes to return.

        Returns:
            A `bytes` instance that contains 0 to `max_bytes` bytes.
        """
        if max_bytes >= 0:
            result = self._content[self._offset:self._offset+max_bytes]
        else:
            result = self._content[self._offset:]
        self._offset += len(result)
        return bytes(result)

    def readable(self) -> bool:
        return True

    def writable(self) -> bool:
        return False

    def seekable(self) -> bool:
        return False

    @property
    def closed(self) -> bool:
        return False


class _MemoryWriter(BinaryOutput):
    def __init__(self, content: _Content):
        self._content = content
        content.value = bytes()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        if exc_type is not None:
            return False
        else:
            return True

    def write(self, s: Union[bytes, bytearray, memoryview]) -> int:
        """Write `s` bytes to a stream.

        Arguments:
            s: The bytes to write to the stream.

        Returns:
            The actual number of bytes written to the stream. May be from 0 to
            the number of bytes in `s`.
        """
        self._content.value += bytes(s)
        return len(s)

    def readable(self) -> bool:
        return False

    def writable(self) -> bool:
        return True

    def seekable(self) -> bool:
        return False

    @property
    def closed(self) -> bool:
        return False


def list_files(directory: DirectoryPath) -> Iterable[FilePath]:
    """list_files(directory: DirectoryPath) -> Iterable[FilePath]

    Return an iterable of files contained in the specified directory.
    Note that the absolute paths of the files are returned (i.e. they
    *include* `directory` in their paths).

    Args:
        directory: The path of the directory to list files within.

    Returns:
        An iterable of the absolute paths of all files contained in `directory`.

    Raises:
        FileNotFoundError: `directory` does not exist.
        PermissionError: The system denied the process permission to access
            `directory`.

    Example::

        >>> for file in list_files(DirectoryPath('/usr/lib')):
        ...     print(file)
        ...
        /usr/lib/liba.dylib
        /usr/lib/libb.dylib
        etc...
    """
    dir = _find(directory)
    if (dir is not None) and isinstance(dir, dict):
        for name, value in dir.items():
            if isinstance(value, _Content):
                yield name
    else:
        raise FileNotFoundError


def list_directories(directory: DirectoryPath) -> Iterable[DirectoryPath]:
    """list_directories(directory: DirectoryPath) -> Iterable[DirectoryPath]

    Return an iterable of the subdirectories contained in the specified
    directory. Note that the absolute paths of the subdirectories are returned
    (i.e. they *include* `directory` in their paths).

    Args:
        directory: The path of the directory to list directories within.

    Returns:
        An iterable of the absolute paths of all directories contained in
        `directory`.

    Raises:
        FileNotFoundError: `directory` does not exist.
        PermissionError: The system denied the process permission to access
            `directory`.

    Example::

        >>> for directory in list_directories(DirectoryPath('/opt')):
        ...     print(directory)
        ...
        /opt/X11
        /opt/jc
        etc...
    """
    dir = _find(directory)
    if (dir is not None) and isinstance(dir, dict):
        for name, value in dir.items():
            if isinstance(value, dict):
                yield name
    else:
        raise FileNotFoundError


def read_file(file_path: FilePath):
    """read_file(file_path: FilePath) -> ContextManager[BinaryInput]

    Return a context-managed, read-only binary stream that reads data from the
    specified file.

    Args:
        file_path: The absolute path of a file on the local file system.

    Raises:
        FileNotFoundError: `file_path` does not exist.
        PermissionError: The system denied the process permission to open
            `file_path` for reading.

    Example::

        with read_file(FilePath('/path/to/my-file')) as fin:
            my_file_data = fin.read()
    """
    f = _find(file_path)
    if f is not None:
        if isinstance(f, _Content):
            return _MemoryReader(f.value)
        else:
            raise FileNotFoundError
    else:
        raise FileNotFoundError


def file_size(file_path: FilePath) -> SizeBytes:
    """file_size(file_path: FilePath) -> SizeBytes

    Return the size of the specified file, in bytes.

    Args:
        file_path: The absolute path of a file on the local file system.

    Raises:
        FileNotFoundError: `file_path` does not exist.
        PermissionError: The system denied the process permission to access
            `file_path`.

    Example::

        >>> path = FilePath('/path/to/my-file')
        >>> print(file_size(path))
        1250124
    """
    f = _find(file_path)
    if f is not None:
        if isinstance(f, _Content):
            return SizeBytes(len(f.value))
        else:
            raise FileNotFoundError
    else:
        raise FileNotFoundError


def last_modified(file_path: FilePath) -> LastModified:
    """last_modified(file_path: FilePath) -> LastModified

    Return the last modified or updated property of the specified file, as a timezone aware datetime
    This will always be the current datetime

    Args:
        file_path: The absolute path of a file on the local file system.

    Raises:
        FileNotFoundError: `file_path` does not exist.
        PermissionError: The system denied the process permission to access
            `file_path`.

    Example::

        >>> path = FilePath('/path/to/my-file')
        >>> print(last_modified(path))
        2020-06-11 02:48:14+00:00
    """
    f = _find(file_path)
    if f is not None:
        if isinstance(f, _Content):
            return LastModified(datetime.now(tz=timezone.utc))
        else:
            raise FileNotFoundError
    else:
        raise FileNotFoundError


def write_file(file_path: FilePath):
    """write_file(file_path: FilePath) -> ContextManager[BinaryOutput]

    Return a context-managed, write-only binary stream that writes data to the
    specified file. Note that if the specified file already exists, it will be
    overwritten.

    Args:
        file_path: The absolute path of a file on the local file system.

    Raises:
        PermissionError: The system denied the process permission to open
            `file_path` for writing.

    Example::

        with write_file(FilePath('/path/to/my-file')) as fout:
            fout.write(b'Some data')
            fout.write(b'Some more data')
    """
    f = _find(file_path, create=True)
    assert isinstance(f, _Content)
    return _MemoryWriter(f)


def join(parent: DirectoryPath, child: FSEntity) -> FSEntity:
    """Join a child path to a parent directory

    :param DirectoryPath parent: parent dir to from the base the child is relative to
    :param FSEntity child: child to add on
    :return: composite path
    """
    if child.startswith('/'):
        return child
    else:
        return parent + "/" + child     # type: ignore


def isfile(path: str) -> bool:
    """Determine iof a path string refers to a file

    :param path: path to test
    :return: True if the path exists and is a file

    Raises:
        FileNotFoundError: One or more entities that are part of the
            `path` do not exist.
    """
    entity = _find(path)    #  type: ignore
    if entity is not None:
        if isinstance(entity, dict):
            return False
        else:
            return True
    else:
        raise FileNotFoundError


def delete(path: str):
    """Delete (recursively) a file or directory

    :param path: path to delete
    :raise `FileNotFoundError` if the entity does not exist
    """
    def _remove(p):
        _find(p, remove=True)

    if isfile(path):
        _remove(path)
    else:
        to_remove = []
        for d in list_directories(DirectoryPath(path)):
            to_remove.append(path + '/' + d)
        for f in list_files(DirectoryPath(path)):
            to_remove.append(path + '/' + f)
        for r in to_remove:
            delete(r)
        _remove(path)


def get_normalized_name(name: FSEntity):
    """
    Get normalized name of a file or directory
    :param name: Path to normalize
    :return: Normalized name
    """
    return name


def reset_memory_filesystem():
    """Clear the filesystem down to an empty root directory

    """
    global _root
    _root = {}


"""The memory filesystem as a :class:`FileSystem`
"""
memory_filesystem = FileSystem(memory_filesystem_type,
                               read_file,
                               write_file,
                               file_size,
                               last_modified,
                               list_files,
                               list_directories,
                               join,
                               isfile,
                               delete,
                               get_normalized_name)


def memory_entity_locater(path: str) -> FSLocater:
    return FSLocater(memory_filesystem, path)    # type: ignore
