"""
Shared functions
"""
import re
import os
import sys
import json
import inspect
import hashlib
import pandas as pd

from pathlib import Path
from typing import List, Union, Any, Callable, Iterable
from functools import reduce
from pandas.util import hash_pandas_object
from certifai.common.utils import get_logger, get_config


log = get_logger()


def get_module_members(name=None):
    if name is None:
        name = __name__
    return inspect.getmembers(sys.modules[name], inspect.isclass)


def get_modules(name=None):
    if name is None:
        name = __name__
    return sys.modules[name]


def normalize_to_header(col: Union[str, int], df: pd.DataFrame):
    """ Normalize a column identifier to be a header

    :param col: header name or index
    :param df: dataframe containing column
    :return: The name of the column or None
    """
    if col is None:
        return None
    elif col in df.columns:
        return col
    elif isinstance(col, str) and col.isdecimal() and (int(col) < len(df.columns)):
        return df.columns[int(col)]
    elif isinstance(col, int) and (col < len(df.columns)):
        return df.columns[col]
    else:
        log.info(f"Couldn't find column by label as index: `{col}`, in df.columns: `{df.columns}`.")
        return None


def get_column_indexes(cols: Iterable[Union[str, int]], df: pd.DataFrame, allow_partial: bool=True) -> List[int]:
    result = []
    for col in cols:
        try:
            idx = df.columns.get_loc(normalize_to_header(col, df))
            result.append(idx)
        except KeyError:
            if not allow_partial:
                raise
    return result


def drop_columns_by_label_or_index(columns_to_drop, df, inplace=True):
    """Drop (and extract the contents of) one or more columns

    :param columns_to_drop: iterable of column designators (may be header names or indexes)
    :param df: dataframe to drop/extract from
    :return: The values of the dropped columns as a list directly corresponding to the input list

    Notes:
      * The input list may contain `None` instances, in which case the corresponding output will be `None`
      * If a column cannot be dropped (not present) the corresponding output wil be `None`
    """
    # First normalize all column identifiers to headers
    # This is necessary or else out of (reverse) order numeric
    # designations (or mixed numeric and non-numeric) might not drop
    # the correct columns since dropping the first changes the numeric
    # index of the latter columns
    dropped_headers = [normalize_to_header(col, df) for col in columns_to_drop]
    col_values = []
    for col in dropped_headers:
        if col is not None:
            col_values.append(df[col].values) # to_numpy() <- not available in Pandas <= v0.23.4
            if inplace:
                df.drop(col, axis=1, inplace=True)
            else:
                df = df.drop(col, axis=1)
        else:
            col_values.append(None)

    return df, col_values


def apply_transform(obj: Any, transform: Union[Callable,List[Callable]]=None) -> Any:
    """
    Applies the specified transform to 'obj'. If the transform is a list
    of callables, they are applied in order or apperance. The original object
    is returned if the transform is not callable or not a list of callables.
    """
    if callable(transform):
        obj = transform(obj)
    elif isinstance(transform, list):
        obj = reduce(lambda value, t: t(value) if callable(t) else value, transform, obj)
    return obj

def get_pandas_md5_hash(df: pd.DataFrame) -> str:
    """
    Creates an md5 hash digest for historical and comparison / archival purposes.
    The hash is created using the pandas dataframe's values and index.
    The dataframe is used instead of a file to simplify cases of files that
    are hosted on "the Cloud" (i.e.: not a local-system file).
    https://pandas.pydata.org/pandas-docs/stable/reference/api/pandas.util.hash_pandas_object.html
    https://github.com/pandas-dev/pandas/blob/cce0b37/pandas/core/util/hashing.py#L57
    """
    return hashlib.md5(hash_pandas_object(df).values).hexdigest()


def get_local_file_md5_hash(filename: str) -> str:
    """
    Creates an md5 hash digest for historical and comparison / archival purposes.
    """
    hash_md5 = hashlib.md5()
    with open(filename, "rb") as f:
        for chunk in iter(lambda: f.read(4096), b""):
            hash_md5.update(chunk)
    return hash_md5.hexdigest()


def to_snake_case(str):
    return ''.join(['_'+i.lower() if i.isupper() else i for i in str]).lstrip('_')


def to_camel_case(name):
    if '_' in name:
        name = "".join(p[0].upper() + p[1:] for p in name.split('_') )
    else:
        name = name[0].upper() + name[1:]
    return name


def to_field_name(k):
    """ Must be valid Python variable names """
    single_digits = ["zero", "one", "two", "three",
                     "four", "five", "six", "seven",
                     "eight", "nine"]
    if k[0].isdecimal():
        k = single_digits[int(k[0])] + '_' + k[1:]
    return re.sub(r'\W+', '', k.replace(' ', '_').lower())


def load_json_file(filename: str) -> dict:
    with open(filename, 'r') as f:
        return json.load(f)


def enum_values(enum):
    """Returns a list of values for the specified enum."""
    return [e.value for e in enum]


def filter_scanner_reports(filenames, scan_id=''):
    return [f for f in filenames if f.startswith(f"certifai-scan-{scan_id}") and f.endswith(".json")]


def allowed_file(filename, extensions=('json', 'csv')):
    """ a dot '.' at the start of the extension is optional """
    name_without_ext = filename
    for ext in extensions:  # remove extension with and without dot
        name_without_ext = name_without_ext.replace(f".{ext}", '').replace(ext, '')
    ext_only = filename.replace(name_without_ext+'.', '').replace(name_without_ext, '')
    return (
        '.' in filename
        and ext_only in extensions
        and len(name_without_ext) > 0
    )


def get_db_file_path(config_section: str) -> str:
    """
    :param config_section: name of [section] in default_certifai_config.ini
    :return: DB file with path.
    """
    db_file_path = get_config('db_file_dir', config_section, dtype='path') + get_config('db_file_name', config_section)
    log.debug(f'db_file_path: {db_file_path}')
    # create if not exists
    if not os.path.isfile(db_file_path):
        os.makedirs(get_config('db_file_dir', config_section, dtype='path'), exist_ok=True)
        Path(db_file_path).touch(mode=0o740, exist_ok=True)
    return db_file_path


def ensure_folder_exists(folder):
    if not os.path.exists(folder):
        log.debug(f'Creating folder: {folder}')
        os.makedirs(folder, exist_ok=True)
