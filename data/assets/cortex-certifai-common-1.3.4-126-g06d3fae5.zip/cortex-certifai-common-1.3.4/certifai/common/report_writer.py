"""
Interface for writing report files
"""
from typing import Optional
from abc import ABC, abstractmethod

class ReportWriter(ABC):
    """Interface for writing report files"""

    @abstractmethod
    def write_report(self, report: dict):
        ...

    @property
    @abstractmethod
    def report_location(self) -> Optional[str]:
        ...
