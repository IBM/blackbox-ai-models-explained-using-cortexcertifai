"""
Common code for reading datasets.
"""
import pandas as pd
from certifai.common.types import FileTypeEnum
from certifai.common.helpers import get_pandas_md5_hash
from certifai.common.errors import CertifaiException
from certifai.common.file.locaters import make_generic_locater


def _read_csv(source: str, **kwargs):
    locater = make_generic_locater(source)
    with locater.reader() as f:
        return pd.read_csv(f, **kwargs)


def _read_json(source: str, **kwargs):
    locater = make_generic_locater(source)
    with locater.reader() as f:
        return pd.read_json(f, **kwargs)


def read_dataset(source: str, filetype: str, **kwargs):
    """
    * Reads the dataframe corresponding to the specified dataset source and filetype.
    * Creates an md5 hash of the dataframe that is read - the checksum is computed prior to applying
      limit' in the specified kwargs.
    :param source: dataset set (either a url or path)
    :param filetype: The type of dataset to read (csv or json)
    :param kwargs: keyword arguments (delimiter, encoding, escape_character, quote_character,
                   has_header, lines, orient, limit)
    :return: dataframe, checksum value, and checksum type (pd.Dataframe, string, string)
    """
    if filetype == FileTypeEnum.csv:
        pd_read_function = _read_csv
        read_kwargs = {
            'delimiter': kwargs.get('delimiter', ','),
            'encoding': kwargs.get('encoding'),
            'escapechar': kwargs.get('escape_character'),
            'quotechar': kwargs.get('quote_character', '"'),
            'header': 'infer' if kwargs.get('has_header') else None,
            'nrows': kwargs.get('limit'),
        }

    elif filetype == FileTypeEnum.json:
        pd_read_function = _read_json
        read_kwargs = {
            'lines': kwargs.get('lines', True),
            'orient': kwargs.get('orient', 'records'),
            'encoding': kwargs.get('encoding')
        }
    else:
        raise CertifaiException(f"Unknown FileType '{filetype}'- cannot read dataset")

    # read dataset and create checksum
    df = pd_read_function(source, **read_kwargs)
    checksum = get_pandas_md5_hash(df)
    checksum_type = 'md5'

    # truncate if limit set, for the read_json case (no nrows param)
    limit = kwargs.get('limit')
    if limit is not None and len(df) > limit:
        df = df[:limit]

    return df, checksum, checksum_type
