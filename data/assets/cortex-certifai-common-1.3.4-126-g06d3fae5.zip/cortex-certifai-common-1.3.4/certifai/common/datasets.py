"""
Common utils for reading datasets
"""
import os
import pandas as pd

from certifai.common.utils import get_logger, get_api_config
from certifai.common.types import FileTypeEnum, JsonStyleEnum

log = get_logger()

DATASET_FILE_SAVE_FOLDER = get_api_config('dataset_dir', dtype='path')
log.debug(f'DATASET_FILE_SAVE_FOLDER: {DATASET_FILE_SAVE_FOLDER}')
if not os.path.exists(DATASET_FILE_SAVE_FOLDER):
    os.makedirs(DATASET_FILE_SAVE_FOLDER, exist_ok=True)


def read_dataset_data(dataset, dataset_file, limit=None):
    dataset_file_path = os.path.join(DATASET_FILE_SAVE_FOLDER, dataset_file.virtual_filename)

    if dataset.file_type is FileTypeEnum.csv:
        pd_read_function = pd.read_csv
        read_kwargs = {
            'delimiter': dataset.delimiter if dataset.delimiter else ',',
            'header': 'infer' if dataset.has_header else None,
            'encoding': dataset.encoding.value if dataset.encoding else None,
            'escapechar': dataset.escape_character,
            'quotechar': dataset.quote_character if dataset.quote_character else '"',
            'nrows': limit,
        }

    else:
        pd_read_function = pd.read_json
        read_kwargs = {
            'lines': True if dataset.json_style is JsonStyleEnum.lines else False,
            'encoding': dataset.encoding.value if dataset.encoding else None,
            # 'index': <- use?
        }

    dataset_data_df = pd_read_function(dataset_file_path, **read_kwargs)

    # truncate if limit set, for the read_json case (no nrows param)
    if limit is not None and len(dataset_data_df) > limit:
        dataset_data_df = dataset_data_df[:limit]

    return dataset_data_df
