import os
import json
from typing import Union, Dict, List, Optional
import contextlib
import random
import shutil
import string
import tempfile
from hypothesis.strategies import SearchStrategy, text


alphanumeric_strings: SearchStrategy[str] = text(
    alphabet = string.ascii_letters + string.digits,
    min_size = 1,
    max_size = 128
)


@contextlib.contextmanager
def temporary_file(name    : Optional[str  ] = None,
                   contents: Optional[bytes] = None,
                   root_dir: Optional[str  ] = None):
    """Create a temporary file within a context-managed environment.

    Args:
        name: The name to give the temporary file. If unspecified, a random
            name of 8 alphanumeric characters is generated. File name must be
            relative, but may contain directories, which will be created if
            they do not already exist. The full path to the temporary file is
            constructed using the relative `name` and the `root_dir`.
        contents: The contents of the temporary file. If unspecified, the file
            is filled with 256 random bytes.
        root_dir: The directory to create temporary files in. If unspecified, a
            system-provided temporary directory is used.

    Returns:
        A context manager that yields the absolute path to the temporary file.

    The temporary file is automatically deleted when the context manager
    returned by this function is exited.

    Example::

        with temporary_file() as file_name:
            assert os.path.exists (file_name)
            assert os.path.isfile (file_name)
            assert os.path.getsize(file_name) == 256

        assert not os.path.exists(file_name)
    """
    t_dir = root_dir or tempfile.tempdir
    assert t_dir is not None
    filepath = os.path.join(
        t_dir,
        name or ''.join(random.sample(string.ascii_lowercase + string.digits, 8))
    )

    filedir = os.path.split(filepath)[0]
    directory_existed = os.path.isdir(filedir)

    if len(filedir) > 0:
        os.makedirs(filedir, exist_ok = True)

    with open(filepath, 'wb') as fout:
        fout.write(
            contents if contents is not None else
            bytes(random.sample(range(256), 256))
        )

    yield filepath

    os.remove(filepath)
    if not directory_existed:
        os.rmdir(filedir)


@contextlib.contextmanager
def temporary_directory(directory: str,
                        mode     : int,
                        exists_ok: bool = True):
    """Create an empty temporary directory within a context-managed environment.

    Args:
        directory: The absolute path of the temporary directory to create.
        mode: Integer describing the permissions for the directory.
            See :obj:`os.chmod` for possible values of `mode`.
        exists_ok: If `True` (the default), then `directory` is deleted and
            re-created if it already exists; otherwise, a pre-existing
            `directory` results in an :obj:`OSError`.

    Returns:
        A context manager within which the temporary directory exists.

    Raises:
        OSError: `exists_ok` is `False` and `directory` already exists. Also
            raised if `directory` exists and contains files.
        FileNotFoundError: One or more parent directories on the path of the
            specified `directory` do not exist.

    The temporary directory is automatically deleted when the context manager
    returned by this function is exited.

    Example::

        with temporary_directory('my_dir', 0o777):
            assert os.path.exists('my_dir')
            assert os.path.isdir ('my_dir')

        assert not os.path.exists('my_dir')
    """
    if os.path.isdir(directory):
        if exists_ok:
            shutil.rmtree(directory)
        else:
            raise OSError(f'Directory "{directory}" already exists')
    os.mkdir(directory, mode = mode)
    yield
    os.rmdir(directory)


def remove_keys(d: Union[Dict, List], keys: List) -> Union[Dict, List]:
    """
    Removes keys (including nested keys) from a dictionary or list of dictionaries.
    :param d: dictionary or list of dictionaries
    :param keys: list of keys to remove
    :return: the input objet with the specified keys removed
    """
    if type(d) == list:
      return [remove_keys(i, keys) for i in d]
    elif type(d) == dict:
      dcopy = d.copy()  # Skip DictionaryHasChanged error
      for k in dcopy.keys():
          if k in keys:
              del d[k]
          elif type(dcopy[k]) in [dict, list]:
              d[k] = remove_keys(d[k], keys)
      return d
    else:
      return d


def load_json_file(filename: str) -> dict:
    with open(filename, 'r') as fixture:
        return json.load(fixture)


def load_json_fixture(fixture_path: str, name: str, ignore_keys: List=None):
    """
    Loads a json fixture from the path '<fixture_path>/<name>'.
    :param fixture_path: path to fixtures
    :param name: name of the fixture file to read
    :param ignore_keys: keys to ignore from the fixture
    """
    with open(os.path.join(fixture_path, name), 'r') as fixture:
        if ignore_keys is None:
          return json.load(fixture)
        else:
          return remove_keys(json.load(fixture), ignore_keys)


def compare_dicts(d1: Union[dict,list],
                  d2: Union[dict,list],
                  path: str='',
                  first_is_subset: bool=True,
                  round_decimals: int=-1) -> bool:
    """
    Checks if two dictionaries match or reports first difference.
    :param d1: First dict or list to compare
    :param d2: Second dict or list to compare
    :param path: Dict key tree path
    :param first_is_subset: whether to check if first dict is a subset of the second (not vice versa), default True
    :param round_decimals: Number of decimals to round a FLOAT to.
    :return: True if all fields are equal or match (floats rounded or not), False otherwise.
    """

    if isinstance(d1, list):
        if not isinstance(d2, list):
            print(f"Unexpected non-list in second at {path}")
            return False
        if len(d1) != len(d2):
            print(f"Unexpected differing array lengths at {path}")
            return False
        for idx, (e1, e2) in enumerate(zip(d1, d2)):
            if not compare_dicts(e1, e2, path + f"[{idx}]", round_decimals=round_decimals, first_is_subset=first_is_subset):
                return False
    elif isinstance(d1, dict):
        if not isinstance(d2, dict):
            print(f"Unexpected non-dict in second at {path}")
            return False
        for key in d1:
            if key not in d2:
                print(f"Missing key {key} in second at {path}")
                return False
            if not compare_dicts(d1[key], d2[key], path + "/" + str(key), round_decimals=round_decimals, first_is_subset=first_is_subset):
                return False
        if not first_is_subset:
            for key in d2:
                if key not in d1:
                    print(f"Missing key {key} in first at {path}")
                    return False
    elif d1 != d2:
        # if type is float, only compare specified number of decimals
        if round_decimals >= 0 and type(d1) == float and type(d2) == float:
            matches = round(d1, round_decimals) == round(d2, round_decimals)
            if not matches:
                print(f"Value mismatch (to {round_decimals} decimals) at {path}: {str(d1)} vs {str(d2)}")
            return matches
        else:
            print(f"Value mismatch at {path}: {str(d1)} vs {str(d2)}")
            return False

    return True
