"""
Distinct exceptions used by Certifai to convey failures
"""
from typing import Any


class CertifaiException(Exception):
    """Wrapper for error conditions that are fatal to Certifai run"""
    pass


class CertifaiUnexpectedException(CertifaiException):
    """Specific wrapper for totally unexpected failures"""
    def __init__(self, e: Exception):
        super().__init__(f"Unexpected exception running counterfactual analysis: {str(e)}")


class CertifaiFormatException(CertifaiException):
    """Specific wrapper for badly formatted data"""
    def __init__(self, feature_name: str, feature_type: str, value: Any):
        super().__init__(f"Badly formatted data for feature {feature_name} (type: {feature_type}, value: {value})")


class CertifaiUnknownLabel(CertifaiException):
    """Specific wrapper for totally unexpected failures"""
    def __init__(self, label: Any):
        super().__init__(f"Unknown label value: {str(label)} encountered")


class CertifaiNoCounterfactual(CertifaiException):
    def __init__(self):
        super().__init__("No counterfactual found")


class CertifaiRestrictionError(CertifaiException):
    def __init__(self, feature_name):
        super().__init__(f"Counterfactual's constant feature '{feature_name}' is different than that of target datapoint")


class CertifaiValidationException(CertifaiException):
    def __init__(self, context: str, errors: list):
        error_messages = ', '.join([str(e) for e in errors])
        super().__init__(f"Validation errors found, {context}: {error_messages}")


class CertifaiCancelledException(CertifaiException):
    def __init__(self):
        super().__init__("Certifai analysis cancelled before completion")


class CertifaiUnknownMetricException(CertifaiException):
    def __init__(self, name: str):
        super().__init__(f"Unknown metric '{name}'")


class CertifaiMetricSpecifierException(CertifaiException):
    def __init__(self, specifier: str, details: str):
        super().__init__(f"Bad metric specifier '{specifier}': {details}")


class CertifaiTimeEstimateException(CertifaiException):
    """Specific wrapper for exceptions that occur while estimating the amount time a scan will take"""
    def __init__(self, msg: str):
        super().__init__(msg)
