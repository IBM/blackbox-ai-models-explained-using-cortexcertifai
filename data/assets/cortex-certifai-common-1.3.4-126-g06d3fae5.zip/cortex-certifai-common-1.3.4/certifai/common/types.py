"""
Types shared accross modules
"""
import enum


class JsonStyleEnum(str, enum.Enum):
    __catalog_name__ = 'dataset_json_style'
    object = 'object'
    lines = 'lines'

## NOTE: The API only supports the default orient of 'columns', scanner supports all of the below
class JsonOrientEnum(str, enum.Enum):
    __catalog_name__ = 'dataset_json_orients'
    records = 'records'
    columns = 'columns'
    values = 'values'

class FileTypeEnum(str, enum.Enum):
    __catalog_name__ = 'dataset_file_type'
    csv = 'csv'
    json = 'json'

class DataTypeEnum(str, enum.Enum):
    __catalog_name__ = 'dataset_data_type'
    categorical = 'categorical'
    numerical_int = 'numerical-int'
    numerical_float = 'numerical-float'

class EncodingEnum(str, enum.Enum):
    __catalog_name__ = 'dataset_encoding'
    ascii = 'ascii'
    utf_16 = 'utf-16'
    utf_16_be = 'utf-16-be'
    utf_16_le = 'utf-16-le'
    utf_32 = 'utf-32'
    utf_32_be = 'utf-32-be'
    utf_32_le = 'utf-32-le'
    utf_7 = 'utf-7'
    utf_8 = 'utf-8'
    utf_8_sig = 'utf-8-sig'
    latin_1 = 'latin-1'
    iso_8859_1 = 'iso-8859-1'
    windows_1252 = 'windows-1252'

class RestrictionStringEnum(str, enum.Enum):
    __catalog_name__ = 'dataset_restriction_string'
    no_restrictions = 'no restrictions'
    no_changes = 'no changes'
    min_max = 'min/max'
    percentage = '+-%'

class ModelTypeEnum(str, enum.Enum):
    __catalog_name__ = 'model_type'
    multiclass_classification = 'multiclass-classification'
    binary_classification = 'binary-classification'
    classification = 'classification' # compatibility with previous DB
    regression = 'regression'

class EvaluationTypeEnum(str, enum.Enum):
    __catalog_name__ = 'evaluation_type'
    robustness = 'robustness'
    fairness = 'fairness'
    explainability = 'explainability'
    explanation = 'explanation'
    performance = 'performance'

class ExplanationTypeEnum(str, enum.Enum):
    __catalog_name__ = 'explanation_type'
    counterfactual = 'counterfactual'
    shap = 'shap'

class AtxComponentsEnum(str, enum.Enum):
    __catalog_name__ = 'atx_components'
    robustness = 'robustness'
    fairness = 'fairness'
    explainability = 'explainability'
    performance = 'performance'

class FeatureTypeEnum(str, enum.Enum):
    CAT = 'CAT'        # categorical feature, previously known as 'STR'
    INT = 'INT'        # numerical int feature
    FLOAT = 'FLOAT'    # numerical float feature

    @staticmethod
    def is_numeric(feature_type):
        return feature_type == FeatureTypeEnum.INT or feature_type == FeatureTypeEnum.FLOAT

    @staticmethod
    def is_categorical(feature_type):
        return feature_type == FeatureTypeEnum.CAT

class ModelHeaderTypeEnum(str, enum.Enum):
    DEFAULT = 'default'
    DEFINED = 'defined'

class PredictionFavorabilityEnum(str, enum.Enum):
    ordered = 'ordered'   # equiv. to 'ordered' for multiclass-classification
    explicit = 'explicit' # equiv. to 'partitioned' for multiclass-classification
    none = 'none'         # equiv. to 'unordered' for multiclass-classification

class RegressionOutcomeValueEnum(str, enum.Enum):
    """
    Represents possible outcome values for regression task types - e.g. the counterfactual either
    caused an increase or decrease.
    """
    increased = 'increased'
    decreased = 'decreased'

class ScanStatusEnum(str, enum.Enum):
    failed = 'Failed'
    completed = 'Completed'


class RegressionBoundaryTypeEnum(str, enum.Enum):
    absolute = 'Absolute'
    relative = 'Relative'
