from typing import List

import numpy as np


# Pickle-able class callable to remove specified features by column index
class FeatureDrop:
    def __init__(self, dropped_features: List[int], num_features: int):
        self._model_features = np.array([idx for idx in range(num_features) if idx not in dropped_features])

    def __call__(self, X):
        if not isinstance(X, np.ndarray):
            X = np.array(X)
        return X[:, self._model_features]
