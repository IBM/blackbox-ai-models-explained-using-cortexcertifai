"""Utilities for timing functions and code blocks in a non-intrusive manner.
"""

import contextlib
from datetime import datetime


# Stats are a tuple of call-count and total time (in ms)
class TimerStats():
    def __init__(self, call_count: int, total_time: int):
        self._call_count = call_count
        self._total_time = total_time

    @property
    def call_count(self) -> int:
        return self._call_count
    
    @property
    def total_time(self) -> int:
        return self._total_time

    def plus(self, other: 'TimerStats'):
        return TimerStats(self.call_count + other.call_count,
                          self.total_time + other.total_time)

    def diff(self, other: 'TimerStats'):
        return TimerStats(self.call_count - other.call_count,
                          self.total_time - other.total_time)

    def __str__(self):
        return f"{self.total_time}ms for {self.call_count} calls"

    @staticmethod
    def empty():
        return TimerStats(0, 0)


def _timedelta_micros(td):
    return int(td.total_seconds()*1000000)


class TimeAggregate:
    def __init__(self, name: str, time_on_exception=False):
        self.name = name
        self.time_on_exception = time_on_exception
        self.reset()

    def __str__(self):
        return "Total time in '{}' was {} micro seconds for {} calls".format(self.name, self.total_time, self.call_count)

    def reset(self):
        self.total_time = 0
        self.call_count = 0

    @property
    def stats(self) -> TimerStats:
        return TimerStats(self.call_count, self.total_time/1000)

    @contextlib.contextmanager
    def __call__(self, *args, **kwargs):
        self.call_count += 1
        start_time = datetime.now()
        try:
            yield
        except Exception as e:
            if self.time_on_exception:
                self.total_time += _timedelta_micros(datetime.now() - start_time)
            raise e

        end_time = datetime.now()
        self.total_time += _timedelta_micros(end_time - start_time)


