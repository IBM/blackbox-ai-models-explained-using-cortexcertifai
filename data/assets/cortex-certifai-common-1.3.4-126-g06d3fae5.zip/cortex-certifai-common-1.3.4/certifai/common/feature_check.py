"""
Module for storing whether certain Certifai features are in beta or are fully supported.
"""
from certifai.common.utils import get_config
from certifai.common.errors import CertifaiException


class Feature:
    def __init__(self, name: str, config_section: str, config_key: str, is_beta: bool):
        self._name = name
        self._key = config_key
        self._section = config_section
        self._is_beta = is_beta

    @property
    def name(self):
        return self._name

    @property
    def config_section(self):
        return self._section

    @property
    def config_key(self):
        return self._key

    @property
    def is_beta(self):
        return self._is_beta

    @property
    def is_config_enabled(self):
        return get_config(self.config_key, self.config_section, dtype='bool', default=False)

    @property
    def is_enabled(self):
        return not self.is_beta or self.is_config_enabled


_FEATURES = {}


# outer facing API


def register_features(feature_map):
    global _FEATURES
    _FEATURES.update(feature_map)


def is_feature_enabled(feature_id: str) -> bool:
    """
    Checks whether the specified feature is enabled.
    :param feature_id: Id of feature to check
    :return: True if the feature is enabled, False otherwise
    """
    f = _FEATURES.get(feature_id)
    if f is None:
        raise ValueError(f"Unknown feature id {feature_id}")
    return f.is_enabled

def raise_for_disabled_beta_feature(feature_id: str):
    """
    Checks whether the specified feature is enabled and raise a CertifaiException if the feature is not enabled.
    :param feature_id: Id of feature check
    """
    if not is_feature_enabled(feature_id):
        f = _FEATURES.get(feature_id)
        raise CertifaiException(f"Unsupported feature: {f.name} is only supported as beta feature. " \
                                f"Set '{f.config_section}.{f.config_key}' to true in your Certifai config to enble {f.name}")
