"""
Classes and utilities related to progress reporting
"""
import datetime
from abc import ABC, abstractmethod
from typing import Callable, Optional, List, NamedTuple, Any
import numpy as np


class ProgressUpdate(NamedTuple):
    units_complete: int
    total_num_units: int
    summary: str

    @property
    def percent(self):
        if self == NULL_PROGRESS:
            return 0.0
        return self.units_complete / self.total_num_units

    def to_dict(self) -> dict:
        return dict(self._asdict()) # _asdict() alone returns an OrderedDict (of tuples)


ProgressListener = Callable[[ProgressUpdate], None]
NULL_PROGRESS = ProgressUpdate(0, 0, "Unknown progress")

class ProgressBarListener:
    def __init__(self,
                 progress_bar_len: int = 20,
                 progress_char: str = '#',
                 base_char: str = '-',
                 output_fn: Optional[Callable[[str], None]] = None,
                 task: Optional[str] = ''):
        """
        :param progress_bar_len: length of the progress bar, default 20
        :param progress_char: optional character for the amount of finished work in the progress bar, default '#'
        :param base_char: optional character for the the amount of not-finished work in the progress bar, default '-'
        :param output_fn: optional function to receive the output strings from each update, defaults to print()
        :param task: optional description of what is being completed (e.g. 'reports' or 'checks')
        """
        self.progress_bar_len = progress_bar_len
        self.progress_char = progress_char
        self.base_char = base_char
        self.task = task
        self.__first = True

        if output_fn is None:
            self.__output_fn = print
        else:
            self.__output_fn = output_fn

    def __call__(self, update: ProgressUpdate):
        """
        Creates a string message from the ProgressUpdate  and passes said message to the output function. The
        first call will only pass the given ProgressUpdate's summary and subsequential calls will include a
        progress bar.

        :param update: ProgressUpdate object
        """
        # only print summary for the first update (ignore progress bar)
        if self.__first:
            self.__first = False
            self.__output_fn(update.summary)
            return

        num_progress_char = int(update.percent * self.progress_bar_len)
        num_base_char = self.progress_bar_len - num_progress_char
        progress_bar_str = (self.progress_char * num_progress_char) + (self.base_char * num_base_char)
        msg = f"{datetime.datetime.now()} - {update.units_complete} of {update.total_num_units} {self.task} ({round(update.percent * 100, 2)}% complete) - {update.summary}"
        self.__output_fn('[{0}] {1}'.format(progress_bar_str, msg))


class AbstractTask(ABC):
    """
    Abstract class for encapsulating a progress moniterable task.
    """

    @abstractmethod
    def run(self, callback: ProgressListener) -> Optional[Any]:
        """Runs the task"""
        ...

    @abstractmethod
    def attach(self, callback: ProgressListener):
        """Attaches the given callback to the already running task"""
        ...

    @abstractmethod
    def estimate(self) -> int:
        """Offer an estimate on the number of units of work left for the given task"""
        ...

    @staticmethod
    def compose(tasks: List['AbstractTask']) -> 'AbstractTask':
        """
        Composes multiple tasks into a single task with an overall progress. The given tasks will be run serially, and
        a list will be returned containining values returned by the individual tasks.
        :param tasks: list of tasks to compose
        :return: An AbstractTask
        """
        return _CompositeTask(tasks)


class _CompositeTask(AbstractTask):
    """Wrapper class for composing multiple tasks into a single task."""

    def __init__(self, tasks: List[AbstractTask]):
        self._tasks = tasks
        self._listeners = []

        # list of most recent update from each task - assume none have started
        self._progress_map = [ProgressUpdate(0, t.estimate(), "Task not started") for t in tasks]

    def run(self, callback: ProgressListener):
        results = []
        self._listeners.append(callback)
        for idx, task in enumerate(self._tasks):
            results.append(task.run(self._create_listener(idx)))
        return results

    def attach(self, callback: ProgressListener):
        self._listeners.append(callback)

    def estimate(self) -> int:
        return sum(t.estimate() for t in self._tasks)

    def _create_listener(self, task_idx: int):
        def f(p: ProgressUpdate):
            self._progress_map[task_idx] = p
            update = ProgressUpdate(sum(x.units_complete for x in self._progress_map),
                                    sum(x.total_num_units for x in self._progress_map),
                                    p.summary)

            # iterate over copy of listeners (avoid race conditions w/ `attach()`)
            listeners_copy = self._listeners.copy()
            for listener in listeners_copy:
                listener(update)

        return f
