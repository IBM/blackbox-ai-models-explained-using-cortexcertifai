import re
import os


protocol_regex = re.compile("([a-z0-9]+):.*")

def protocol_from_path(path: str) -> str:
    p_match = re.match(protocol_regex, path)
    if p_match is None:
        return None
    return p_match.group(1)


def extract_protocol_from_path(path: str) -> str:
    if path.startswith('/'):
        path = f'file:{path}'
    return protocol_from_path(path)


def resolve_filepath(base: str, filepath: str, is_file: bool = False):
    """
    Resolves local filepath w.r.t the specified base path.
    :param base: the base path
    :param filepath: filepath to resolve w.r.t the base path
    :param is_file: whether the base path points to a file (True) or directory (False), default False
    :return: Resolved filepath
    """
    def _is_local(path):
        protocol = protocol_from_path(path)
        return protocol is None or protocol == 'file'

    is_base_local = _is_local(base)
    is_filepath_local = _is_local(filepath)
    if is_filepath_local:
        base_abs_path = os.path.abspath(base) if is_base_local else base
        dirname_path = os.path.dirname(base_abs_path) if is_file else base_abs_path
        joined_path = os.path.join(dirname_path, _clean_file_url(filepath))
        if is_base_local:
            return os.path.normpath(os.path.expanduser(joined_path))
        return joined_path
    else:
        # Using absolute (original) value when filepath is not a local filepath
        return filepath


def _clean_file_url(url):
    result = url.replace('file:', '')
    if result.startswith('//'):
        return result[1:]
    else:
        return result


def extract_path_from_fullpath(protocol: str , path: str) -> str:
    """
    Removes protocol and returns the path
    :param protocol: protocol name
    :param path: Path
    :return: Extracted path
    """
    return re.sub(f'{protocol}:/+', '', path)
