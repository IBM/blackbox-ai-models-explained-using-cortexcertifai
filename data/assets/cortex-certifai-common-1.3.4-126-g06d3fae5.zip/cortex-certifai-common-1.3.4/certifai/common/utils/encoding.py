from typing import Dict, List, Optional, Tuple, Union

from sklearn import preprocessing
import scipy.sparse as sparse
from sklearn.preprocessing import StandardScaler, OneHotEncoder
import numpy as np
import pandas as pd


ColName = str
CatValue = str


# Bootstrapping onehot decoder used to get thing initialized
def _decode(cat_columns: List[ColName],
            cat_column_value_names: List[List[Tuple[ColName, CatValue]]],
            data):
    encoded_cat_column_values = {}
    for idx, val_details in enumerate(cat_column_value_names):
        for tc, v in val_details:
            encoded_cat_column_values[tc] = (idx, v)

    num_column_indexes = {}
    one_hot_cat_indexes = {}
    one_hot_values = {}
    decoded_idx = 0
    decoded_columns = []
    logical_col_idxs = {}

    # Build three things:
    # 1. Feature columns for the decoded DataFrame
    # 2. Numeric index mappings
    # 3. Categorical feature and value mappings
    # Note - there is ambiguity in the ordering of the resulting logical dataframe now that we support
    # non-contiguous categoricals.  WLG we choose to position the logical categorical features in the
    # relative ordering of the numerics at the position of the first one-hot column belonging to that feature
    for idx, col in enumerate(data.columns):
        if col in encoded_cat_column_values:
            cat_col_idx = encoded_cat_column_values[col][0]
            if cat_col_idx in logical_col_idxs:
                logical_col_idx = logical_col_idxs[cat_col_idx]
            else:
                logical_col_idxs[cat_col_idx] = decoded_idx
                logical_col_idx = decoded_idx
                decoded_idx += 1
                decoded_columns.append(cat_columns[cat_col_idx])
                one_hot_cat_indexes[logical_col_idx] = []
                one_hot_values[logical_col_idx] = []
            one_hot_cat_indexes[logical_col_idx].append(idx)
            one_hot_values[logical_col_idx].append(encoded_cat_column_values[col][1])
        else:
            num_column_indexes[decoded_idx] = idx
            decoded_idx += 1
            decoded_columns.append(col)

    decoded_dim = decoded_idx

    # Perform the encoding
    x = data.values
    result = np.empty((len(data), decoded_dim), dtype=object)
    num_idxs = list(num_column_indexes.values())
    decoded_num_idxs = list(num_column_indexes.keys())
    result[:, decoded_num_idxs] = x[:, num_idxs]
    for c_idx, oh_idxs in one_hot_cat_indexes.items():
        vals = np.array(one_hot_values[c_idx])
        oh_rows, oh_cols = np.where(x[:, oh_idxs] >= 0.5)
        # Check for invalid encoding of one-hot features
        if (oh_rows.shape[0] != x.shape[0]) or np.any(oh_rows != np.arange(x.shape[0])):
            multi = False
            none = False
            for i in range(x.shape[0]):
                count = np.sum(oh_rows == i)
                if count == 0:
                    none = True
                elif count > 1:
                    multi = True
            if (none and multi):
                reason = ' (0-hot and multi-hot both present)'
            elif none:
                reason = ' (0-hot present)'
            elif multi:
                reason = ' (multi-hot present)'
            else:
                # This last case should not happen
                reason = ''
            raise ValueError(f"Column '{decoded_columns[c_idx]}' has invalid one-hot encoding{reason}")
        pick = vals[oh_cols]
        result[:, c_idx] = pick
    return pd.DataFrame(result, columns=decoded_columns)


class _OneHotEncoder:
    def __init__(self, categories=None, string_equivalence=False):
        self._string_equivalence = string_equivalence
        self._feature_indices = None
        if categories is None:
            self._cat_values = None
            self._cat_encoded = None
            self._feature_names = None
        else:
            self._cat_values = [np.expand_dims(np.array(values), axis=0) for values in categories]
            self._cat_encoded = [np.eye(len(values)) for values in categories]
            self._feature_names = [f'feat_{idx}_{str(v)}' for idx, values in enumerate(categories) for v in values]
            self._setup_repr()

    def fit(self, x: pd.DataFrame):
        self._cat_values = []
        self._feature_names = []
        x_array = x.values
        for idx in range(x_array.shape[1]):
            self._cat_values.append(np.expand_dims(np.unique(x_array[:, idx]), axis=0))
            self._feature_names.extend([f'{x.columns[idx]}_{str(value)}' for value in self._cat_values[idx][0]])
        self._cat_encoded = [np.eye(len(values[0])) for values in self._cat_values]
        self._setup_repr()

    def _setup_repr(self):
        n_values = [cats.shape[1] for cats in self._cat_values[:]]
        n_values = np.array([0] + n_values)
        self._feature_indices = np.cumsum(n_values)
        self._cat_value_maps = []
        for cv in self._cat_values:
            if self._string_equivalence:
                self._cat_value_maps.append({str(v): idx for idx, v in enumerate(cv[0,:])})
            else:
                self._cat_value_maps.append({v: idx for idx, v in enumerate(cv[0,:])})

    def transform(self, x: np.ndarray, ordinal_cats=False) -> np.ndarray:
        n_samples, n_features = x.shape

        if ordinal_cats:
            ordinal_idxs = x.astype(int)
        else:
            ordinals = []
            for idx in range(x.shape[-1]):
                cv = self._cat_value_maps[idx]
                if self._string_equivalence:
                    ordinal_idxs = np.array([cv[str(v)] for v in x[:, idx]])
                else:
                    ordinal_idxs = np.array([cv[v] for v in x[:, idx]])
                ordinals.append(ordinal_idxs)
            ordinal_idxs = np.stack(ordinals, axis=1)

        n_out_dim = self._feature_indices[-1]
        indices = (ordinal_idxs + self._feature_indices[:-1]).ravel()
        row_offsets = (np.arange(n_samples*n_features)/n_features).astype(int)*n_out_dim
        indices += row_offsets
        out = np.zeros(n_samples*n_out_dim)
        out[indices] = 1
        result = out.reshape((n_samples, n_out_dim))
        return result


    def inverse_transform(self, x: np.ndarray) -> np.ndarray:
        decoded_features = []
        idx = 0
        for values in self._cat_values:
            decoded_features.append(values[0, np.where(x[:, idx:idx+values.shape[1]] > .5)[1]])
            idx += values.shape[1]
        result = np.stack(decoded_features, axis=1)
        return result

    def get_feature_names(self, columns):
        return self._feature_names


class CatEncoder:
    def __init__(self,
                 cat_columns: List[str],
                 data: Optional[pd.DataFrame]=None,
                 normalize: bool=True,
                 cat_column_value_names: Optional[List[List[Tuple[ColName, CatValue]]]]=None,
                 data_encoded: bool=False,
                 string_equivalence: bool=True,
                 numeric=None):
        if (cat_column_value_names is None) and data_encoded:
            raise ValueError("Decoding one-hot encoded data requires 'cat_column_value_names' to be specified")

        self.cat_column_value_names = cat_column_value_names
        self.cat_columns = cat_columns
        self.normalize = normalize
        self.data_encoded = data_encoded
        self.string_equivalence = string_equivalence
        self.numeric = numeric
        self.encoder = None
        self._fit = False

        if data is not None:
            self.fit(data)

    def fit(self, data, y=None):
        # Sort on col index
        if self.data_encoded:
            perm = np.argsort([min([data.columns.get_loc(c[0]) for c in cv]) for cv in self.cat_column_value_names])
        else:
            perm = np.argsort([data.columns.get_loc(c) for c in self.cat_columns])
        self.cat_columns = [self.cat_columns[idx] for idx in perm]
        if self.cat_column_value_names is not None:
            self.normalize = False   # No decoded scales available
            self.cat_column_value_names = [self.cat_column_value_names[idx] for idx in perm]

        # If we're starting with already one-hot encoded data canonicalize it back into a value-encoded state
        if self.data_encoded:
            encoded_data = data
            data = _decode(self.cat_columns, self.cat_column_value_names, data)
            self.int_encoded = []
        else:
            encoded_data = None
            self.int_encoded = [idx for idx, dt in enumerate(data.dtypes) if dt == 'int64']

        self.dim = len(data.columns)
        self.columns = np.array([c for c in data.columns])
        self.cat_indexes = [data.columns.get_loc(name) for name in self.cat_columns]
        self.num_indexes = np.array([idx for idx in range(len(data.columns)) if idx not in self.cat_indexes])
        if not self.normalize:
            self.normed_numeric_indexes = None
        elif self.numeric is not None:
            self.normed_numeric_indexes = np.array([idx for idx in self.num_indexes if self.columns[idx] in self.numeric])
            if len(self.normed_numeric_indexes) == 0:
                self.normed_numeric_indexes = None
        else:
            self.normed_numeric_indexes = self.num_indexes if len(self.num_indexes) > 0 else None
        self.num_columns = list(data.columns[self.num_indexes.tolist()])
        self._transformed_column_mappings = []
        self._transformed_num_indexes = []
        self._transformed_normed_indexes = []
        self._transformed_cat_indexes = []
        if len(self.cat_indexes) > 0:
            if self.cat_column_value_names is not None:
                self.encoder = _OneHotEncoder(categories=[[v[1] for v in fv] for fv in self.cat_column_value_names],
                                              string_equivalence=self.string_equivalence)
            else:
                self.encoder = _OneHotEncoder(string_equivalence=self.string_equivalence)
                self.encoder.fit(data[self.cat_columns])
            if self.cat_column_value_names is None:
                all_cat_columns = self.encoder.get_feature_names(self.cat_columns)
                col_values = []
                for col in self.cat_columns:
                    col_values.append([(f, f[len(col)+1:]) for f in all_cat_columns if f.startswith(f"{col}_")])
            else:
                col_values = self.cat_column_value_names
        else:
            self.encoder = None

        for f_idx, col in enumerate(data.columns):
            if col in self.cat_columns:
                if (self.numeric is not None) and (col in self.numeric):
                    raise ValueError(f"Column '{col}' specified as both categorical and numeric")
                idx = self.cat_columns.index(col)
                for tc, v in col_values[idx]:
                    if f_idx in self.int_encoded:
                        v = int(v)
                    index = encoded_data.columns.get_loc(tc) if encoded_data is not None else len(self._transformed_column_mappings)
                    self._transformed_cat_indexes.append(index)
                    self._transformed_column_mappings.append((tc, col, v))
            else:
                index = encoded_data.columns.get_loc(col) if encoded_data is not None else len(self._transformed_column_mappings)
                self._transformed_num_indexes.append(index)
                if (self.numeric is None) or (col in self.numeric):
                    self._transformed_normed_indexes.append(index)
                self._transformed_column_mappings.append((col, col, None))

        if len(self._transformed_num_indexes) > 0:
            self._transformed_num_indexes = np.array(self._transformed_num_indexes)
        if self.normed_numeric_indexes is not None:
            self._transformed_normed_indexes = \
                np.array([self._transformed_num_indexes[idx] for idx, ni in enumerate(self.num_indexes)
                          if ni in self.normed_numeric_indexes])
            self.normalizer = StandardScaler()
            self.normalizer.fit(data.iloc[:, self.normed_numeric_indexes.tolist()].astype(float))
        else:
            self.normalizer = None

        self._fit = True

    def transform(self, x):
        if not self._fit:
            raise ValueError("Attempt to transform with CatEncoder that has not yet been fit")

        if isinstance(x, pd.DataFrame):
            x = x.values
        return self.__call__(x)

    def __call__(self, x, ordinal_cats: bool=False):
        # We need to redistribute the column which involves lots of copying data around in column-oriented
        # manner.  Accordingly ue a Fortran data layout - this is about twice as fast
        result = np.empty((x.shape[0], len(self._transformed_num_indexes)+len(self._transformed_cat_indexes)), order='F')
        if self.num_indexes.shape[0] > 0:
            # Move each contiguous block of numeric columns as a single bulk copy directly into to result array
            start_t = -1
            start_ni = -1
            last_ni = -1
            last_t = -2
            for ni_idx, t_idx in enumerate(self._transformed_num_indexes):
                if last_t != t_idx-1:
                    if start_t > -1:
                        result[:, start_t:last_t+1] = x[:, self.num_indexes[start_ni]:self.num_indexes[last_ni]+1]
                    start_t = t_idx
                    start_ni = ni_idx
                last_t = t_idx
                last_ni = ni_idx
            result[:, start_t:last_t+1] = x[:, self.num_indexes[start_ni]:self.num_indexes[last_ni]+1]
            # normalize anything that needs it
            if self.normed_numeric_indexes is not None:
                result[:, self._transformed_normed_indexes] = self.normalizer.transform(result[:, self._transformed_normed_indexes].astype(float))
        if self.encoder is not None:
            # Copy transformed categoricals into the relevant output columns
            if ordinal_cats and self.data_encoded:
                result[:, self._transformed_cat_indexes] = self.encoder.transform(x[:, self.cat_indexes], ordinal_cats=True)
            else:
                result[:, self._transformed_cat_indexes] = self.encoder.transform(x[:, self.cat_indexes])
        return result

    def decode(self, x):
        result = np.empty((x.shape[0], self.dim), dtype=object, order='F')
        if self.num_indexes.shape[0] > 0:
            result[:, self.num_indexes] = x[:, self._transformed_num_indexes]
            if self.normed_numeric_indexes is not None:
                result[:, self.normed_numeric_indexes] = self.normalizer.inverse_transform(result[:, self.normed_numeric_indexes].astype(float))
        result[:, self.cat_indexes] = self.encoder.inverse_transform(x[:, self._transformed_cat_indexes])
        if len(self.int_encoded) > 0:
            result[:, self.int_encoded] = result[:, self.int_encoded].astype(int)
        return result

    @property
    def transformed_features(self):
        return [c[0] for c in self._transformed_column_mappings]

    @property
    def untransformed_features(self):
        return self.columns

    def cat_indexes_of_feature(self, feature: str) -> Dict[Union[str,int], int]:
        result = {}
        for idx, (tc, c, v) in enumerate(self._transformed_column_mappings):
            if feature == c:
                result[v] = idx
        return result

    def transformed_feature_indexes(self, idx: int) -> List[int]:
        num_idx = -1
        for ni, i in enumerate(self.num_indexes):
            if i == idx:
                num_idx = ni
                break
        if num_idx >= 0:
            return [self._transformed_num_indexes[num_idx]]
        else:
            feature = self.columns[idx]
            return list(self.cat_indexes_of_feature(feature).values())
