import math
import numpy as np
from certifai.common.utils import get_logger
from certifai.common.types import AtxComponentsEnum
from certifai.common.helpers import enum_values

log = get_logger()

DEFAULT_ASPECT_WEIGHTS = { c.value : 1.0 for c in AtxComponentsEnum }

def compute_atx_score(scores_dict, weights_dict=None):
    """
    Computes an ATX score as a weighted average of the specified scoring components.
    Returns None if the average is NaN.
    :param scores_dict: dictionary of scores for atx components, e.g. {'robustness': 75, ...}
    :param weights_dict: dictionary of weights for atx components, e.g. {'robustness': 1.0, ...}
    """
    scores = []
    weights = []

    if weights_dict is None:
        weights_dict = DEFAULT_ASPECT_WEIGHTS.copy()

    for evaluation, score in scores_dict.items():
        if evaluation not in enum_values(AtxComponentsEnum):
            raise ValueError(f"Unknown evaluation type '{evaluation}' when computing atx score")
        if evaluation not in weights_dict:
            default_weight = DEFAULT_ASPECT_WEIGHTS.get(evaluation)
            log.warn(f"ATX weight not specified for '{evaluation}', using default aspect weight {default_weight}")

        weight = weights_dict.get(evaluation, DEFAULT_ASPECT_WEIGHTS.get(evaluation))
        scores.append(score)
        weights.append(weight)

    if len(scores) == 0:
        log.warn("Computing ATX score from empty set of components")

    atx_score = np.ma.average(scores, weights=weights) # nan if weights are all 0
    return atx_score if not math.isnan(atx_score) else 0
