from typing import Iterable, Set, Optional
from abc import ABC, abstractmethod
from certifai.common.utils.utils import generate_uuid

class CollisionResolutionException(Exception):
    """Common error for failing to resolve string collisions"""
    def __init__(self, value, iterations):
        super().__init__(f"Unable to create unique string value from '{value}' after {iterations} attempts")


class CollisionResolver(ABC):
    """Abstract class for resolving string collisions"""
    def __init__(self, max_iterations: int = -1):
        """
        :param max_iterations: Maximum number of attempts to resolve the collision. Default is -1 (no maximum).
        """
        self._max_iterations = max_iterations

    @abstractmethod
    def resolve(self, value: str, history: Iterable[str], limit: int = -1) -> str:
        """
        Resolves a possible string collision.
        :param value: base string
        :param history: collection of strings to avoid
        :param limit: maximum length of the string to be returned, default -1 (no limit)
        :return: a string based on the given value that is not in specified history collection
        """
        ...

    @property
    def max_iterations(self):
        return self._max_iterations

def _max_iterations_reached(n: int, max_iterations: int) -> bool:
    if max_iterations > 0:
        return n > max_iterations
    return False

def _valid_length(s: str, length_limit: int) -> bool:
    if length_limit > 0:
        return len(s) <= length_limit
    return True

class ShorteningResolver(CollisionResolver):
    """Resolves string collisions by removing characters."""
    def __init__(self, max_iterations: int):
        super().__init__(max_iterations)

    def resolve(self, value: str, history: Iterable[str], limit: int = -1) -> str:
        modified_value = value[:limit] if limit > 0 else value # trim to max length

        i = 0
        while not _max_iterations_reached(i, self.max_iterations) and len(modified_value) > 2:
            if modified_value not in history:
                break

            modified_value = modified_value[:-1]
            i += 1

        if modified_value in history:
            raise CollisionResolutionException(value, self.max_iterations)
        return modified_value

class UUIDResolver(CollisionResolver):
    """Resolves string collisions by appending a fixed length substring of a uuid to the value."""
    def __init__(self, max_iterations: int, uuid_length: int):
        super().__init__(max_iterations)
        self._len = uuid_length

    @property
    def uuid_length(self):
        return self._len

    def resolve(self, value: str, history: Iterable[str], limit: int = -1) -> str:
        # trivial case - no need to append a UUID
        if _valid_length(value, limit) and value not in history:
            return value

        # truncate value so uuid can be appended
        projected_length = len(value) + self.uuid_length
        if limit > 0 and projected_length > limit:
            overflow = projected_length - limit
            shortened_value = value[:-overflow]
        else:
            shortened_value = value

        # try appending fixed length substrings of uuid's
        # the check for early termination is at the end to match a do/while structure
        i = 0
        modified_value = shortened_value
        while not _max_iterations_reached(i, self.max_iterations):
            uuid = generate_uuid(self.uuid_length)
            modified_value = shortened_value + uuid
            i += 1
            if modified_value not in history:
                break

        if modified_value in history:
            raise CollisionResolutionException(value, self.max_iterations)
        return modified_value


class CompositeResolver(CollisionResolver):
    """Wrapper for multiple collision resolution strategies."""
    def __init__(self, resolvers: Iterable[CollisionResolver] = None):
        self._resolvers = self._resolvers = list(resolvers) if resolvers is not None else []

    def add_resolver(self, r: CollisionResolver):
        self._resolvers.append(r)

    def remove_resolver(self, index: int) -> CollisionResolver:
        return self._resolvers.pop(index)

    def resolve(self, value: str, history: Iterable[str], limit: int = -1) -> str:
        for r in self._resolvers:
            try:
                return r.resolve(value, history, limit)
            except CollisionResolutionException:
                pass # ignore failure and try to use next resolver
        raise CollisionResolutionException(value, sum(r.max_iterations for r in self._resolvers))


def IncrementalUUIDResolver(max_iterations, max_uuid_length) -> CollisionResolver:
    """
    Factory function for creating a CollisionResolver that tries to append UUID substrings of length 1 to max_uuid_length.
    :param max_iterations: maximum number of attempts for EACH UUIDResolver
    :param max_uuid_length: maxmimum uuid length to try appending
    """
    return CompositeResolver([UUIDResolver(max_iterations, i) for i in range(1, max_uuid_length + 1)])


class NameCreator:
    """Wrapper class for resolving name collisions - store history of resolved strings."""
    def __init__(self, resolver: CollisionResolver, history: Optional[Set[str]] = None):
        """
        :param resolver: CollisionResolver to resolve possible collisions between created names
        :param history: Starting values for history of resolved strings, optional
        """
        self._resolver = resolver
        if history is None:
            self._history =  set() # stores generated names to avoid future ocllisions
        else:
            self._history = set(history)

    def create(self, source: str, length_limit: int = -1) -> str:
        """
        Creates a string value based on the source value, the value will be unique relative to previously created values.
        :param source: source value
        :param length_limit: optional maximum length of the string to generate, default is -1 (no maximum)
        """
        value = self._resolver.resolve(source, self.all_values, length_limit)
        self._history.add(value)
        return value

    @property
    def all_values(self) -> Iterable[str]:
        """Returns all values generated by this object"""
        return frozenset(self._history)
