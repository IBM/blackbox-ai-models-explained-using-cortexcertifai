from typing import Optional, Callable, Any
from toolz.functoolz import curry


@curry
def fmap_opt(f: Callable[[Any], Any], value: Optional[Any]) -> Optional[Any]:
    """Functor for Optional"""
    return None if value is None else f(value)
