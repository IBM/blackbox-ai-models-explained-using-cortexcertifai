"""
This module provides utility functions for directing output to either the logging framework or
Python's print function based on whether the certifai is running from a remote or local instance.
"""
import sys
from certifai.common.utils.utils import get_logger, is_remote_instance
from typing import Optional

def print_output(msg: str):
    """
    Outputs the given message to either python's native print function or the logging framework. If
    the message is delegated to the logging library, it will be logged at a log level of INFO.
    Otherwise the message will be printed to sys.stdout.
    :param msg: message to be printed
    """
    log = get_logger()
    output_func = log.info if is_remote_instance() else print
    output_func(msg)

def print_error(msg: str):
    """
    Outputs the given message to either python's native print function or the logging framework. If
    the message is delegated to the logging library, it will be logged at a log level of ERROR.
    Otherwise the message will be printed to sys.stderr.
    :param msg: message to be printed
    """
    log = get_logger()
    if is_remote_instance():
        log.error(msg)
    else:
        print(msg, file=sys.stderr)
