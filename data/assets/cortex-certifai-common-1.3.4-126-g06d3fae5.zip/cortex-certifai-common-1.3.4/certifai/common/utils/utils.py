import os
import shutil
import logging
import pkg_resources
from datetime import datetime, timedelta
import uuid
from typing import List, Union
import re
import types
import dateutil.parser as date_parser

from logging.config import fileConfig as logFileConfig
from configparser import ConfigParser, NoOptionError, NoSectionError

RESOURCE_PKG = 'certifai.common.utils'
USER_LOG_CONFIG = 'log_conf.ini'
USER_CFI_CONFIG = 'certifai_conf.ini'
DEFAULT_LOG_CONFIG = 'default_log_config.ini'
DEFAULT_CFI_CONFIG = 'default_certifai_config.ini'
INITIAL_CONFIG = 'initial_certifai_conf.ini'
CFI_USR_CONFIG_DIR = os.path.join(os.path.expanduser("~"), ".certifai")
CFI_REMOTE_INSTANCE_VAR = 'CFI_RESTRICTED_FS_ACCESS'

def is_remote_instance() -> bool:
    """
    Whether this instance of Certifai is a remote instance based on the value of the `CFI_RESTRICTED_FS_ACCESS`
    env variable.
    :return: True if the `CFI_RESTRICTED_FS_ACCESS` env var is set, False otherwise
    """
    return os.getenv(CFI_REMOTE_INSTANCE_VAR) is not None

def user_cfi_resource(resource_name):
    """
    Creates a path to a resource in the user certifai config directory (~/.certifai)
    :param resource_name: resource name in config dir
    :return: the location of the resource
    """
    return os.path.join(CFI_USR_CONFIG_DIR, resource_name)

def user_cfi_resource_exists(resource_name):
    """
    Checks if the specified resource exists in the user certifai config directory (~/.certifai)
    :param resource_name: resource to look for
    :return: true if the resource exists in the users config dir
    """
    return os.path.isfile(os.path.join(CFI_USR_CONFIG_DIR, resource_name))

def create_user_cfi_resource(cfi_resource_name, user_resource_name):
    """
    Copies the specified Certifai resource to the user's resource directory.
    :param cfi_resource_name: name of the certifai resource to copy
    :param user_resource_name: name of file to write resource to
    """
    user_resource_path = os.path.join(CFI_USR_CONFIG_DIR, user_resource_name)
    os.makedirs(CFI_USR_CONFIG_DIR, exist_ok=True)
    cfi_resource_path = pkg_resources.resource_filename(RESOURCE_PKG, cfi_resource_name)
    shutil.copyfile(cfi_resource_path, user_resource_path)

def create_user_cfi_resource_from_file(file, user_resource_name):
    """
    Copies the specified file to the user's resource directory.
    :param file: location of file to copy
    :param user_resource_name: name of file to write resource to
    """
    user_resource_path = os.path.join(CFI_USR_CONFIG_DIR, user_resource_name)
    os.makedirs(CFI_USR_CONFIG_DIR, exist_ok=True)
    shutil.copyfile(file, user_resource_path)

def create_user_cfi_resource_from_str(file_data, user_resource_name):
    """
    Writes the string to the user's resource directory.
    :param file_data: string data to be written to resource
    :param user_resource_name: name of file to write to
    """
    user_resource_path = os.path.join(CFI_USR_CONFIG_DIR, user_resource_name)
    os.makedirs(CFI_USR_CONFIG_DIR, exist_ok=True)
    with open(user_resource_path, 'w') as file_to_write:
        file_to_write.write(file_data)



LOG = None
VERBOSE = True
def get_logger():
    global LOG
    if LOG is None:
        LOG = logging.getLogger() # setup default LOG
        try:
            if is_remote_instance():
                setup_default_logging()
            else:
                usr_log_conf_file = os.path.join(CFI_USR_CONFIG_DIR, USER_LOG_CONFIG)
                if not user_cfi_resource_exists(USER_LOG_CONFIG):
                    create_user_cfi_resource(DEFAULT_LOG_CONFIG, USER_LOG_CONFIG)

                logFileConfig(usr_log_conf_file)
                LOG.debug(f"Successfully read logging config from file {usr_log_conf_file}.")
        except Exception as e:
            setup_default_logging()
            LOG.warn(f"Exception initializing LOG config from file {usr_log_conf_file}, using default.")

        # monkey patch details() method
        LOG.details = types.MethodType(_details_patch, LOG)
    return LOG

def setup_default_logging():
    """Sets restricted logging that only writes to a stderr with a logging level INFO."""
    LOG_LEVEL = logging.INFO
    ch0 = logging.StreamHandler()
    LOG.setLevel(LOG_LEVEL)
    # Do not explicitly set the level of the child logger else it will ignore changes to the root logger's level
    formatter = logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    ch0.setFormatter(formatter)
    LOG.addHandler(ch0)

def set_verbose(verbose):
    global VERBOSE
    VERBOSE = verbose

def _details_patch(self, msg, *args, **kwargs):
    if VERBOSE:
        self.info(msg, *args, **kwargs)
    else:
        self.debug(msg, *args, **kwargs)



def process_path_key_config(cnf, key, section):
    """ Expand user home folder if key is of dtype 'path' """
    value = cnf[section][key]
    value = os.path.join(*value.split('/'))
    if '~' in value:
        return value.replace('~', os.path.expanduser("~"))
    else:
        return value

def set_config(key, section, value):
    """
    Set value in config

    :param key: key for the value to set
    :param section: config section to set the key in
    :param value: value of key
    """
    log = get_logger()
    try:
        if config is None:
            init_config()

        if not config.has_section(section):
            log.info(f"Adding new section to config options: {section}")
            config.add_section(section)
        log.info(f"Setting key '{key}' in section '{section}' to value: {value}")
        config[section][key] = value
    except Exception:
        log.error(f"Unable to set key: '{key}' in section: '{section}'", exc_info=True)
        raise


def _get_by_config(cnf, key, section, dtype):
    if dtype == 'str':
        return cnf[section][key]
    elif dtype == 'float':
        return cnf.getfloat(section, key)
    elif dtype == 'int':
        return cnf.getint(section, key)
    elif dtype == 'bool':
        return cnf.getboolean(section, key)
    elif dtype == 'path':
        return process_path_key_config(cnf, key, section)
    else:
        raise ValueError(f"Unknown dtype '{dtype}' specified")

def get_config(key, section='default', dtype='str', default=None, log_on_missing=True):
    """Retrieve value from config

    :param key: key for the value to be retrieved
    :param section: config section to retrieve from
    :param dtype: datatype to coerce to (defaults to 'str', also support 'int', 'float', 'bool', 'path')
    :param default: If specified will be returned if the config file is missing the key
    :return: value if present else None
    """
    log = get_logger()
    try:
        if config is None:
            init_config()
        return _get_by_config(config, key, section, dtype)
    except (KeyError, NoOptionError, NoSectionError):
        if default is not None:
            return default
        else:
            log.debug(
                f"Did not find config key: '{key}' in section: '{section}' - using default config: {default_cfi_config_file}")
            # Try default config in case user hasn't defined in his own.
            try:
                return _get_by_config(default_config, key, section, dtype)
            except (KeyError, NoOptionError, NoSectionError) as e:
                if log_on_missing:
                    log.warning(
                        f"Could not find key: '{key}' in section: '{section}': {e}", exc_info=True)
                    pass
            except Exception:
                log.error(
                    f"Error getting config option from default config: {default_cfi_config_file}", exc_info=True)
                return None
    except ValueError as e:
        log.error(
            f"Error processing key: '{key}' in section: '{section}': {e}", exc_info=True)
        return None
    except Exception as e:
        log.error(
            f"Error processing key: '{key}' in section: '{section}'", exc_info=True)
        return None


def get_api_config(key, dtype='str', default=None):
    return get_config(key, 'api', dtype=dtype, default=default)


def resolve_value(env_var, default_value):
    log = get_logger()
    env_var_value = os.getenv(env_var)
    if env_var_value is not None:
        log.debug(f"Environment variable `{env_var}` is set to: `{env_var_value}`")
        return env_var_value
    log.debug(f"Environment variable `{env_var}` not set, returning: `{default_value}`")
    return default_value

# setup config parser
config = None
default_config = None
default_cfi_config_file = None
def init_config():
    log = get_logger()
    global config, default_config, default_cfi_config_file
    try:
        config = ConfigParser()
        default_config = ConfigParser()
        default_cfi_config_file = pkg_resources.resource_filename(RESOURCE_PKG, DEFAULT_CFI_CONFIG)
        usr_cfi_config_file = os.path.join(CFI_USR_CONFIG_DIR, USER_CFI_CONFIG)

        if is_remote_instance():
            config.read(default_cfi_config_file) # read default config as user config
        else:
            if not user_cfi_resource_exists(USER_CFI_CONFIG):
                create_user_cfi_resource(INITIAL_CONFIG, USER_CFI_CONFIG)
            log.info(f"Reading config from: {usr_cfi_config_file}")
            config.read(usr_cfi_config_file)

        log.info(f"Reading default config (fallback) from: {default_cfi_config_file}")
        default_config.read(default_cfi_config_file)

        def env_or_config(env_name, group, field):
            if group not in config:
                config[group] = {}
            # Set to env or config value, if any exists
            value = resolve_value(env_name, get_config(field, group, log_on_missing=False))
            if value is not None:
                config[group][field] = value

        # Add any env variable overrides here
        env_or_config('GA_POPULATION', 'algo_hyper_params', 'population')

        # Following should be removed once PoV app is decommissioned
        env_or_config('UI_READONLY', 'ui', 'readonly')
        env_or_config('AUTHENTICATE_UI', 'ui', 'auth0_enabled')
        env_or_config('AUTH0_CLIENTID', 'ui', 'auth0_clientid')
        env_or_config('AUTH0_DOMAIN', 'ui', 'auth0_domain')

        log.info(
            "Read config marker: config['default']['marker'] = " + config['default']['marker'])
    except Exception as e:
        log.error(
            "Error while trying to read config. Attempting package config defaults.", exc_info=True)
        config.read(pkg_resources.resource_filename(
            RESOURCE_PKG, DEFAULT_CFI_CONFIG))



def generate_uuid(max_len=36, replace=('-', '')):
    """
    * Generates a unique id with maximum length of max_len.
    * Replaces the specified substring in @replace.
    """
    return str(uuid.uuid4()).replace(*replace)[:max_len]

def get_iso8601_date(replace: Union[tuple,List,List[List]]=None, delta: timedelta=None) -> str:
    """Current ISO 8601 date.
    replace: list
    """
    date = datetime.now().replace(microsecond=0)
    if delta is not None:
        date = date + delta
    date_str = date.isoformat()
    if replace is not None:
        if isinstance(replace[0], list) or isinstance(replace[0], tuple):
            replacements = replace
        else:
            replacements = [replace]
        for repl in replacements:
            date_str = date_str.replace(*repl)

    return date_str


def get_iso8601_datetime(date_str: str) -> datetime:
    """
    Converts str date to datetime object
    :param date_str: Date as string
    :return: datetime object
    """
    return date_parser.parse(date_str)


def replace_to_symbol(text, replacement_symbol, target_symbols):
    """
    Replace symbol in text that are present in target_symbols with a replacement_symbol
    :param text: Text to replace chars on
    :param replacement_symbol: Symbol to add as a replacement
    :param target_symbols: List of symbols to replace
    :return: Replaced text
    """
    if not target_symbols:
        return text
    rx = '[' + re.escape(''.join(target_symbols)) + ']'
    return re.sub(rx, replacement_symbol, text)


def to_filename_safe_chars(unsafe_str, keep_chars=('-', '_'), map_to_underscore=('/', '\\'), max_len=16):
    """
    * Strips spaces and non-alphanumeric charcters, unless in @keep_chars
    * Truncates length to max_len value
    """
    filename = replace_to_symbol(unsafe_str, '_', map_to_underscore)
    filename = "".join(c for c in filename if c.isalnum() or c in keep_chars).rstrip()
    if max_len > 0:
        return filename[:max_len]
    return filename


def prepend_element_to_generator(element, generator):
    """
    Prepends an element to the passed generator
    :param element: first element
    :param generator: the trailing generator
    :return: Generator having element as the first element
    """
    yield element
    yield from generator


def empty_generator():
    """
    An empty generator
    """
    return
    yield
