"""
Common code for inferring features from a dataframe.
"""

import numpy as np
import scipy.stats
from certifai.common.types import DataTypeEnum, FeatureTypeEnum
from certifai.common.utils import get_logger, get_config

log = get_logger()


EPSILON = 1e-8

def infer_feature_data_dictionary(df):
    features = []
    for i, c in enumerate(df.columns):
        column = df[c]
        feat = infer_feature_single_column(column)
        # constant field will be added when we apply restrictions, not inferred
        feat.update({
            "name": c,
            "index": i
        })
        features.append(feat)
    return features


def infer_feature_single_column(df_column, type_hint=None):
    """
    :param df_column: column to infer feature details about
    :param type_hint: a FeatureTypeEnum
    """
    if type_hint:
        if FeatureTypeEnum.is_categorical(type_hint):
            feat = get_categorical_features(type_hint, df_column)
        elif FeatureTypeEnum.is_numeric(type_hint):
            feat = get_numerical_features(type_hint, df_column)
        else:
            raise Exception(f'Unexpected type hint {type_hint}')

    elif df_column.dtype == 'int64':
        # For integer values we measure the cardinality if we have a large enough sample, and infer
        # that it's actually categorical if the cardinality is low
        max_cat_card = get_config('max_inferred_categorical_cardinality', dtype='int', default=10)
        card = len(np.unique(df_column))
        if (card <= max_cat_card) and (len(df_column) >= 10*max_cat_card):
            feat = get_categorical_features(FeatureTypeEnum.CAT, df_column)
            log.details(f"Integer-valued feature '{df_column.name}' inferred to be categorical (sample cardinality {card})")
        else:
            feat = get_numerical_features(FeatureTypeEnum.INT, df_column)
            log.details(f"Integer-valued feature '{df_column.name}' inferred to be numeric (sample cardinality {card})")
        feat['heuristically_inferred'] = True
    elif df_column.dtype == 'float64':
        feat = get_numerical_features(FeatureTypeEnum.FLOAT, df_column)
    elif df_column.dtype == object:
        feat = get_categorical_features(FeatureTypeEnum.CAT, df_column)
    else:
        raise Exception(f'Unexpected data type {df_column.dtype}')
    return feat


def get_categorical_features(data_type, column):
    return {
        "type": data_type,
        "category_values": np.unique(column).astype('object'),
    }


def median_absolute_deviation(column):
    try:
        return scipy.stats.median_absolute_deviation(column, axis=None, scale=1.)
    except AttributeError:
        log.warning("Using fallback implementation of: median_absolute_deviation")
        # scipy < v1.3.0 doesn't have median_absolute_deviation
        # fallback for Azure Notebooks - which conflicts with scipy >= v1.3.0
        # Sources:
        # https://github.com/scipy/scipy/blob/v1.3.0/scipy/stats/stats.py#L2655-L2767
        # https://github.com/scipy/scipy/blob/v1.3.0/scipy/stats/stats.py#L243-L269
        arr = np.asarray(column)
        try:
            if not arr.size or np.isnan(np.sum(arr)):
                return np.nan
        except TypeError:
            try:
                if np.nan in set(arr.ravel()):
                    return np.nan
            except TypeError:
                log.warning("The input array could not be properly checked for "
                            "nan values. nan values will be ignored.")
        med = np.median(arr)
        return np.median(np.abs(arr - med))


def get_numerical_features(data_type, column):
    def scalar_to_numpy(x):
        if isinstance(x, int):
            return np.int64(x)
        elif isinstance(x, float):
            return np.float64(x)
        else:
            return x

    mad = median_absolute_deviation(column)
    if mad == 0:
        spread = np.std(column)
        spread_type = 'std'
        if spread == 0.:
            spread = EPSILON
    else:
        spread = mad
        spread_type = 'mad'
    min_val = scalar_to_numpy(np.min(column))
    max_val = scalar_to_numpy(np.max(column))
    return {
        "type": data_type,
        "min": min_val.astype('object'),
        "max": max_val.astype('object'),
        "spread": spread,
        "spread_type": spread_type
    }

def set_constant_features(feature_dict, constant_list):
    for idx, feature in enumerate(feature_dict):
        if feature["name"] in constant_list:
            feature_dict[idx]["constant"] = True
    return feature_dict


# TODO(LA): remove the int conversion after fixing robustness tests
def process_data(df, features, number_samples):
    if number_samples > 0:
        df = df.iloc[0:number_samples, :]

    ## converts variables back to INT
    int_features = [f['name'] for f in features if f['type'] == FeatureTypeEnum.INT]
    if len(int_features) > 0:
        df[int_features] = df[int_features].astype(int)

    return df


def data_type_to_engine_feature_type(data_type: str) -> FeatureTypeEnum:
    """
    Converts the specified data_type (DataTypEnum) to the corresponding FeatureTypEnum:
    categorical -> CAT, numerical_int -> INT, numerical_float -> FLOAT
    """
    if data_type == DataTypeEnum.categorical:
        return FeatureTypeEnum.CAT
    elif data_type == DataTypeEnum.numerical_int:
        return FeatureTypeEnum.INT
    else:
        return FeatureTypeEnum.FLOAT # DataTypeEnum.numerical_float

def data_type_from_engine_feature_type(feature_type: str) -> DataTypeEnum:
    """
    Converts the specified feature type (FeatureTypeEnum) to the corresponding DataTypeEnum:
    CAT -> categorical, INT -> numerical_int, FLOAT -> numerical_float
    """
    if feature_type == FeatureTypeEnum.CAT:
        return DataTypeEnum.categorical
    elif feature_type == FeatureTypeEnum.INT:
        return DataTypeEnum.numerical_int
    else:
        return DataTypeEnum.numerical_float # FeatureTypeEnum.FLOAT


def get_feature_type_conversion_func(feature_type):
    """
    Returns a function for converting values based on the given feature type (FeatureTypEnum):
    CAT -> np.object_, INT -> np.int64, FLOAT -> np.float64
    """
    if feature_type == FeatureTypeEnum.CAT:
        return np.object_ # object - not necessarily 'str'
    elif feature_type == FeatureTypeEnum.INT:
        return np.int64
    else:
        return np.float64 # FeatureTypeEnum.FLOAT
