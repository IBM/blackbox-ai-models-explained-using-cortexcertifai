from certifai.common.utils import get_logger

log = get_logger()
