from certifai.common.utils.utils import get_iso8601_datetime
from certifai.common.file.interface import FilePath, DirectoryPath, get_basename
from certifai.common.scan_manager.utils import read_from_file
from certifai.common.scan_manager.log import log
from certifai.common.scan_manager.errors import CertifaiNotFoundError
from certifai.common.scan_manager.types import FileType, ReportType
from certifai.common.scan_manager.config import get_config

CONFIG = get_config()


def get_scans(usecase_id):
    directory = CONFIG.get('LOCATER') if usecase_id == CONFIG.get('DEFAULT_USECASE_ID') else CONFIG.get('LOCATER').join(DirectoryPath(usecase_id))
    scans = {}
    error_str = 'Completed with errors'
    success_str = 'Completed'
    label_key = 'labels'
    baseline_label = 'baseline'
    latest_label = 'latest'
    baseline_yaml_filename = CONFIG.get('BASELINE_YAML_FILENAME')
    latest_scan = {
        'date': None,
        'scan_id': None
    }
    baseline = {}
    try:
        baseline = read_from_file(directory.join(DirectoryPath(baseline_yaml_filename)))
    except FileNotFoundError:
        log.debug(f'{baseline_yaml_filename} not found.')
    except:
        log.exception('Unable to fetch baseline')

    try:
        dir_list_gen = directory.file_lister()
    except FileNotFoundError:
        raise CertifaiNotFoundError(directory.name) from None

    try:
        def extract_date_from_filename(x):
            try:
                return get_iso8601_datetime(get_basename(x[0]).split('.')[-2].split('-')[-4])
            except IndexError:
                return None

        file_list = []
        for file_name in dir_list_gen:
            base_file_name = get_basename(file_name)
            if not base_file_name.startswith('certifai-scan-'):
                continue
            try:
                # the model id in the scan report filename is not necessarily accurate
                date, id_, reportType, model_abbrev = base_file_name.split(".")[-2].split("-")[-4:]
            except ValueError:
                log.debug(f'Skipping... {file_name}')
                continue
            file_list.append((file_name, {'date': date, 'id_': id_, 'model_abbrev': model_abbrev, 'reportType': reportType}))

        file_list = sorted(file_list, key=extract_date_from_filename, reverse=True)
        for file_name, file_metadata in file_list:
            file_contents = {}
            resolved_file = directory.join(FilePath(file_name))

            # the model id in the scan report filename is not necessarily accurate
            date = file_metadata.get('date')
            id_ = file_metadata.get('id_')
            model_abbrev = file_metadata.get('model_abbrev')
            reportType = file_metadata.get('reportType')

            if id_ in scans:
                if reportType not in scans[id_]["reportTypes"]:
                    scans[id_]["reportTypes"].append(reportType)
            else:
                scans[id_] = {"reportTypes": [], "models": [], "date": date, "id": id_, "status": None}
                if "usecaseName" not in scans[id_].keys():
                    try:
                        file_contents = read_from_file(resolved_file, filetype=FileType.json)
                        scans[id_]["usecaseName"] = file_contents.get("model_use_case", {}).get("name", None)
                    except:
                        scans[id_]["usecaseName"] = None
                scans[id_]['reportTypes'].append(reportType)

            # Look for "status" and model_id in each ATX report
            # we have to read every ATX report to find accurate model_id
            if reportType == ReportType.atx:
                if not file_contents:
                    file_contents = read_from_file(resolved_file, filetype=FileType.json)
                status = file_contents.get('status', '')
                scans[id_]['status'] = status if status == success_str else error_str
                scans[id_]['models'].append(file_contents.get('model', {}).get('model_id', model_abbrev))

            # Set baseline scan
            if label_key not in scans[id_]:
                scans[id_][label_key] = []
            if id_ == baseline.get('scan_id'):
                if baseline_label not in scans[id_][label_key]:
                    scans[id_][label_key].append(baseline_label)

            # Save the latest date for later comparison
            date_obj = get_iso8601_datetime(date)
            if latest_scan.get('date') is None or date_obj > latest_scan.get('date'):
                latest_scan['date'] = date_obj
                latest_scan['scan_id'] = id_

    except FileNotFoundError:
        log.exception(f'Unable to list files in path {directory}')

    # Set "latest" label to the latest scan
    if scans:
        if latest_scan['scan_id'] is None and len(scans) == 1:
            scans[0][label_key].append(latest_label)
        else:
            scans[latest_scan['scan_id']][label_key].append(latest_label)
    scan_list = list(scans.values())

    if len(scan_list) == 0:
        raise CertifaiNotFoundError(message=f'Unable to find scans in {directory.filesystem.type_name} directory: {directory.name}')
    data = {"scans": list(scans.values())}

    return data


def get_scan_id_data(usecase_id, scan_id):
    locater = CONFIG.get('LOCATER') if usecase_id == CONFIG.get('DEFAULT_USECASE_ID') else CONFIG.get('LOCATER').join(DirectoryPath(usecase_id))

    def match_scan_id(file_name):
        try:
            _, _, _, id_, _, _ = file_name.strip().split('-')
            return id_ == scan_id
        except ValueError as e:
            log.debug(f'Skipping... {file_name}')
            return None

    data = {"reports": []}
    try:
        for file in locater.file_lister():
            file_locater = locater.join(file)
            file_name = get_basename(file)
            if not file_name.endswith('.json') or not match_scan_id(file_name):
                continue
            try:
                # model id in filename is not reliable
                date, id_, reportType, model_abbrev = get_basename(file_name).split(".")[0].split("-")[-4:]
            except ValueError:
                log.debug(f'Skipping... {file}')
                continue
            report_data = {"reportType": reportType, "date": date}
            file_data = read_from_file(file_locater, filetype=FileType.json)
            report_data['data'] = file_data
            report_data['model'] = file_data.get('model', {}).get('model_id', model_abbrev)
            data["reports"].append(report_data)
    except FileNotFoundError:
        log.exception(f'Path {locater.name} does not exist')
    return data


def get_model_by_id(model_id, scan_list):
    model = [m.get('data', {}).get('model') for m in scan_list if m.get('model') == model_id]
    return model[0] if model else None
