from certifai.common.scan_manager.utils import read_from_file, write_to_file
from certifai.common.scan_manager.scan import get_model_by_id, get_scan_id_data
from certifai.common.scan_manager.usecase import get_usecase_by_id
from certifai.common.file import DirectoryPath
from certifai.common.scan_manager.config import get_config
from certifai.common.scan_manager.log import log
from certifai.common.scan_manager.errors import CertifaiNotFoundError, CertifaiWriteError

CONFIG = get_config()


def _validate_usecase_scan_model(usecase_id: str, scan_id: str, model_id: str) -> bool:
    """
    Validates if a usecase, scan and a model exists
    :param usecase_id: Usecase id
    :param scan_id: Scan id
    :param model_id: Model id
    :return: True if all exists
    :raises: CertifaiNotFoundError
    """
    usecase = get_usecase_by_id(usecase_id)
    if not usecase:
        raise CertifaiNotFoundError(message=f'Usecase with id "{usecase_id}" not found')

    scan = get_scan_id_data(usecase_id, scan_id)
    scan_list = scan.get('reports', [])
    if not scan_list:
        raise CertifaiNotFoundError(message=f'Scan with id "{scan_id}" not found')

    model = get_model_by_id(model_id, scan_list)
    if not model:
        raise CertifaiNotFoundError(message=f'Model with id "{model_id}" not found')

    return True


def set_baseline_model(usecase_id: str, scan_id: str, model_id: str) -> dict:
    """
    Sets a model as baseline
    :param usecase_id: Usecase id
    :param scan_id: Scan id
    :param model_id: Model id
    :return: Baseline data
    :raise: CertifaiWriteError
    """
    _validate_usecase_scan_model(usecase_id, scan_id, model_id)
    baseline_file = CONFIG.get('LOCATER').join(DirectoryPath(usecase_id)).join(CONFIG.get('BASELINE_YAML_FILENAME'))

    data = {
        'scan_id': scan_id,
        'model_id': model_id,
    }

    if write_to_file(baseline_file, data):
        return data
    else:
        raise CertifaiWriteError(resource=baseline_file.name)


def get_baseline_model(usecase_id) -> dict:
    """
    Reads the baseline
    :param usecase_id: Usecase id
    :return: Baseline file contents
    :raises: CertifaiNotFoundError
    """
    baseline_file = CONFIG.get('LOCATER').join(DirectoryPath(usecase_id)).join(CONFIG.get('BASELINE_YAML_FILENAME'))
    baseline = {}
    try:
        baseline = read_from_file(baseline_file)
    except FileNotFoundError:
        raise CertifaiNotFoundError(message='Baseline is not set!')
    except:
        log.exception('Unable to get baseline')
    return baseline
