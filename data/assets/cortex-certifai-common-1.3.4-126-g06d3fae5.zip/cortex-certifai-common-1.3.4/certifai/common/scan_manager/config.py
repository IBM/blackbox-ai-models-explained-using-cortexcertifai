import os

from certifai.common.file.locaters import make_generic_locater
from certifai.common.file.interface import DirectoryPath, FilePath
from certifai.common.scan_manager.types import VMType
from certifai.common.scan_manager.log import log

CONFIG = {
    'FILE_CHUNK_SIZE_BYTES': 500000,
    'DEFAULT_USECASE_ID': 'default',
    'DEFAULT_USECASE_NAME': 'Default',
    'DEFAULT_USECASE_FILENAME': 'usecase.yaml',
    'BASELINE_YAML_FILENAME': 'baseline.yaml'
}


def load_config(reports_directory=None):
    global CONFIG
    TOOLKIT_DOWNLOAD_FILENAME = os.getenv('CERTIFAI_TOOLKIT_FILENAME', 'certifai_toolkit.zip')
    TOOLKIT_PATH = FilePath(os.getenv('CERTIFAI_TOOLKIT_PATH', './certifai_toolkit.zip'))
    CERTIFAI_VM = get_vm_type()
    PORTAL_URL = os.getenv('PORTAL_URL', None)
    if reports_directory:
        SCAN_RESULTS_DIRECTORY = DirectoryPath(reports_directory)
    else:
        SCAN_RESULTS_DIRECTORY = DirectoryPath(os.getenv('SCAN_RESULTS_DIRECTORY', './reports'))
    LOCATER = make_generic_locater(SCAN_RESULTS_DIRECTORY)
    conf = {
        'TOOLKIT_DOWNLOAD_FILENAME': TOOLKIT_DOWNLOAD_FILENAME,
        'TOOLKIT_PATH': TOOLKIT_PATH,
        'CERTIFAI_VM': CERTIFAI_VM,
        'PORTAL_URL': PORTAL_URL,
        'SCAN_RESULTS_DIRECTORY': SCAN_RESULTS_DIRECTORY,
        'LOCATER': LOCATER
    }
    CONFIG.update(conf)


def get_vm_type():
    certifai_vm = os.getenv('CERTIFAI_VM', None)
    try:
        if certifai_vm is not None:
            VMType[certifai_vm] # check that it is a valid VMType
        return certifai_vm
    except KeyError:
        error_msg = f'Invalid CERTIFAI_VM type: {certifai_vm}. CERTIFAI_VM must be one of: {[t.name for t in VMType]}'
        log.exception(error_msg)
        raise Exception(error_msg)


def get_config():
    return CONFIG
