from certifai.common.file.interface import FilePath, get_basename
from certifai.common.file.locaters import FSLocater
from certifai.common.scan_manager.utils import read_from_file
from certifai.common.scan_manager.types import FileType
from certifai.common.scan_manager.log import log
from certifai.common.scan_manager.errors import CertifaiNotFoundError, CertifaiPathNotFoundError
from certifai.common.scan_manager.config import get_config

CONFIG = get_config()


def get_usecase_by_id(usecase_id):
    directory_locater = CONFIG.get('LOCATER')
    default_usecase_id = CONFIG.get('DEFAULT_USECASE_ID')
    default_usecase_filename = CONFIG.get('DEFAULT_USECASE_FILENAME')
    locater = directory_locater if usecase_id == default_usecase_id else directory_locater.join(usecase_id)
    usecase_file = locater.join(FilePath(default_usecase_filename))
    usecase = {}
    try:
        usecase = read_from_file(usecase_file, filetype=FileType.yaml)
    except FileNotFoundError:
        log.debug(f'Path {usecase_file.name} does not exists')
    except:
        log.exception(f'Unable to get usecase by id: {usecase_id}')

    # Making sure the the default usecase is handled, overwriting "model_use_case_id"
    if usecase_id == default_usecase_id:
        default_usecase_desc = "The Default group contains models and scans that have not been run as part of a defined use case. Make sure you have a model_use_case_id in your scan definition."
        usecase['model_use_case'] = dict.fromkeys(usecase.get('model_use_case', {}).keys(), None)
        usecase['model_use_case']['model_use_case_id'] = default_usecase_id
        usecase['model_use_case']['description'] = default_usecase_desc
        usecase['model_use_case']['name'] = default_usecase_filename

    return usecase


def get_usecases() -> list:
    default_usecase_id = CONFIG.get('DEFAULT_USECASE_ID')
    default_usecase_name = CONFIG.get('DEFAULT_USECASE_NAME')
    default_usecase_filename = CONFIG.get('DEFAULT_USECASE_FILENAME')
    directory = CONFIG.get('LOCATER')
    usecase_list = []
    usecase_filename = 'usecase.yaml'

    def create_use_case_object(file_contents, model_usecase_id) -> dict:
        model_use_case_obj = file_contents.get('model_use_case', {})
        # Sets model_use_case_id to 'default' if the 'default' case
        return {
            'model_use_case_id': model_usecase_id,
            'model_use_case_name': default_usecase_name if model_usecase_id == default_usecase_id else model_use_case_obj.get('name', ''),
            'task_type': model_use_case_obj.get('task_type', ''),
            'created': file_contents.get('created')
        }

    def create_min_metadata(dirpath, usecase_default=False):
        id_ = get_basename(dirpath.rstrip('/'))
        data = {
            "model_use_case": {
                "model_use_case_id": id_
            }
        }
        if usecase_default:
            return data
        data.update({"name": id_.replace('_', ' ').title()})
        return data

    def is_valid_usecase_directory(directory: FSLocater, is_default_case: bool = False) -> bool:
        """
        Check if the directory is a valid use case
        :param directory: Directory locater
        :param is_default_case: True if it's a default case else False
        :return: True if the directory is a valid use case else False
        """
        try:
            for file_path in directory.file_lister():
                file_name = get_basename(file_path)
                if is_default_case and file_name.startswith('certifai-scan') and file_name.endswith('.json'):
                    return True
                elif not is_default_case and file_name == default_usecase_filename:
                    return True
        except FileNotFoundError as e:
            log.debug(f'Unable to parse directory: {directory.name} {e}')
            return False
        except Exception:
            log.error(f'Unable to parse directory: {directory.name}')
            return False
        return False

    def read_file_and_create_usecase(file, dir_name, usecase_id):
        try:
            file_contents = read_from_file(file)
        except Exception as e:
            if isinstance(e, FileNotFoundError):
                log.debug(f'Cannot read contents of "{file.name}": {e}')
            else:
                log.exception(f'Cannot read contents of "{file.name}"')
            # Create minimum metadata if usecase.yaml doesn't exist
            file_contents = create_min_metadata(dir_name)
        data = create_use_case_object(file_contents, usecase_id)
        usecase_list.append(data)

    try:
        dir_gen = directory.directory_lister()
    except FileNotFoundError:
        raise CertifaiPathNotFoundError(
            directory.name,
            message=f'{directory.filesystem.type_name.title()}Error: No such file or directory: {directory.name}'
        ) from None
    while True:
        try:
            obj = next(dir_gen)
            locater = directory.join(obj)
            if not is_valid_usecase_directory(locater):
                log.debug(f'Skipping directory, Invalid use case dir: {locater.name}')
                continue
            model_use_case_id = locater.get_normalized_name().rstrip('/').split('/')[-1]
            file = locater.join(FilePath(usecase_filename))
            read_file_and_create_usecase(file, locater.name, model_use_case_id)
        except StopIteration:
            break
        except (FileNotFoundError, PermissionError):
            log.exception(f'Unable to list directories in path: {directory.name}')
        except Exception:
            log.exception('Unhandled exception')

    # Default use case
    if is_valid_usecase_directory(directory, is_default_case=True):
        file = directory.join(FilePath(usecase_filename))
        read_file_and_create_usecase(file, directory.name, default_usecase_id)

    if len(usecase_list) == 0:
        raise CertifaiNotFoundError(message=f'Unable to find usecases in {directory.filesystem.type_name} directory: {directory.name}')
    return usecase_list


# Dataclasses for these Certifai Types should be implemented,
# but the console UI also needs to be updated to consume the new schema fields.
# WIP - Need to decide when to do this - TECHNICAL DEBT!
# @dataclass
# class ModelUseCase():
#
#     model_use_case_id: str
#     model_use_case_name: str
#     task_type: str
#     description: str
#     author: str
