from certifai.common.errors import CertifaiException
from certifai.common.file.interface import FilePath


class CertifaiConsoleError(CertifaiException):
    status = None
    message = None

    def __init__(self, message=None):
        super().__init__()
        if message:
            self.message = message
        self.status = self.__class__.status

    def __str__(self):
        return self.message

    def to_dict(self):
        return self.__dict__


class CertifaiPathNotFoundError(CertifaiConsoleError):
    status = 404

    def __init__(self, path: FilePath, message=None):
        super().__init__(message)
        if not message:
            self.message = f'No such file or directory: \'{path}\''


class CertifaiNotFoundError(CertifaiConsoleError):
    status = 404

    def __init__(self, resource=None, message=None):
        super().__init__(message)
        if not message:
            self.message = f'Resource not found: \'{resource}\''


class CertifaiWriteError(CertifaiConsoleError):
    status = 400

    def __init__(self, resource=None, message=None):
        super().__init__(message)
        if not message:
            self.message = f'Unable to write to: \'{resource}\''
