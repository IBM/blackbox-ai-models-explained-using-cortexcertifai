import enum


class ReportType(str, enum.Enum):
    atx = 'atx'
    fairness = 'fairness'
    explanations = 'explanations'
    explainability = 'explainability'
    robustness = 'robustness'
    performance = 'performance'


class FileType(enum.Enum):
    json = 'json'
    yaml = 'yaml'
    csv = 'csv'


class VMType(enum.Enum):
    azure = 'azure'
    aws = 'aws'
    gcp = 'gcp'
    vmware = 'vmware'
