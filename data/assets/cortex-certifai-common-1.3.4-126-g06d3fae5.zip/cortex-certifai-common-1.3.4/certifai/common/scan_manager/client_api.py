from certifai.common.scan_manager.usecase import get_usecases, get_usecase_by_id
from certifai.common.scan_manager.scan import get_scans, get_scan_id_data, get_model_by_id
from certifai.common.scan_manager.baseline import get_baseline_model, set_baseline_model
from certifai.common.file import DirectoryPath
from certifai.common.scan_manager.config import load_config


class ScanManager:
    """
    Client library for scan management
    """

    def __init__(self, reports_directory: DirectoryPath = None):
        load_config(reports_directory)

    def list_usecases(self, **kwargs) -> list:
        """
        Lists usecases
        :return: List of usecases
        """
        return get_usecases()

    def get_usecase(self, usecase, **kwargs) -> dict:
        """
        Get usecase by id
        :param usecase: Usecase Id
        :return: Usecase object
        """
        return get_usecase_by_id(usecase)

    def list_scans(self, usecase, **kwargs) -> list:
        """
        Lists scans under a usecase
        :param usecase: Usecase id
        :return: List of usecases
        """
        return get_scans(usecase).get('scans', [])

    def get_scan(self, usecase, scan, **kwargs) -> list:
        """
        Gets scan reports by usecase id, scan id
        :param usecase: Usecase id
        :param scan: Scan id
        :return: Scan object
        """
        return get_scan_id_data(usecase, scan).get('reports', [])

    def get_baseline(self, usecase, **kwargs) -> dict:
        """
        Get baseline object
        :param usecase: Usecase id
        :return: Baseline object
        """
        return get_baseline_model(usecase)

    def set_baseline(self, usecase, scan, model, **kwargs) -> dict:
        """
        Set baseline
        :param usecase: Usecase id
        :param scan: Scan id
        :param model: Model id
        :return: Baseline object
        """
        return set_baseline_model(usecase, scan, model)

    def get_model(self, model, scans) -> list:
        """
        Get models
        :param model: Model id
        :param scans: List of scans
        :return: List of models
        """
        return get_model_by_id(model, scans)
