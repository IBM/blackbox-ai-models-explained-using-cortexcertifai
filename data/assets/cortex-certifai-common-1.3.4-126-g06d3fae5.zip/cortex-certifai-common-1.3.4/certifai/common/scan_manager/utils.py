import json
import yaml

import pandas as pd

from certifai.common.file.locaters import FSLocater
from certifai.common.scan_manager.types import FileType


def extract_file_type(file: FSLocater) -> FileType:
    """
    Finds file type of a file
    :param file: File locater object
    :return: Filetype
    """
    if file.name.endswith('.json'):
        filetype = FileType.json
    elif file.name.endswith('.yaml'):
        filetype = FileType.yaml
    else:
        raise Exception(f'File type is not one of JSON or YAML')
    return filetype


def read_from_file(file, filetype: FileType=None):
    """
    Reads a file and returns its contents
    :param filetype: Type of file
    :param file: File locater
    :return: File contents as JSON / YAML / CSV
    """
    if filetype is None:
        filetype = extract_file_type(file)
    with file.reader() as file_name:
        if filetype == FileType.json:
            return json.load(file_name)
        elif filetype == FileType.yaml:
            return yaml.load(file_name, Loader=yaml.SafeLoader)
        elif filetype == FileType.csv:
            return pd.read_csv(file_name)


def write_to_file(file, data, filetype: FileType=None):
    """
    Write data to file
    :param file: Locater file object
    :param filetype: Type of file (default JSON)
    :return:
    """
    if filetype is None:
        filetype = extract_file_type(file)
    with file.writer() as writer:
        if filetype == FileType.json:
            file_contents = json.dumps(data)
        else:
            file_contents = yaml.dump(data, Dumper=yaml.SafeDumper)
        return writer.write(file_contents.encode('utf-8'))
