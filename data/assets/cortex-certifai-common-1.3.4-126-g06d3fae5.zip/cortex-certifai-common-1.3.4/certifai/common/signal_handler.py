import platform
import contextlib
from certifai.common.utils import get_logger

log = get_logger()

_sigint_handler   =  None    # lambda when CTRL+C event occurs (returns )
_added_os_handler =  False   # os handler flag installed or not

def cli_signal_handler(dwCtrlType, hook_sigint=None):
    if dwCtrlType == 0: # CTRL_C_EVENT
        log.warning('CLI interrupt signal received')
        return 1 # don't chain to the next handler
    else:
        log.warning(f"CLI handler received {dwCtrlType}")
    return 0 # chain to the next handler


def process_init():
    if platform.system() == 'Windows':
        add_os_handler(cli_signal_handler)
    else:
        pass


def default_signal_handler(dwCtrlType, hook_sigint=None):
    if dwCtrlType == 0: # CTRL_C_EVENT
        if _sigint_handler is not None:
            log.info('invoking attached signal handler')
            return _sigint_handler(dwCtrlType,hook_sigint)
        else:
            return 0
        # return 1 # don't chain to the next handler
    else:
        log.warning(f"handler received {dwCtrlType}")
        return 0


def add_os_handler(fn=None):
    # Force pywintypes38.dll load by importing pywintypes before win32 modules
    # source: https://stackoverflow.com/questions/58631512/pywin32-and-python-3-8-0
    import pywintypes
    import win32api
    log.info("Setting Windows signal handler")
    if fn:
        win32api.SetConsoleCtrlHandler(fn, True)
    else:
        win32api.SetConsoleCtrlHandler(default_signal_handler, True)
    return True


@contextlib.contextmanager
def sigint_handling(handler_fn):
    if platform.system() == 'Windows':
        global _sigint_handler
        global _added_os_handler
        log.debug('Working inside signal handling context')
        if not _added_os_handler:
            _added_os_handler = add_os_handler()

        _sigint_handler = handler_fn
        try:
            yield
        except Exception as e:
            log.error(f'Error inside signal handler contex {e}')
            log.info('Setting signal handler inside context to None')
            _sigint_handler = None
            raise e
        finally:
            log.info('Setting _sigint handler to None')
            _sigint_handler = None
    else:
        yield
