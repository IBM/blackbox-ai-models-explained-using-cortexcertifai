from typing import Union, Callable, Any, Optional, Dict, List, NamedTuple

import sys
import numpy as np
import json
import requests
from abc import ABC

from requests.adapters import HTTPAdapter
from urllib3.util import Retry
from certifai.common.timing import TimeAggregate, TimerStats
from certifai.common.utils import get_logger
from certifai.common.errors import CertifaiValidationException


log = get_logger()

_session = None


def create_session():
    global _session
    _session = requests.Session()
    max_retries = Retry(
        total=5,
        backoff_factor=0.2,
        status_forcelist=[500, 502, 503, 504],
        method_whitelist=frozenset(['GET', 'POST']),
        raise_on_status=False)

    _session.mount('http://', HTTPAdapter(max_retries=max_retries))
    _session.mount('https://', HTTPAdapter(max_retries=max_retries))


# Stats are a tuple of call-count and total time (in ms)
class ModelStats():
    def __init__(self, timing: TimerStats, records_evaluated: int):
        self._timing = timing
        self._timing = timing
        self._records_evaluated = records_evaluated

    @property
    def timing(self) -> TimerStats:
        return self._timing

    @property
    def records_evaluated(self) -> int:
        return self._records_evaluated

    def plus(self, other: 'ModelStats'):
        return ModelStats(self.timing.plus(other.timing), self.records_evaluated + other.records_evaluated)

    def diff(self, other: 'ModelStats'):
        return ModelStats(self.timing.diff(other.timing), self.records_evaluated - other.records_evaluated)

    @staticmethod
    def empty():
        return ModelStats(TimerStats(0, 0), 0)


class IBaseModel(ABC):
    """Abstract base class for the family of all supported models - suitable for
    sklearn models directly"""
    def predict(self, values, **kwargs):
        ...


class SoftClassificationMixin(ABC):
    def __init__(self):
        self._threshold = None

    def thresholded_prediction(self, raw):
        """Binarize soft predictions with respect to a threshold
           If no threshold has been set then 0.5 will be used.  Also having
           an explicit threshold set will cause the model's `predict` method
           to ignore the underlying model's discrete label output and recalculate
           it from the soft scores with respect to the explicit threshold"""
        if len(raw.shape) == 1:
            return raw >= (0.5 if self._threshold is None else self._threshold)
        else:
            return np.argmax(raw, axis=1)

    @property
    def threshold(self) -> Optional[float]:
        return self._threshold

    @threshold.setter
    def threshold(self, value: Optional[float]):
        self._threshold = value


class BoilerPlate(ABC):

    @property
    def timer(self) -> TimeAggregate:
        """
        Return an aggregate timer for all calls to the hosted model

        :return: An instance of `AggregateTimer` for this model host
        """
        ...

    def reset(self):
        ...

    @property
    def stats(self) -> ModelStats:
        ...


class BaseConnector(SoftClassificationMixin, BoilerPlate, IBaseModel):
    def __init__(self):
        super(BaseConnector, self).__init__()
        self._timer = TimeAggregate(f' {self.__class__.__name__}')
        self.records_evaluated = 0
        self._label_ordering = None

    @property
    def timer(self):
        return self._timer

    def reset(self):
        self._timer.reset()
        self.records_evaluated = 0

    @property
    def stats(self) -> ModelStats:
        return ModelStats(self._timer.stats, self.records_evaluated)

    def predict(self, values, **kwargs):
        kwargs.pop('encoder_args', None)
        with self._timer():
            if self.supports_soft_scores and self.threshold is not None:
                result = self._soft_predict(values, **kwargs)
                raw = self.thresholded_prediction(result)
                return raw if self.label_ordering is None else np.array(self.label_ordering)[raw]
            else:
                return self._predict(values, **kwargs)

    def _soft_predict(self, values, **kwargs):
        ...

    def _predict(self, values, **kwargs):
        ...

    def soft_predict(self, values, **kwargs):
        kwargs.pop('encoder_args', None)
        with self._timer():
            return self._soft_predict(values, **kwargs)

    @property
    def label_ordering(self) -> Optional[List[Any]]:
        return self._label_ordering

    @label_ordering.setter
    def label_ordering(self, labels):
        self._label_ordering = labels


class IHostedModel(BaseConnector):
    """
    Abstract base class for model hosting wrappers
    """

    def predict_with_untransformed(self, values, **kwargs):
        result = self.predict(values, **kwargs)
        return result, result

    def map(self, f: Callable[[Any], Any]) -> 'IHostedModel':
        """Map over the model output type (acts as a functor on IHostedModel)"""
        return MappedHostedModel(self, f)

    @property
    def supports_soft_scores(self):
        return False

    @property
    def label_ordering(self) -> Optional[List[Any]]:
        return None

    @label_ordering.setter
    def label_ordering(self, labels):
        pass

    def contramap(self, f: Callable[[Any], Any]) -> 'IHostedModel':
        """Map over the model input type (acts as a contravariant functor on IHostedModel)"""
        return ContraMappedHostedModel(self, f)

    @property
    def map_timer(self) -> Optional[TimeAggregate]:
        return None

    @property
    def comap_timer(self) -> Optional[TimeAggregate]:
        return None


class ContraMappedHostedModel(IHostedModel):
    def __init__(self, underlying: IHostedModel, f: Callable[[Any], Any]):
        self.comapper = f
        self.underlying = underlying
        self._comap_timer = TimeAggregate("comapper")

    def reset(self):
        self.underlying.reset()

    @property
    def stats(self) -> ModelStats:
        return self.underlying.stats

    @property
    def timer(self) -> TimeAggregate:
        return self.underlying.timer

    @property
    def map_timer(self) -> Optional[TimeAggregate]:
        return self.underlying.map_timer

    @property
    def comap_timer(self) -> Optional[TimeAggregate]:
        return self._comap_timer

    @property
    def supports_soft_scores(self):
        return self.underlying.supports_soft_scores

    @property
    def label_ordering(self) -> Optional[List[Any]]:
        return self.underlying.label_ordering

    @label_ordering.setter
    def label_ordering(self, labels):
        self.underlying.label_ordering = labels

    @property
    def threshold(self) -> Optional[float]:
        return self.underlying.threshold

    @threshold.setter
    def threshold(self, value: Optional[float]):
        self.underlying.threshold = value

    def predict(self, values, **kwargs):
        encoder_args = kwargs.pop('encoder_args', {})
        with self.comap_timer():
            comapped = self.comapper(values, **encoder_args)
        return self.underlying.predict(comapped, **kwargs)

    def soft_predict(self, values, **kwargs) -> Union[np.ndarray, List[Dict[Any, float]]]:
        encoder_args = kwargs.pop('encoder_args', {})
        with self.comap_timer():
            comapped = self.comapper(values, **encoder_args)
        return self.underlying.soft_predict(comapped, **kwargs)


class MappedHostedModel(IHostedModel):
    def __init__(self, underlying: IHostedModel, f: Callable[[Any], Any]):
        self.mapper = f
        self.underlying = underlying
        self._map_timer = TimeAggregate("mapper")

    def reset(self):
        self.underlying.reset()

    @property
    def stats(self) -> ModelStats:
        return self.underlying.stats

    @property
    def timer(self) -> TimeAggregate:
        return self.underlying.timer

    @property
    def map_timer(self) -> Optional[TimeAggregate]:
        return self._map_timer

    @property
    def comap_timer(self) -> Optional[TimeAggregate]:
        return self.underlying.comap_timer

    def predict(self, values, **kwargs):
        with self.map_timer():
            return self.mapper(self.underlying.predict(values, **kwargs))

    def predict_with_untransformed(self, values, **kwargs):
        transformed, untransformed = self.underlying.predict_with_untransformed(values, **kwargs)
        with self.map_timer():
            return self.mapper(transformed), untransformed

    @property
    def supports_soft_scores(self):
        return self.underlying.supports_soft_scores

    @property
    def label_ordering(self) -> Optional[List[Any]]:
        return self.underlying.label_ordering

    @label_ordering.setter
    def label_ordering(self, labels):
        self.underlying.label_ordering = labels

    def soft_predict(self, values, **kwargs) -> np.ndarray:
        result = self.underlying.soft_predict(values, **kwargs)
        if len(result.shape) > 1:
            with self.map_timer():
                label_index_map = self.mapper(np.arange(0, result.shape[-1]))
            mapped_result = np.zeros((result.shape[0], np.max(label_index_map)+1))
            for idx in range(mapped_result.shape[-1]):
                mapped_result[:, idx] = np.sum(result[:, np.where(label_index_map == idx)], axis=1)
            return mapped_result
        else:
            return result

    @property
    def threshold(self) -> float:
        return self.underlying.threshold

    @threshold.setter
    def threshold(self, value: float):
        self.underlying.threshold = value


def _construct_label_permutation(model_label_ordering: Optional[list]=None,
                                 expected_label_ordering: Optional[list]=None) -> Optional[np.ndarray]:
    if (model_label_ordering is not None) and (expected_label_ordering is not None):
        if len(model_label_ordering) != len(expected_label_ordering):
            raise ValueError(f"Label count mismatch ({len(model_label_ordering)} vs expected {len(expected_label_ordering)})")
        ordering_dict = {l: idx for idx, l in enumerate(model_label_ordering)}
        perm = np.zeros(len(model_label_ordering), dtype=int)
        for idx, l in enumerate(expected_label_ordering):
            if l not in ordering_dict:
                raise ValueError(f"Expected label {l} missing from scores")
            perm[idx] = ordering_dict[l]
        return perm
    else:
        return None


class LocalHostedModel(IHostedModel):
    def __init__(self,
                 model: IBaseModel,
                 soft_predictions: bool=False,
                 threshold: Optional[float]=None,
                 model_label_ordering: Optional[list]=None,
                 label_ordering: Optional[list]=None):
        super().__init__()
        self.model = model
        self._soft = soft_predictions
        self._expected_labels = np.array(label_ordering) if label_ordering is not None else None
        self.model_label_ordering = model_label_ordering
        self._label_perm = _construct_label_permutation(self.model_label_ordering, self.label_ordering)
        self._len_warning_issued = False
        if threshold is not None:
            self.threshold = threshold

    def _soft_predict(self, values, **kwargs):
        if callable(getattr(values, '__len__', None)):
            self.records_evaluated += len(values)
        elif not self._len_warning_issued:
            self._len_warning_issued = True
            log.warning("Encoded data for local model has no __len__ - evaluation stats will not be available")
        result = np.array(self.model.soft_predict(values, **kwargs), dtype=float)
        if self._label_perm is not None:
            result = result[:, self._label_perm]
        return result

    def _predict(self, values, **kwargs):
        # remove 'retries' parameter (not applicable to local models)
        kwargs.pop('retries', None)
        if callable(getattr(values, '__len__', None)):
            self.records_evaluated += len(values)
        elif not self._len_warning_issued:
            self._len_warning_issued = True
            log.warning("Encoded data for local model has no __len__ - evaluation stats will not be available")
        return np.array(self.model.predict(values, **kwargs), dtype='object')

    @property
    def supports_soft_scores(self):
        return self._soft

    @property
    def label_ordering(self) -> Optional[List[Any]]:
        # dtype 'object' is necessary here to ensure we get a list of native types, otherwise
        # we can leak numpy int64s, which cannot be YAML serialized
        return list(self._expected_labels.astype(object)) if self._expected_labels is not None else None

    @label_ordering.setter
    def label_ordering(self, labels):
        self._expected_labels = np.array(labels)
        self._label_perm = _construct_label_permutation(self.model_label_ordering, self.label_ordering)

    def soft_predict(self, values, **kwargs) -> Union[np.ndarray, List[Dict[Any, float]]]:
        if self.supports_soft_scores:
            return self._soft_predict(values, **kwargs)
        else:
            raise NotImplementedError


class PredictResponse(NamedTuple):
    """Representation of model prediction response, allowing for optional soft scoring information
    """
    predictions: np.ndarray
    scores: Optional[np.ndarray]
    labels: Optional[list]
    threshold: Optional[float]


class HostedModel(IHostedModel):
    """
    Wrapper to Http-POST values to a model's http-endpoint.
    The original "model" object had a predict() function, this class exposes
    that same function and returns the prediction results.

    The scaler_* functions are only for back-compatibility purposes,
    models are expected to do the scaling within and as part of the prediction.

    The optional `response_provider` is purely to make testing easier and allow
    ready injection of mocks
    """
    def __init__(self,
                 predict_endpoint,
                 batch_support=False,
                 max_batch_size=None,
                 headers=None,
                 supports_soft_scores=False,
                 threshold: Optional[float]=None,
                 label_ordering: Optional[list]=None,
                 response_provider: Optional[Callable[[str, dict], dict]]=None):
        super().__init__()
        self._predict_endpoint = predict_endpoint
        self.max_batch_size = max_batch_size if batch_support else 1
        self.headers = headers
        self._supports_soft_scores = supports_soft_scores
        self._label_ordering = label_ordering
        self._response_provider = response_provider
        if threshold is not None:
            self.threshold = threshold

    @property
    def predict_endpoint(self):
        return self._predict_endpoint

    @property
    def supports_soft_scores(self):
        return self._supports_soft_scores

    @property
    def label_ordering(self) -> Optional[List[Any]]:
        return self._label_ordering

    @label_ordering.setter
    def label_ordering(self, labels):
        self._label_ordering = labels

    @predict_endpoint.setter
    def predict_endpoint(self, predict_endpoint):
        log.info(f"Updating predict_endpoint to: {predict_endpoint}")
        self._predict_endpoint = predict_endpoint

    def _do_call(self, url, payload, **kwargs) -> dict:
        headers = {'Content-Type': 'application/json'} if not self.headers else self.headers
        retries = kwargs.pop('retries', 5)
        if not _session:
            create_session()
        [setattr(adapter.max_retries, 'total', retries) for _, adapter in _session.adapters.items()]
        resp = _session.post(
            url,
            data=json.dumps(payload),
            headers=headers,
            **kwargs
        )

        # For server side errors check to see if we have a structured response containing
        # error details
        if 500 <= resp.status_code < 600:
            try:
                resp_payload = json.loads(resp.text)
                err = resp_payload.get('payload', {}).get('error')
            except ValueError:
                err = f"Server 500 error: {resp.text}" if len(resp.text or '') > 0 else None
        else:
            err = None

        if err is not None:
            raise ValueError(f"Model server error: {err}")

        resp.raise_for_status()

        # assume always JSON, regardless of content-type header
        return json.loads(resp.text)

    def _predict_batch(self, batch, **kwargs) -> PredictResponse:
        columns = kwargs.get('columns')
        if columns:
            payload = {"payload": {"instances": batch, "columns": columns}}
        else:
            payload = {"payload": {"instances": batch}}

        if self._response_provider is None:
            resp_data = self._do_call(self.predict_endpoint, payload, **kwargs)
        else:
            resp_data = self._response_provider(self.predict_endpoint, payload)

        if "payload" in resp_data:
            payload = resp_data['payload']
            success = payload.get('success', True)
            error = payload.get('error', '')
            predictions = payload.get('predictions', None) if success else None
            if predictions is not None:
                prediction_values = np.asarray(predictions, dtype=object)
                self.records_evaluated += len(batch)

                # Sanity check shape of results and handle easily detectable bad cases as distinguished errors
                if len(prediction_values.shape) != 1:
                    raise ValueError("Model unexpectedly returned multi-dimensional predictions")
                elif len(prediction_values) != len(batch):
                    raise ValueError(f"Model returned {len(prediction_values)} predictions for batch size of {len(batch)}")

                scores_raw = payload.get('scores', None)
                if scores_raw is not None:
                    scores = np.array(scores_raw, dtype=float)
                    if scores.shape[0] != len(batch):
                        raise ValueError(f"Model returned {scores.shape[0]} scores for batch size of {len(batch)}")
                else:
                    scores = None

                labels = payload.get('labels', None)
                threshold = payload.get('threshold', None)
                return PredictResponse(prediction_values, scores, labels, threshold)
            else:
                log.error(f"Unsuccessful response from model endpoint: {resp_data}, error='{error}")
                raise ValueError(f"Model failed to evaluate batch ({error}).")
        else:
            log.error(f"Invalid response from model endpoint: {resp_data}")
            raise ValueError(f"Invalid response from model endpoint: {self.predict_endpoint}, no 'payload.predictions' field in JSON.")

    def _predict(self, values, **kwargs):
        if isinstance(values, np.ndarray):
            values = values.tolist()
        elif not isinstance(values, list):
            raise ValueError(f"Values must be a list or numpy array.")
        idx = 0
        resp_values = None
        while idx < len(values):
            if self.max_batch_size is not None:
                batch = values[idx:idx+self.max_batch_size]
                idx += self.max_batch_size
            else:
                batch = values
                idx = len(values)
            batch_result = self._predict_batch(batch, **kwargs)
            predictions = batch_result.predictions
            if resp_values is None:
                resp_values = predictions
            else:
                resp_values = np.concatenate([resp_values, predictions], axis=0)

        return resp_values

    def _soft_predict(self, values, **kwargs) -> np.ndarray:
        if isinstance(values, np.ndarray):
            values = values.tolist()
        elif not isinstance(values, list):
            raise ValueError(f"Values must be a list or numpy array.")
        idx = 0
        resp_values = None
        threshold = None
        labels = None
        while idx < len(values):
            if self.max_batch_size is not None:
                batch = values[idx:idx+self.max_batch_size]
                idx += self.max_batch_size
            else:
                batch = values
                idx = len(values)
            batch_result = self._predict_batch(batch, **kwargs)
            if batch_result.scores is None:
                raise ValueError(f"Invalid response from model endpoint: {self.predict_endpoint}, no 'payload.predictions' fields in JSON")
            if resp_values is None:
                resp_values = batch_result.scores
                threshold = batch_result.threshold
                labels = batch_result.labels
            else:
                if (threshold is not None) and (threshold != batch_result.threshold):
                    raise ValueError(f"Invalid response from model endpoint: {self.predict_endpoint}, inconsistent score threshold")
                if (labels is not None) and (labels != batch_result.labels):
                    raise ValueError(f"Invalid response from model endpoint: {self.predict_endpoint}, inconsistent labels")
                resp_values = np.concatenate([resp_values, batch_result.predictions], axis=0)

        perm = _construct_label_permutation(labels, self.label_ordering)
        if perm is not None:
            resp_values = resp_values[:, perm]

        if threshold is not None:
            self.threshold = threshold

        return resp_values


class IConnectionFactory(ABC):
    """
    Abstract class for supporting various model connectors
    """
    def get_instance(self, predict_url: str, **kwargs) -> IHostedModel:
        ...


class ExternalConnectionFactory(IConnectionFactory):
    def __init__(self, module_name: str, connector_class_name: Optional[str] = None, inst_args: Dict = None):
        self._module_name = module_name
        self._connector_class_name = connector_class_name
        self._inst_args = inst_args if inst_args else {}

    def get_instance(self, predict_url: str, **kwargs) -> IHostedModel:
        args = {**self._inst_args, **kwargs}
        return self.make_connection(predict_url, self._module_name, self._connector_class_name, **args)

    @staticmethod
    def make_connection(predict_url: str, module_name: str, connector_class_name: Optional[str] = None,
                        **kwargs) -> IHostedModel:
        from importlib import import_module
        mod = import_module(module_name)
        return mod.get_connector(predict_url, connector_class_name=connector_class_name, **kwargs)


__supported_connectors__ = ['HostedModel', 'LocalHostedModel']


# __future__work to support moving local and hosted models to be instantiated using ExternalConnectionFactory
def get_connector(predict_endpoint: str, connector_class_name, **kwargs):
    if connector_class_name not in __supported_connectors__:
        raise CertifaiValidationException(connector_class_name, ['connector class not supported',
                                                           'list of supported connector classes',
                                                           __supported_connectors__])

    # load connector class by reflection
    klass = getattr(sys.modules[__name__], connector_class_name)
    return klass(predict_endpoint, **kwargs)
