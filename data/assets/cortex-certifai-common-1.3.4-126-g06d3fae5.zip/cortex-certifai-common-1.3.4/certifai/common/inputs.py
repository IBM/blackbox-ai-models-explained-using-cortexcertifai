"""
Common utils for reading datasets
"""
import numpy as np

from certifai.common.utils import get_logger
from certifai.common.types import DataTypeEnum, RestrictionStringEnum


log = get_logger()


def get_cfi_category_features(feature_schema, dataset_df):
    """ returns the categories list of values,
    if no categories are set, it tries to get unique values in column,
    if data type is numeric they remain as such since we're not changing the
    type here, although that might become required at some point.
    """
    if feature_schema.categories:
        values = np.array(feature_schema.categories)
        # Allow for schema specified values to be encoded as strings even for numeric features
        # check:
        #   feature is present
        #   encoding is a string
        #   feature is not a string
        if (feature_schema.feature_name in dataset_df.columns) and \
           (values.dtype.char in ('U', 'S')) and \
           (dataset_df.dtypes[feature_schema.feature_name].char != 'O'):
            values = values.astype('int').astype('object')
        elif values.dtype == np.dtype('int64'):
            values = values.astype('object')   # else we get int64 which cannot be rendered to json by the json lib
    else:
        if feature_schema.feature_name in dataset_df.columns:
            values = np.unique(dataset_df[feature_schema.feature_name])
        else:
            values = None
        feature_schema.categories = values.tolist() if values is not None else None

    return {"category_values": values}


def get_cfi_numerical_features(feat_schema, data_type):
    if data_type == DataTypeEnum.numerical_int:
        features = {
            "min": np.int64(feat_schema.min),
            "max": np.int64(feat_schema.max),
        }
    else:
        features = {
            "min": np.float64(feat_schema.min),
            "max": np.float64(feat_schema.max),
        }

    features.update({"mad": np.float64(feat_schema.mad)})

    return features

