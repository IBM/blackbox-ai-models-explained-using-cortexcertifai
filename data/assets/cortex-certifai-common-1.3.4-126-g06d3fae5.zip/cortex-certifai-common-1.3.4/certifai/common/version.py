__version__ = '1.3.4-126-g06d3fae5'

def get_version():
    return __version__.split('-', 1)[0]

def get_full_version():
    return __version__
