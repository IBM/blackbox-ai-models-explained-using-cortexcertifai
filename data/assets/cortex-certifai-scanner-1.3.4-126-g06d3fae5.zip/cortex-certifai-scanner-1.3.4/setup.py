"""
Copyright 2019 Cognitive Scale, Inc. All Rights Reserved.

See LICENSE.txt for details.

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
"""

from setuptools import find_packages
from setuptools import setup

__version__ = '1.3.4'

with open('README.md', 'r') as f:
    long_description = f.read()


setup(
    name='cortex-certifai-scanner',
    description="CLI Scanner for the CognitiveScale Certifai AI Auditor",
    long_description=long_description,
    long_description_content_type='text/Markdown',
    version=__version__,
    author='CognitiveScale',
    author_email='info@cognitivescale.com',
    url='https://www.cognitivescale.com/',
    license='LICENSE.txt',
    platforms=['linux', 'osx', 'windows'],
    packages=find_packages(exclude=["test"]),
    include_package_data=True,
    exclude_package_data={'': ['tests']},
    install_requires=['numpy>=1.16.2,<1.19',
                      'pandas>=0.23.4,<=1.0.3',
                      'marshmallow>=3.0.0,<4.0',
                      'pyyaml>=3.13,<6.0',
                      'python-dateutil>=2.6.1,<3.0',
                      'Jinja2>=2.10.3,<3.0',
                      'dataclasses>=0.6,<1.0; python_version<="3.6"'
                      ],

    extras_require={
    },


    tests_require=[
        'pipdeptree',
        'pytest-cov==2.7.1',
        'pytest==4.6.4',
        'pytest-mock==1.12.1',
        'hypothesis==5.5.0', # needed for common testutils
        'tox==3.14.0',
    ],

    classifiers=[
        'Operating System :: MacOS :: MacOS X',
        'Operating System :: POSIX',
        'Programming Language :: Python :: 3.6',
        'Operating System :: Microsoft :: Windows :: Windows 10',
    ],

    entry_points={
        'console_scripts': []
    }
)
