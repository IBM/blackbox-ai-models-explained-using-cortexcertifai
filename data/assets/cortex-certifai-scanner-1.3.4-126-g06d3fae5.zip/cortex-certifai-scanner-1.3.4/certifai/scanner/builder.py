"""
Certifai Scan object model builder

Contains classes representing a Certifai scan definition, and the ability to programmatically
manipulate, load, save and run them.
"""
from typing import Optional, List, Any, Tuple, Iterable, Union, Callable, Sequence, Dict
from abc import ABC
from collections import defaultdict
from copy import deepcopy, copy
import builtins
import yaml
import pandas as pd
import re

from certifai.engine.engine_api_types import CertifaiAnalysis, CertifaiTaskType, MetricTypes, FairnessMetric, ExplanationType
from certifai.common.hosted_model import LocalHostedModel, IBaseModel, IHostedModel
from certifai.common.utils.fn_utils import fmap_opt
from certifai.scanner.schemas import (ScanTemplate, Evaluation, Scoring, DatasetSchemaDef, Scan, ScanTemplateSchema,
                                      ModelUseCase, Metric, Model, MetricValue, Dataset, DatasetFeatureSchema,
                                      FairnessGrouping, FeatureBucket, ModelHeaders, PredictionValue,
                                      JSON_ORIENTS, DEFAULT_JSON_ORIENT, DEFAULT_JSON_LINES, DEFAULT_CSV_HAS_HEADER,
                                      DATASET_ENCODINGS, EVALUATION_TYPES, ALPHA_NUMERIC_REGEX, DefaultModelHeader,
                                      DefinedModelHeader, ModelConnector, FeatureRestrictions, ModelArgs, ModelConnectorSecrets,
                                      OneHotColumn)
from certifai.scanner.certifai_scan import read_blueprint, process_blueprint
from certifai.common.types import ModelHeaderTypeEnum, PredictionFavorabilityEnum, RestrictionStringEnum
from certifai.scanner.generator.scan_generator import generate_feature_schemas
from certifai.scanner.certifai_scan import materialize_dataset
from certifai.common.progress_task import ProgressUpdate, ProgressBarListener

DEFAULT_EVAL_DATASET_ID = 'eval'


_id_matcher = re.compile(ALPHA_NUMERIC_REGEX)


def _name_val_list_to_dict(nvl):
    return {_.name: _.value for _ in nvl}


def _validate_id(id: str):
    if not _id_matcher.match(id):
        raise ValueError("ids contain only alphanumeric characters and '_'")


class _DataEquality:
    """Helper base class that defines equality as memberwise equality for subclasses."""
    def __eq__(self, other):
        if type(other) is type(self):
            return self.__dict__ == other.__dict__
        return False


class CertifaiOutcomeValue:
    def __init__(self, value: Any, name: Optional[str]=None, favorable: bool=False):
        def favorability():
            return 'Favorable' if favorable else 'Unfavorable'

        self.value = value
        self.name = name if name is not None else f"{favorability()} - {str(value)}"
        self.favorable = favorable


class CertifaiTaskOutcomes(ABC):
    """Union type representing the outcomes of a task by type (possible classes for classification,
       favorable direction for regression)"""

    @property
    def task_type(self) -> CertifaiTaskType:
        ...

    @property
    def prediction_favorability(self) -> str:
        ...

    @staticmethod
    def regression(increased_favorable: Optional[bool],
                   change_std_deviation: Optional[float]=None,
                   absolute_threshold: Optional[float]=None,
                   absolute_percentile: Optional[float]=None):
        """Construct a regression task type

           Favorability may be specified in one of three ways (only one of which may be specified):

                1. As a relative increase [or decrease] by a multiple
                   of the population global regressed value standard deviation
                2. As an absolute threshold, specified as an exact value of the regressor output
                3. As an absolute threshold, specified as a percentile of the population global regressed
                   value empirical distribution

        :param Optional[bool] increased_favorable: True if the favorable direction of the prediction is increasing.
               Can be set to None if there is no favorable direction.
        :param Optional[float] change_std_deviation: Number of standard deviations considered to be a significant change
        :param Optional[float] absolute_threshold: Absolute regressed value threshold for favorability
        :param Optional[float] absolute_percentile: Absolute regressed value threshold for favorability expressed as a population percentile
        :return: CertifaiTaskType instance representing the regression outcome definition
        """
        num_params_specified = 0
        if change_std_deviation is not None:
            num_params_specified += 1
        if absolute_threshold is not None:
            num_params_specified += 1
        if absolute_percentile is not None:
            if (absolute_percentile <= 0.) or (absolute_percentile >= 100.):
                raise ValueError("'absolute_percentile' must in in the range (0, 100)")
            num_params_specified += 1
        if num_params_specified != 1:
            raise ValueError("Exactly one of 'change_std_deviation', 'absolute_threshold', or 'absolute_percentile' must be specified")

        return _CertifaiRegressionTask(increased_favorable,
                                       change_std_deviation,
                                       absolute_threshold,
                                       absolute_percentile)

    @staticmethod
    def classification(prediction_values: Iterable[CertifaiOutcomeValue],
                       prediction_favorability: Optional[str] = PredictionFavorabilityEnum.explicit.value,
                       last_favorable_prediction: Optional[Any] = None,
                       favorable_outcome_group_name: Optional[str] = None,
                       unfavorable_outcome_group_name: Optional[str] = None):
        """Construct a classification task type

        :param Iterable[CertifaiClassificationPrediction] prediction_values: list of possible classes
        :param Optional[str] prediction_favorability: describes the favorability of the prediction_values, default 'explicit'. Must be one of
                - 'explicit', predictions should be explicitly marked as favorable
                - 'ordered', predictions are ordered from most to least favorable
                - 'none', no prediction should be treated as favorable
        :param Optional[Any] last_favorable_prediction - ignored unless the `prediction_favorability` is 'ordered', in which
               case this value should be the last label (in the ordering of the `prediction_values` which is considered favorable
        :param Optional[str] favorable_outcome_group_name: name of favorable group of prediction values - reserved for
                multiclass-classification task's with a prediction_favorablity of 'explicit'
        :param Optional[str] unfavorable_outcome_group_name: name of unfavorable groups of prediction values - reserved for
                multiclass-classification task's with a prediction_favorability of 'explicit'
        :return: CertifaiTaskType instance representing the classification outcome definition
        """
        values_list = list(prediction_values)
        if (last_favorable_prediction is not None) and (last_favorable_prediction not in values_list):
            raise ValueError(f"Label '{last_favorable_prediction}' is not one of the provided prediction values")

        return _CertifaiClassificationTask(prediction_values, prediction_favorability, last_favorable_prediction,
                                           favorable_outcome_group_name, unfavorable_outcome_group_name)


class _CertifaiRegressionTask(CertifaiTaskOutcomes):
    def __init__(self,
                 increased_favorable: Optional[bool],
                 change_std_deviation: Optional[float]=None,
                 absolute_threshold: Optional[float]=None,
                 absolute_percentile: Optional[float]=None):
        self.increased_favorable = increased_favorable
        self.change_std_deviation = change_std_deviation
        self.absolute_threshold = absolute_threshold
        self.absolute_percentile = absolute_percentile

    @property
    def task_type(self) -> CertifaiTaskType:
        return CertifaiTaskType.REGRESSION

    @property
    def prediction_favorability(self) -> str:
        return 'none' if self.increased_favorable is None else 'ordered'


class _CertifaiClassificationTask(CertifaiTaskOutcomes):
    def __init__(self,
                 prediction_values: Iterable[CertifaiOutcomeValue],
                 prediction_favorability: Optional[str] = PredictionFavorabilityEnum.explicit.value,
                 last_favorable_prediction: Optional[Any] = None,
                 favorable_outcome_group_name: Optional[str] = None,
                 unfavorable_outcome_group_name: Optional[str] = None):
        self.prediction_values = list(prediction_values)
        self.prediction_fav = prediction_favorability
        self.last_favorable_prediction = last_favorable_prediction

        if self.task_type == CertifaiTaskType.MULTICLASS_CLASSIFICATION and prediction_favorability == PredictionFavorabilityEnum.explicit:
            if favorable_outcome_group_name is None or unfavorable_outcome_group_name is None:
                raise ValueError("favorable_outcome_group_name and unfavorable_outcome_group_name arguments are "
                                 "required for multiclass-classification with a prediction_favorability of explicit")
        else:
            if favorable_outcome_group_name is not None or unfavorable_outcome_group_name is not None:
                raise ValueError("favorable_outcome_group_name and unfavorable_outcome_group_name arguments are "
                                 "reserved for multiclass-classification with a prediction_favorability of explicit")

        self.favorable_outcome_group_name = favorable_outcome_group_name
        self.unfavorable_outcome_group_name = unfavorable_outcome_group_name

    @property
    def task_type(self) -> CertifaiTaskType:
        return CertifaiTaskType.BINARY_CLASSIFICATION if len(self.prediction_values) <= 2 else CertifaiTaskType.MULTICLASS_CLASSIFICATION

    @property
    def prediction_favorability(self) -> str:
        return self.prediction_fav


class CertifaiPredictionTask(_DataEquality):
    """Metadata about the prediction task - immutable once instantiated."""
    def __init__(self,
                 outcomes: CertifaiTaskOutcomes,
                 prediction_description: Optional[str]=None):
        """

        :param CertifaiTaskOutcomes outcomes: One of the supported CertifaiTaskOutcomes types, constructed
               from the static methods on `CertifaiTaskOutcomes`.
        :param Optional[str] prediction_description: Free text description of what is being predicted.
        """
        self._outcomes = outcomes
        self._prediction_description = prediction_description

    @property
    def task_type(self) -> str:
        """
        The task type string ('binary_classification', 'multiclass-classification', 'regression')

        :getter: Returns the task type.
        :type: str
        """
        return str(self._outcomes.task_type)

    @property
    def prediction_description(self) -> Optional[str]:
        """
        Description of what the prediction represents.

        :getter: Returns the description, if any.
        :type: Optional[str]
        """
        return self._prediction_description

    @property
    def prediction_favorability(self) -> Optional[str]:
        """
        What format is used for specifying the favorable prediction value, if any, ('none', 'ordered', 'explicit').

        :getter: Returns prediction favorability
        :type: Optional[str]
        """
        return self._outcomes.prediction_favorability

    @property
    def favorable_outcome(self) -> Optional[str]:
        """
        What the favorable outcome direction is for a regression task, None otherwise.

        :getter: Returns the favorable label direction (regression) if set.
        :type: Optional[Any]
        """
        if isinstance(self._outcomes, _CertifaiRegressionTask):
            if self.prediction_favorability == 'none':
                return None
            return 'increased' if self._outcomes.increased_favorable else 'decreased'
        return None

    @property
    def prediction_values(self) -> List[CertifaiOutcomeValue]:
        if isinstance(self._outcomes, _CertifaiClassificationTask):
            return self._outcomes.prediction_values
        else:
            return []

    @property
    def last_favorable_prediction(self) -> Optional[Any]:
        if isinstance(self._outcomes, _CertifaiClassificationTask):
            return self._outcomes.last_favorable_prediction
        else:
            return None

    @property
    def regression_standard_deviation(self) -> Optional[float]:
        if isinstance(self._outcomes, _CertifaiRegressionTask):
            return self._outcomes.change_std_deviation
        else:
            return None

    @property
    def regression_absolute_threshold(self) -> Optional[float]:
        if isinstance(self._outcomes, _CertifaiRegressionTask):
            return self._outcomes.absolute_threshold
        else:
            return None

    @property
    def regression_absolute_percentile(self) -> Optional[float]:
        if isinstance(self._outcomes, _CertifaiRegressionTask):
            return self._outcomes.absolute_percentile
        else:
            return None

    @property
    def favorable_outcome_group_name(self) -> Optional[str]:
        """
        The string name of the favorable group of prediction values - reserved for multiclass-classification with
        prediction_favorability of 'explicit' - None otherwise.

        :getter: Return name of favorable group of prediction values
        :type: Optional[str]
        """
        if isinstance(self._outcomes, _CertifaiClassificationTask):
            return self._outcomes.favorable_outcome_group_name
        else:
            return None

    @property
    def unfavorable_outcome_group_name(self) -> Optional[str]:
        """
        The string name of the unfavorable group of prediction values - reserved for multiclass-classification with
        prediction_favorability of 'explicit' - None otherwise.

        :getter: Return name of unfavorable group of prediction values
        :type: Optional[str]
        """
        if isinstance(self._outcomes, _CertifaiClassificationTask):
            return self._outcomes.unfavorable_outcome_group_name
        else:
            return None


# Just alias the existing enum since we don't need to add anything
CertifaiFairnessMetric = FairnessMetric


class CertifaiModelMetric(_DataEquality):
    """Metadata for a metric - immutable once instantiated"""
    def __init__(self, name: str, certifai_metric: Optional[str]=None):
        """

        :param str name: Free text descriptive name of the metric.
        :param Optional[str] certifai_metric: If specified will allow Certifai to calculate the value.
                 Supported values are:
                   * 'accuracy' (classification)
                   * 'precision' (classification)
                   * 'recall' (classification)
                   * 'f1'  (classification)
                   * 'r-squared' (regression)
        """
        self._name = name
        self._certifai_metric = str(MetricTypes.from_str(certifai_metric)) if certifai_metric is not None else None

    @property
    def name(self) -> str:
        """
        Descriptive name of the metric.

        :getter: Returns the human-readable metric name.
        :type: str
        """
        return self._name

    @property
    def certifai_metric(self) -> Optional[str]:
        """
        Certifai metric type name.

        :getter: Returns the Certifai-evaluable metric type (if set).
        :type: Optional[str]
        """
        return self._certifai_metric


# Model-related

class CertifaiPredictorWrapper:
    """Wrapper class for in-process models"""
    def __init__(self,
                 predictor: IBaseModel,
                 encoder: Optional[Callable[[Sequence], Sequence]]=None,
                 decoder: Optional[Callable[[Sequence], Sequence]]=None,
                 wrapped: Optional[IHostedModel]=None,
                 soft_predictions: bool=False,
                 label_ordering: Optional[List[Any]]=None,
                 threshold: Optional[float]=None):
        """

        :param `IBaseModel` predictor: Any predictor object that has a `predict` method
                            which takes a sequence of data vectors as a numpy array and returns
                            a sequence of corresponding predicted values.
        :param Optional[Callable[[Sequence],Sequence]] encoder: optional function used to
                            transform the predictor's input (e.g. - to perform one-hot encoding and so on)
        :param Optional[Callable[[Sequence],Sequence]] decoder: optional function used to
                            transform the predictor's output (e.g. - to binarize with a threshold).
        :param Optional[IHostedModel] wrapped: if specified other parameters are ignored and the wrapper
                            just proxies the (already wrapped) model provided here (mostly intended for
                            internal usage).
        :param bool soft_predictions: If True the model supports soft scoring for predictions (default False)
        :param Optional[List[Any]] label_ordering: For soft scoring models the ordering of the classification labels
                            in the scoring vector
        :param Optional[float] threshold: For binary classifiers whose soft-scores are returned as a 1-dimensional
                            array of scores, one for each input row, the threshold to apply.  Scores greater than or equal
                            to the threshold will receive the second label (or 1 rather than 0 if no labels provided)

        *Note* - the underlying model and any encoder and decoders used must be picklable.
        """
        if wrapped is None:
            if isinstance(predictor, IHostedModel):
                soft_predictions = predictor.supports_soft_scores
                if label_ordering is None:
                    label_ordering = predictor.label_ordering

            self._model = LocalHostedModel(predictor,
                                           soft_predictions=soft_predictions,
                                           label_ordering=label_ordering,
                                           threshold=threshold)
            if encoder is not None:
                self._model = self._model.contramap(encoder)
            if decoder is not None:
                self._model = self._model.map(decoder)
        else:
            self._model = wrapped

    @property
    def model(self) -> IHostedModel:
        """
        Certifai metric type name.

        :getter: Returns the wrapped model suitable for use by Certifai.
        :type: `IHostedModel`
        """
        return self._model


class CertifaiModelConnector(_DataEquality):
    """Metadata for a model connector"""
    def __init__(self,
                 name: str,
                 module_name: str,
                 class_name: str,
                 description: Optional[str]=None,
                 model_args: Dict[str, str]={},
                 model_secrets: Dict[str,str]={}):
        """

        :param str name: Free text descriptive name of the connector.
        :param str module_name: python module containingthe external connector (e.g. 'certifai.connectors')
        :param str class_name: name of python class of the connector
        :param description Optional[str]: Optional description
        :param model_args Dict[str,str]: arguments to pass to the model connector instances
        :param model_secrets Dict[str,str]: secrets to pass to the model connector instances - substrings
                                            of the values of the form `{<NAME>}` will have the `<NAME>`
                                            replaced by the contents of the environment variable of that name
        """
        self._name = name
        self._module_name = module_name
        self._class_name = class_name
        self._description = description
        self._model_args = model_args if model_args is not None else {}
        self._model_secrets = model_secrets if model_secrets is not None else {}

    @property
    def name(self) -> str:
        """
        Descriptive name of the connector.

        :getter: Returns the connector name.
        :type: str
        """
        return self._name

    @property
    def module_name(self) -> str:
        """
        Module containing the connector.

        :getter: Returns the fully qualified module name.
        :type: str
        """
        return self._module_name

    @property
    def class_name(self) -> str:
        """
        Class name of the connector.

        :getter: Returns the name of the python class of the connector.
        :type: str
        """
        return self._class_name

    @property
    def description(self) -> str:
        """
        Description of the connector.

        :getter: Returns the optional description.
        :type: str
        """
        return self._description

    @property
    def model_args(self) -> Dict[str,str]:
        """
        Arguments to instantiated model connector instances.

        :getter: Returns the arguments to be provided to connector instances.
        :type: Dict[str,str]
        """
        return self._model_args

    @property
    def model_secrets(self) -> Dict[str,str]:
        """
        Secrets provided to instantiated model connector instances.

        :getter: Returns the secrets to be provided to connector instances.
        :type: Dict[str,str]
        """
        return self._model_secrets


class CertifaiModel:
    """Metadata describing a model, and allowing manipulation of this metadata."""
    def __init__(self,
                 id: str,
                 name: Optional[str]=None,
                 author: Optional[str]=None,
                 version: Optional[str]=None,
                 performance_metric_values: Optional[List[Tuple]]=None,
                 description: Optional[str]=None,
                 predict_endpoint: Optional[str]=None,
                 max_batch_size: Optional[int]=None,
                 local_predictor: Optional[CertifaiPredictorWrapper]=None,
                 supports_soft_scoring: bool=False,
                 prediction_value_order: Optional[List[Any]]=None,
                 connector: Optional[CertifaiModelConnector]=None):
        """

        :param str id: Identifier for the model used to refer to it.
        :param Optional[str] name: Descriptive name for the model.  Defaults to the
                                 value provided for `id`
        :param Optional[str] author: Optional author name.
        :param Optional[str] version: Optional model version string.
        :param Optional[List[Tuple]] performance_metric_values: Optional asserted list of (`metric_name`, `value`)
                                     pairs for metrics of the model - primarily intended to allow injection of externally
                                     measured values for metrics not directly supported by Certifai.
        :param Optional[str] description: Optional free text description of the model.
        :param Optional[str] predict_endpoint: URL of the prediction endpoint of the model (if non-process-local).
        :param Optional[int] max_batch_size: Optional limit on prediction batch sizes to call the model with.
        :param Optional[CertifaiPredictorWrapper] local_predictor: wrapped model object (if using a local in-process model).
        :param bool supports_soft_scoring: If True model is expected to return soft scores as well as hard predictions
        :param List[Any[ prediction_value_order: For soft scoring models the ordering of the class labels in the score vector
        :param Optional[CertifaiModelConnector] connector: Optional connector to use to attach to the model
        """
        _validate_id(id)
        self._id = id
        self._name = name or id
        self._author = author
        self._version = version
        self._description = description
        self._predict_endpoint = predict_endpoint
        self._performance_metric_values = \
            {k: v for k, v in performance_metric_values} if performance_metric_values is not None else {}
        self._max_batch_size = max_batch_size
        self._local_predictor = local_predictor
        if local_predictor is not None:
            self._supports_soft_scoring = local_predictor.model.supports_soft_scores
            if local_predictor.model.label_ordering is not None:
                self._prediction_value_order = list(local_predictor.model.label_ordering)
            else:
                self._prediction_value_order = None
        else:
            self._supports_soft_scoring = supports_soft_scoring
            self._prediction_value_order = prediction_value_order
        self._connector = connector

    @property
    def name(self) -> str:
        """
        Model name.

        :getter: Returns the human-readable name of the model.
        :type: str
        """
        return self._name

    @property
    def id(self) -> str:
        """
        Model id.

        :getter: Returns the identifier for the model by which it may be referenced.
        :type: str
        """
        return self._id

    @property
    def author(self) -> Optional[str]:
        """
        Model author.

        :getter: Returns the author string if provided.
        :setter: Set author string for the model.
        :type: Optional[str]
        """
        return self._author

    @author.setter
    def author(self, value: Optional[str]):
        self._author = value

    @property
    def version(self) -> Optional[str]:
        """
        Model version.

        :getter: Returns the version string if provided.
        :setter: Set version string for the model.
        :type: Optional[str]
        """
        return self._version

    @version.setter
    def version(self, value: Optional[str]):
        self._version = value

    @property
    def description(self) -> Optional[str]:
        """
        Model description.

        :getter: Returns the description string if provided.
        :setter: Set description string for the model.
        :type: Optional[str]
        """
        return self._description

    @description.setter
    def description(self, value: Optional[str]):
        self._description = value

    @property
    def predict_endpoint(self) -> Optional[str]:
        """
        Model predict endpoint URL

        :getter: Returns the URL of the (remote) model prediction endpoint, if provided
        :setter: Sets the prediction endpoint URL for the model
        :type: Optional[str]
        """
        return self._predict_endpoint

    @predict_endpoint.setter
    def predict_endpoint(self, value: Optional[str]):
        self._predict_endpoint = value

    @property
    def max_batch_size(self) -> Optional[int]:
        """
        Model max batch size.

        :getter: Returns the max batch size to send to the model.
        :setter: Sets the provided restriction on max batch size (None => unlimited).
        :type: Optional[int]
        """
        return self._max_batch_size

    @max_batch_size.setter
    def max_batch_size(self, value: Optional[int]):
        self._max_batch_size = value

    @property
    def supports_soft_scoring(self) -> bool:
        """
        Whether the model returns soft scores.

        :getter: True if the model is expected to upport soft scores.
        :setter: Sets whether the model is expected to support soft scores.
        :type: bool
        """
        return self._supports_soft_scoring

    @supports_soft_scoring.setter
    def supports_soft_scoring(self, value: bool):
        self._supports_soft_scoring = value

    @property
    def prediction_value_order(self) -> bool:
        """
        Ordering of class labels in the score vector returned by the model.

        :getter: Returns the ordering.
        :setter: Sets the ordering.
        :type: List[Any]
        """
        return self._prediction_value_order

    @prediction_value_order.setter
    def prediction_value_order(self, value: List[Any]):
        self._prediction_value_order = value

    @property
    def local_predictor(self) -> Optional[CertifaiPredictorWrapper]:
        """
        Wrapped local (in-process) model.

        :getter: Returns the wrapped model being used.
        :setter: Sets a local wrapped model (see :class:`CertifaiPredictorWrapper`) to use.
        :type: Optional[CertifaiPredictorWrapper]
        """
        return self._local_predictor

    @local_predictor.setter
    def local_predictor(self, value: Optional[CertifaiPredictorWrapper]):
        self._local_predictor = value

    @property
    def performance_metric_values(self) -> List[Tuple[str, Any]]:
        """
        List of asserted metric values for this model.

        :getter: Returns any asserted values as (`metric name`, `value`) tuples.
        :type: List[Tuple[str,Any]]
        """
        return [(name, value) for name, value in self._performance_metric_values.items()]

    def add_performance_metric_value(self, metric_name: str, metric_value: Any):
        """Add an asserted performance metric value.

        :param str metric_name: Name of the metric to assert a value for.
        :param Any value: Value to assert.
        """
        self._performance_metric_values[metric_name] = metric_value

    def remove_performance_metric_value(self, metric_name: str):
        """Remove an asserted metric value

        :param metric_name: name of the metric to remove the asserted value for.
        """
        if metric_name not in self._performance_metric_values:
            raise ValueError(f"Metric '{metric_name}' does not have a value defined for this model")
        del self._performance_metric_values[metric_name]

    @property
    def connector(self) -> Optional[CertifaiModelConnector]:
        return self._connector

    @connector.setter
    def connector(self, value: Optional[CertifaiModelConnector]):
        self._connector = value


def _certifai_model_from_template_model(model: Model, connector: Optional[CertifaiModelConnector]) -> CertifaiModel:
    if (model.hosted_model is not None) and isinstance(model.hosted_model, LocalHostedModel):
        local_predictor = CertifaiPredictorWrapper(wrapped=model.hosted_model)
    else:
        local_predictor = None
    return CertifaiModel(id=model.model_id,
                         name=model.name,
                         max_batch_size=model.max_batch_size,
                         predict_endpoint=model.predict_endpoint,
                         performance_metric_values=[(m.name, m.value) for m in model.performance_metric_values],
                         description=model.description,
                         version=model.version,
                         author=model.author,
                         local_predictor=local_predictor,
                         supports_soft_scoring=model.supports_soft_scoring,
                         prediction_value_order=model.prediction_value_order,
                         connector=connector)


def _template_model_from_certifai_model(model: CertifaiModel) -> Model:
    return Model(model_id=model.id,
                 name=model.name,
                 max_batch_size=model.max_batch_size,
                 predict_endpoint=model.predict_endpoint,
                 performance_metric_values=[MetricValue(name=m[0], value=m[1]) for m in model.performance_metric_values],
                 description=model.description,
                 version=model.version,
                 author=model.author,
                 hosted_model=model.local_predictor.model if model.local_predictor is not None else None,
                 supports_soft_scoring=model.supports_soft_scoring,
                 prediction_value_order=model.prediction_value_order)


# Schema related

class CertifaiFeatureDataType:
    """Class describing feature datatypes supported by Certifai - immutable once instantiated.
    Static methods are provided for instantiating each supported type."""
    def __init__(self, args: dict):
        self._args = args

    @property
    def value_dict(self) -> dict:
        """
        Data type details as a dictionary.

        :getter: Returns the metadata dict for this datatype.  In particular
                 this will contain a key named `data_type` which will be one of
                   - 'numerical-int'
                   - 'numerical-float'
                   - 'categorical'
                 Other keys vary by datatype.
        :type: dict
        """
        return deepcopy(self._args)

    @staticmethod
    def _validate_numeric(d):
        if ('min' in d) and ('max' in d) and d['min'] > d['max']:
            raise ValueError(f"Feature bounds [{min},{max}] are invalid")

    @staticmethod
    def _validate_categorical(d):
        if ('category_values' in d) and len(d['category_values']) == 0:
            raise ValueError("Category values must not be empty")

    @staticmethod
    def int(min: Optional[builtins.int]=None,
            max: Optional[builtins.int]=None,
            spread: Optional[float]=None) -> 'CertifaiFeatureDataType':
        """Constructor for an 'int' feature.

        :param Optional[int] min: optional floor value this feature can take.
        :param Optional[int] max: optional ceiling value this feature can take.
        :param Optional[float] spread: optional measure of spread (typically MAD or std. deviation).
        :return: instantiated `CertifaiFeatureDataType`
        :rtype: `CertifaiFeatureDataType`
        """
        base = {
            'data_type': 'numerical-int'
        }
        if min is not None:
            base['min'] = min
        if max is not None:
            base['max'] = max
        if spread is not None:
            base['spread'] = spread

        CertifaiFeatureDataType._validate_numeric(base)
        return CertifaiFeatureDataType(base)

    @staticmethod
    def float(min: Optional[builtins.float]=None,
              max: Optional[builtins.float]=None,
              spread: Optional[float]=None) -> 'CertifaiFeatureDataType':
        """Constructor for an 'float' feature.

        :param Optional[float] min: optional floor value this feature can take.
        :param Optional[float] max: optional ceiling value this feature can take.
        :param Optional[float] spread: optional measure of spread (typically MAD or std deviation).
        :return: instantiated `CertifaiFeatureDataType`
        :rtype: `CertifaiFeatureDataType`
        """
        base = {
            'data_type': 'numerical-float'
        }
        if min is not None:
            base['min'] = float(min)
        if max is not None:
            base['max'] = float(max)
        if spread is not None:
            base['spread'] = spread

        CertifaiFeatureDataType._validate_numeric(base)
        return CertifaiFeatureDataType(base)

    @staticmethod
    def categorical(values: Optional[Iterable[Union[str, builtins.int]]]=None,
                    value_columns: Optional[List[Tuple[str, Union[str, builtins.int]]]]=None,
                    target_encodings: Optional[Iterable[builtins.float]]=None) -> 'CertifaiFeatureDataType':
        """Constructor for a 'categorical' feature.

        :param Optional[Iterable[Union[str,int]]] values: optional list of possible values this
                     categorical field may take on.  If omitted then Certifai will infer the value set
                     from the available data.
        :param Optional[List[Tuple[str,Union[str,builtins.int]]]] value_columns: optional list of
                     categorical value -> column name mappings for one-hot encoded data.  If both
                     `value_columns` and `values` are specified then they must have exactly the same
                     set of values.  If only `value_columns` is specified then the values are inferred.
                     If only `values` is specified then the feature is assumed to be value-encoded in a
                     single column.
        :param Optional[Iterable[float]] target_encodings: optional list of encodings for the values
                     in `values` used to represent those values in the dataset
        :return: instantiated `CertifaiFeatureDataType`
        :rtype: `CertifaiFeatureDataType`
        """
        base = {
            'data_type': 'categorical'
        }
        if value_columns is not None:
            base['one_hot_columns'] = [OneHotColumn(name=n, value=v) for n, v in value_columns]
            inferred_values = [v for _, v in value_columns]
            if values is None:
                values = inferred_values
            elif frozenset(values) != frozenset(inferred_values):
                def render_set(s):
                    return ", ".join([str(e) for e in s])

                raise ValueError(f"The set of 'values' ({render_set(values)}), does not match those given in 'value_columns' ({render_set(inferred_values)})")
        if values is not None:
            if target_encodings is not None:
                if len(target_encodings) != len(values):
                    raise ValueError(f"Number of specified target encodings ({len(target_encodings)}) does not match number of values ({len(values)})")
                base['category_values'] = values
                base['target_encodings'] = target_encodings
            else:
                base['category_values'] = values
        elif target_encodings is not None:
            raise ValueError("'target_encodings' cannot be specified without 'values'")

        CertifaiFeatureDataType._validate_categorical(base)
        return CertifaiFeatureDataType(base)


class CertifaiFeatureRestriction:
    """Class describing feature chnage restrictions supported by Certifai - immutable once instantiated.
    Static methods are provided for instantiating each supported type."""
    def __init__(self, args: dict):
        self._args = args

    @property
    def value_dict(self) -> dict:
        """
        Data type details as a dictionary.

        :getter: Returns the metadata dict for this datatype.  In particular
                 this will contain a key named `constraint` which will be one of
                   - 'constant'
                   - 'percentage'
                   - 'range'
                 Other keys vary by datatype.
        :type: dict
        """
        return deepcopy(self._args)

    @staticmethod
    def _validate_range(d):
        if ('restriction_numerical_min' in d) and ('restriction_numerical_max' in d) and \
           d['restriction_numerical_min'] > d['restriction_numerical_max']:
            raise ValueError(f"Feature bounds [{restriction_numerical_min},{restriction_numerical_max}] are invalid")

    @staticmethod
    def _validate_percentage(d):
        if ('restriction_numerical_percentage' not in d) or d['restriction_numerical_percentage'] < 0:
            raise ValueError("restriction_numerical_percentage must be specified and >= 0")

    @staticmethod
    def range(min: Optional[builtins.int]=None, max: Optional[builtins.int]=None) -> 'CertifaiFeatureRestriction':
        """Constructor for a range constraint on feature modifications in counterfactual production.

        :param Optional[int] min: optional floor value this feature can take.
        :param Optional[int] max: optional ceiling value this feature can take.
        :return: instantiated `CertifaiFeatureRestriction`
        :rtype: `CertifaiFeatureRestriction`
        """
        base = {
            'constraint': 'range'
        }
        if min is not None:
            base['restriction_numerical_min'] = min
        if max is not None:
            base['restriction_numerical_max'] = max

        CertifaiFeatureRestriction._validate_range(base)
        return CertifaiFeatureRestriction(base)

    @staticmethod
    def percentage(amount: float) -> 'CertifaiFeatureRestriction':
        """Constructor for a percentage change constraint on feature modifications in counterfactual production.

        :param float amount: max percentage the feature may change by (can only be applied to numeric features).
        :return: instantiated `CertifaiFeatureRestriction`
        :rtype: `CertifaiFeatureRestriction`
        """
        base = {
            'constraint': 'percentage',
            'restriction_numerical_percentage': amount
        }

        CertifaiFeatureRestriction._validate_percentage(base)
        return CertifaiFeatureRestriction(base)

    @staticmethod
    def constant() -> 'CertifaiFeatureRestriction':
        """Constructor for a no-change constraint on feature modifications in counterfactual production.

        :return: instantiated `CertifaiFeatureRestriction`
        :rtype: `CertifaiFeatureRestriction`
        """
        base = {
            'constraint': 'constant'
        }

        return CertifaiFeatureRestriction(base)


def _scan_feature_restriction2api_restriction(r: FeatureRestrictions) -> CertifaiFeatureRestriction:
    if r.restriction_string == RestrictionStringEnum.no_changes:
        return CertifaiFeatureRestriction.constant()
    elif r.restriction_string == RestrictionStringEnum.min_max:
        return CertifaiFeatureRestriction.range(r.restriction_numerical_min, r.restriction_numerical_max)
    elif r.restriction_string == RestrictionStringEnum.percentage:
        return CertifaiFeatureRestriction.range(r.restriction_numerical_percentage)
    else:
        raise ValueError(f"Unknown restriction type '{r.restriction_string}'")


def _api_restriction2scan_feature_restriction(feature_name: str,
                                              r: CertifaiFeatureRestriction) -> FeatureRestrictions:
    if r.value_dict['constraint'] == 'constant':
        return FeatureRestrictions(feature_name, RestrictionStringEnum.no_changes.value)
    elif r.value_dict['constraint'] == 'range':
        return FeatureRestrictions(feature_name,
                                   RestrictionStringEnum.min_max.value,
                                   restriction_numerical_min=r.value_dict.get('restriction_numerical_min'),
                                   restriction_numerical_max=r.value_dict.get('restriction_numerical_max'))
    elif r.value_dict['constraint'] == 'percentage':
        return FeatureRestrictions(feature_name,
                                   RestrictionStringEnum.percentage.name,
                                   restriction_numerical_percentage=r.value_dict.get('restriction_numerical_percentage'))
    else:
        raise ValueError(f"Unknown restriction type '{r.value_dict['constraint']}'")


class CertifaiFeatureSchema(_DataEquality):
    """Class describing a feature - immutable once instantiated."""
    def __init__(self,
                 name: str,
                 data_type: Optional[CertifaiFeatureDataType]=None):
        """

        :param str name: The name of the feature (should match any column headers in the dataset if any).
        :param `CertifaiFeatureDataType` data_type: Type of data the feature holds.
        """
        self._name = name
        self._data_type = data_type

    @property
    def name(self) -> str:
        """
        Feature name.

        :getter: Returns the name of the feature.
        :type: str
        """
        return self._name

    @property
    def data_type(self) -> Optional[CertifaiFeatureDataType]:
        """
        Feature data type

        :getter: Returns the data type of the feature.
        :type: :class:`CertifaiFeatureDataType`
        """
        return self._data_type

    def _update_data_type(self, data_type: CertifaiFeatureDataType):
        self._data_type = data_type


def _certifai_feature_schema_from_template_feature_schema(feature: DatasetFeatureSchema) -> CertifaiFeatureSchema:
    def _make_datatype():
        def data_type_of_numeric(value):
            return 'numerical-int' if isinstance(value, int) else 'numerical-float'

        # Infer missing data types from other attributes if necessary
        if feature.data_type is None:
            if feature.category_values is not None:
                data_type = 'categorical'
            elif feature.min is not None:
                data_type = data_type_of_numeric(feature.min)
            elif feature.max is not None:
                data_type = data_type_of_numeric(feature.max)
            else:
                data_type = None
        else:
            data_type = feature.data_type

        if data_type == 'categorical':
            value_columns = fmap_opt(lambda ohc: [(nv.name, nv.value) for nv in ohc], feature.one_hot_columns)
            return CertifaiFeatureDataType.categorical(values=feature.category_values,
                                                       value_columns=value_columns)
        elif data_type == 'numerical-int':
            return CertifaiFeatureDataType.int(min=feature.min, max=feature.max, spread=feature.spread)
        elif data_type == 'numerical-float':
            return CertifaiFeatureDataType.float(min=feature.min, max=feature.max, spread=feature.spread)
        else:
            return None

    return CertifaiFeatureSchema(feature.feature_name, _make_datatype())


def _template_feature_schema_from_certifai_feature_schema(feature: CertifaiFeatureSchema) -> DatasetFeatureSchema:
    return DatasetFeatureSchema(feature_name=feature.name,
                                **(feature.data_type.value_dict if feature.data_type is not None else {}))


class CertifaiDataSchema:
    """Class describing a dataset's feature schema, and allowing manipulation of this schema."""
    def __init__(self,
                 features: Optional[List[CertifaiFeatureSchema]]=None,
                 outcome_feature_name: Optional[str]=None,
                 predicted_outcome_feature_name: Optional[str]=None,
                 hidden_feature_names: List[str]=[],
                 defined_feature_order: bool=False):
        """

        :param Optional[List[CertifaiFeatureSchema]] features: features specified by the scan definition.
                    This may be a subset of all the features present.  Any that are omitted will be inferred from
                    the available data.
        :param Optional[str] outcome_feature_name: name of the feature holding the ground truth label/value (if present)
                 *Note* Any outcome feature column will be removed before passing data to the model.
        :param Optional[str] predicted_outcome_feature_name:  name of the feature holding the predicted label/value (if present)
                 *Note* Any predicted_outcome feature column will be removed before passing data to the model.
        :param bool defined_feature_order:  If present and True asserts that the list order of features in the schema
                 matches the layout of columns in the dataset.  If True then all columns must be present.  Intended
                 for use in cases where the dataset does not specify a column ordering itself.
        """
        self._features = features or []
        self._outcome_feature_name = None
        self._predicted_outcome_feature_name = None
        self._hidden_feature_names = hidden_feature_names
        self._defined_feature_order = defined_feature_order
        if outcome_feature_name is not None:
            self.outcome_feature_name = outcome_feature_name
        if predicted_outcome_feature_name is not None:
            self.predicted_outcome_feature_name = predicted_outcome_feature_name

    @property
    def features(self) -> Optional[List[CertifaiFeatureSchema]]:
        """
        features defined by the schema.

        :getter: Returns the list of defined features.
        :type: Optional[List[CertifaiFeatureSchema]]
        """
        return self._features

    @property
    def defined_feature_order(self) -> bool:
        """
        Whether the schema defines the column ordering of the data.

        :getter: Returns True if the schema defines the column ordering.
        :setter: Sets whether the schema defines the column ordering of the data.
        :type: bool
        """
        return self._defined_feature_order

    @defined_feature_order.setter
    def defined_feature_order(self, value: bool):
        self._defined_feature_order = value

    def _find_feature(self, name: str):
        for f in self._features:
            if f.name == name:
                return f
        return None

    def add_feature(self, name: str, data_type: CertifaiFeatureDataType):
        """Add a feature

        :param str name: Name of feature to add.
        :param CertifaiFeatureDataType data_type: data type of feature to add.

        *Note* - the feature will be appended to the current list
        """
        if any([f.name == name for f in self._features]):
            raise ValueError(f"Feature '{name}' is already present")
        self._features.append(CertifaiFeatureSchema(name, data_type))

    def insert_feature(self, name: str, index: int, data_type: CertifaiFeatureDataType):
        """Insert a feature.

        :param str name: Name of feature to add.
        :param int index: Columnar position to insert the feature at (0-based).
        :param CertifaiFeatureDataType data_type: data type of feature to add.
        """
        if any([f.name == name for f in self._features]):
            raise ValueError(f"Feature '{name}' is already present")
        self._features.insert(index, CertifaiFeatureSchema(name, data_type))

    def update_feature(self, name: str, data_type: CertifaiFeatureDataType):
        """Update an existing feature by name - preserves its index in th feature list

        :param str name: Name of feature to update.
        :param CertifaiFeatureDataType data_type: new data type of feature being updated.
        """
        feature = self._find_feature(name)
        if feature is None:
            raise ValueError(f"Feature '{name}' is not present")
        feature._update_data_type(data_type)

    def remove_feature(self, name: str):
        """Remove a feature.

        :param str name: Name of feature to remove.
        """
        feature = self._find_feature(name)
        if feature is None:
            raise ValueError(f"Feature '{name}' is not present")
        self._features.remove(feature)

    def infer_features_from_data(self, dataset_source: 'CertifaiDatasetSource'):
        dataset = Dataset(dataset_id='temp_id',
                          **dataset_source.value_dict)
        materialize_dataset(dataset, '.')
        feature_schemas, _ = generate_feature_schemas(dataset)
        self._features = [_certifai_feature_schema_from_template_feature_schema(f) for f in feature_schemas]

    @property
    def outcome_feature_name(self) -> Optional[str]:
        """
        Name of the (ground truth) outcome column (if any).

        :getter: Returns the feature name of the outcome feature.
        :setter: Sets the name of the (ground truth) outcome column.
        :type: Optional[str]
        """
        return self._outcome_feature_name

    @outcome_feature_name.setter
    def outcome_feature_name(self, value: Optional[str]):
        self._outcome_feature_name = value

    @property
    def predicted_outcome_feature_name(self) -> Optional[str]:
        """
        Name of the predicted outcome column (if any).

        :getter: Returns the feature name of the predicted outcome feature.
        :setter: Sets the name of the predicted outcome column.
        :type: Optional[str]
        """
        return self._predicted_outcome_feature_name

    @predicted_outcome_feature_name.setter
    def predicted_outcome_feature_name(self, value: Optional[str]):
        self._predicted_outcome_feature_name = value

    @property
    def hidden_feature_names(self) -> List[str]:
        """
        Names of hidden (from the model) features (if any).

        :getter: Returns a list feature names of features which are not provided to the model.
        :setter: Sets a list feature names of features which are not provided to the model.
        :type: Optional[str]

        *Note* Any specified `outcome_feature_name` or `predicted_outcome_feature_name`
        will automatically be hidden from the model and need not occur in this list
        """
        return self._hidden_feature_names

    @hidden_feature_names.setter
    def hidden_feature_names(self, value: List[str]):
        self._hidden_feature_names = value


def _certifai_schema_from_template_schema(schema: DatasetSchemaDef) -> CertifaiDataSchema:
    return CertifaiDataSchema(features=[_certifai_feature_schema_from_template_feature_schema(f) for f in schema.feature_schemas],
                              outcome_feature_name=schema.outcome_column,
                              predicted_outcome_feature_name=schema.predicted_outcome_column,
                              hidden_feature_names=schema.hidden_columns,
                              defined_feature_order=schema.defined_feature_order)


def _template_schema_from_certifai_schema(schema: CertifaiDataSchema) -> DatasetSchemaDef:
    return DatasetSchemaDef(feature_schemas=[_template_feature_schema_from_certifai_feature_schema(f) for f in schema.features],
                            outcome_column=schema.outcome_feature_name,
                            predicted_outcome_column=schema.predicted_outcome_feature_name,
                            hidden_columns=schema.hidden_feature_names,
                            defined_feature_order=schema.defined_feature_order)


# dataset related

class CertifaiDatasetSource(_DataEquality):
    """Class describing dataset storage formats supported by Certifai - immutable once instantiated.
    Static methods are provided for instantiating each supported format."""
    def __init__(self, args):
        self._args = args

    @property
    def value_dict(self):
        """
        Data source details as a dictionary.

        :getter: Returns the metadata dict for this data source.  In particular
                 this will contain a key named `file_type` which will be one of
                   - 'csv'
                   - 'json'
                   - 'loaded'
                 Other keys vary by source type.
        :type: dict
        """
        return deepcopy(self._args)

    @staticmethod
    def _validate_encoding(e):
        if (e is not None) and (e not in DATASET_ENCODINGS):
            raise ValueError(f"'{e}' is not a supported data encoding'")

    @staticmethod
    def json(url: str,
             lines: bool=DEFAULT_JSON_LINES,
             orient: str=DEFAULT_JSON_ORIENT,
             encoding: Optional[str]=None):
        """Constructor for a 'json' source.

        :param str url: Location the data may be loaded from.  If no protocol is specified then 'file:'
             is assumed.
        :param bool lines: If True then JSON lines format (default is True), else JSON list expected.
        :param str orient: One of 'records', 'columns', 'values' (matching Pandas usage).  Default is 'records'
        :param Optional[str] encoding: string encoding used - default is 'utf-8'.
        :return: instantiated `DatasetSource`
        :rtype: `DatasetSource`
        """
        if orient not in JSON_ORIENTS:
            raise ValueError(f"Orient '{orient}' is not a valid setting")
        CertifaiDatasetSource._validate_encoding(encoding)
        return CertifaiDatasetSource({
            'url': url,
            'file_type': 'json',
            'lines': lines,
            'orient': orient,
            'encoding': encoding
        })

    @staticmethod
    def csv(url: str,
            delimiter: str = ',',
            escape_character: Optional[str] = None,
            quote_character: str = '"',
            has_header: bool=DEFAULT_CSV_HAS_HEADER,
            encoding: Optional[str]=None):
        """Constructor for a 'csv' source.

        :param str url: Location the data may be loaded from.  If no protocol is specified then 'file:'
             is assumed.
        :param str delimiter: Record separator used.  Default is ','.
        :param Optional[str] escape_character: Escape character if any.  Default is None.
        :param str quote_character: Quote delimiter.  Default is '"'.
        :param bool has_header: Whether the source CSV has a header row specifying column names.  Default is True.
        :return: instantiated `DatasetSource`
        :rtype: `DatasetSource`
        """
        CertifaiDatasetSource._validate_encoding(encoding)
        return CertifaiDatasetSource({
            'url': url,
            'file_type': 'csv',
            'delimiter': delimiter,
            'escape_character': escape_character,
            'quote_character': quote_character,
            'has_header': has_header,
            'encoding': encoding
        })

    @staticmethod
    def dataframe(df):
        """Constructor for a 'dataframe' source (an already loaded Pandas dataframe).

        :param `DataFrame` df: Dataframe containing the data.
        :return: instantiated `DatasetSource`.
        :rtype: `DatasetSource`
        """
        if (df is not None) and not isinstance(df, pd.DataFrame):
            raise ValueError("Data must be provided as a Pandas dataframe")
        return CertifaiDatasetSource({
            'data': df,
            'file_type': 'loaded'
        })


class CertifaiDataset:
    """Metadata describing a dataset."""
    def __init__(self,
                 id: str,
                 source: CertifaiDatasetSource,
                 name: Optional[str]=None,
                 description: Optional[str]=None):
        """

        :param str id: identifier string by which the dataset may be referenced.
        :param `DatasetSource` source: source for the actual data in the dataset.
        :param Optional[str] name: Optional human readable name of the dataset.
        :param Optional[str] description: Optional free text description of the dataset.
        """
        _validate_id(id)
        self.id = id
        self.name = name
        self.description = description
        self.source = source


def _template_dataset_from_certifai_dataset(d: CertifaiDataset) -> Dataset:
    return Dataset(dataset_id=d.id,
                   name=d.name,
                   description=d.description,
                   **d.source.value_dict)


def _certifai_dataset_from_template_dataset(d: Dataset) -> CertifaiDataset:
    if d.file_type == 'json':
        return CertifaiDataset(id=d.dataset_id,
                               name=d.name,
                               description=d.description,
                               source=CertifaiDatasetSource.json(d.url,
                                                                 lines=d.lines,
                                                                 orient=d.orient,
                                                                 encoding=d.encoding))
    elif d.file_type == 'csv':
        return CertifaiDataset(id=d.dataset_id,
                               name=d.name,
                               description=d.description,
                               source=CertifaiDatasetSource.csv(d.url,
                                                                delimiter=d.delimiter,
                                                                escape_character=d.escape_character,
                                                                quote_character=d.quote_character,
                                                                has_header=d.has_header,
                                                                encoding=d.encoding))
    elif d.file_type is None:
        return CertifaiDataset(id=d.dataset_id,
                               name=d.name,
                               description=d.description,
                               source=CertifaiDatasetSource.dataframe(d.data))
    else:
        raise ValueError(f"Unsupported file type '{d.file_type}'")


# Fairness
class CertifaiGroupingBucket(_DataEquality):
    """Metadata describing a value grouping bucket for feature values - immutable once instantiated."""
    def __init__(self,
                 description: str,
                 max: Optional[float]=None,
                 values: Optional[List[Union[str,int]]]=None):
        """

        :param str description: Descriptive name of the bucket.
        :param Optional[float] max: Optional maximum numerical value in the bucket (may only be used with numeric features).
        :param Optional[List[Union[str,int]]] values: Optional explicit list of values falling within the bucket (primarily
                intended for use with categorical features).
        """
        self._description = description
        self._max = max
        self._values = values

    @property
    def description(self) -> str:
        """
        Description of the bucket.

        :getter: Returns the bucket description string.
        :type: str
        """
        return self._description

    @property
    def max(self) -> Optional[float]:
        """
        Maximum numeric value falling within the bucket (if specified).

        :getter: Returns the bucket ceiling value.

        *Note* - the floor of a bucket is determined by the ceiling of the
        previous bucket.  The entire bucket list will be sorted on `max` values
        and a sentinel bucket with no maximum value should be included in the list.
        :type: Optional[float]
        """
        return self._max

    @property
    def values(self) -> Optional[Iterable[Union[str,int]]]:
        """
        List of values falling within the bucket if defined.

        :getter: Returns the list of values or None if not defined.
        :type: Iterable[Union[str,int]]
        """
        return [v for v in self._values] if self._values is not None else None


class CertifaiGroupingFeature(_DataEquality):
    """Metadata describing a fairness grouping feature - immutable once instantiated"""
    def __init__(self,
                 name: str,
                 buckets: Optional[Iterable[CertifaiGroupingBucket]]=None):
        """

        :param str name: Feature name of the feature which defines the grouping.
        :param Optional[Iterable[CertifaiGroupingBucket]] buckets: Optional definition
             for bucketing the values of the feature.  If not specified then every unique
             value occurring in the data will be treated as its own group.
        """
        self._name = name
        self._buckets = [b for b in buckets] if buckets is not None else None

    @property
    def name(self) -> str:
        """
        Name of the grouping feature

        :getter: Returns the feature name used to define the groups
        :type: str
        """
        return self._name

    @property
    def buckets(self) -> Optional[Iterable[CertifaiGroupingBucket]]:
        """
        List of grouping buckets.

        :getter: Returns the list of grouping buckets for the grouping feature, if defined.
        :type: Iterable[CertifaiGroupingBucket]
        """
        return None if self._buckets is None else [b for b in self._buckets]


# Overall template building related

class CertifaiScanBuilder:
    """Builder class for scan templates, with static method for instantiation, and
       methods for manipulation, persistence, and running of the defined scan."""
    def __init__(self, base: ScanTemplate):
        self._template = deepcopy(base)
        self._template.models = []
        self._template.dataset_schema = None
        self._template.datasets = []
        self._models = []


        for model in base.models:
            connector = None
            for c in base.model_connectors:
                if model.model_id in c.model_ids:
                    connector = CertifaiModelConnector(c.name,
                                                       c.module_name,
                                                       c.class_name,
                                                       description=c.description,
                                                       model_args=fmap_opt(_name_val_list_to_dict, c.model_args),
                                                       model_secrets=fmap_opt(_name_val_list_to_dict, c.secrets))
                    break
            self._models.append(_certifai_model_from_template_model(model, connector))
        self._datasets = [_certifai_dataset_from_template_dataset(d) for d in base.datasets]
        self._schema = _certifai_schema_from_template_schema(base.dataset_schema)
        self._model_headers = defaultdict(lambda: defaultdict(dict))


    @property
    def model_headers(self) -> Dict:
        """
        Returns model headers defined in the scan.

        :getter: Returns model headers as dict
        :type: Dict
        """
        return self._model_headers

    def add_model_header(self, header_name: str, header_value: str, model_id: Optional[str] = None) -> ():
        """Add or Update a model header header_name: value. If `model_id` is provided then model header is added
            to the specific model otherwise header is set as defaults for all models

        :param str header_name: Name of the model header to inject.
        :param str header_value: Value associated with the header.
        :param Optional[str] model_id: model to add/update headers given model_id
        """

        if model_id:
            if model_id not in [m.model_id for m in self.template.models]:
                raise ValueError(f'Model with model_id {model_id} not present in scan builder instance models')
            self._model_headers[ModelHeaderTypeEnum.DEFINED][model_id][header_name] = header_value
        else:
            self._model_headers[ModelHeaderTypeEnum.DEFAULT][header_name] = header_value

    def remove_model_header(self, header_name: str, model_id: Optional[str] = None) -> ():
        """Remove a model header given header_name. if model_id is provided then header is removed for that specific model
        otherwise removed from all models(default case)

        :param str header_name: name of the header to remove .
        :param Optional[str] model_id: model to remove headers from
        """

        if model_id:
            if model_id not in [m.model_id for m in self.template.models]:
                raise ValueError(f'Model with model_id {model_id} not present in scan builder instance models')
            if header_name not in self._model_headers[ModelHeaderTypeEnum.DEFINED][model_id]:
                raise ValueError(f"Header '{header_name}' does not have a value defined for this model with {model_id}")
            del self._model_headers[ModelHeaderTypeEnum.DEFINED][model_id][header_name]
        else:
            if header_name not in self._model_headers[ModelHeaderTypeEnum.DEFAULT]:
                raise ValueError(f"Header '{header_name}' does not have a value defined")
            del self._model_headers[ModelHeaderTypeEnum.DEFAULT][header_name]

    @property
    def template(self):
        """
        Retrieve a scan template which can be serialized to dictionary form for saving as JSON
        or YAML by calling its `dump` method.
        :return: `ScanTemplate` instance
        """
        result = copy(self._template)

        def equal_name_value_dicts(d1, d2):
            # Test equality independent of ordering
            return (frozenset(d1.keys()) == frozenset(d2.keys())) and all([d1[k] == d2[k] for k in d1])

        result.model_connectors = []
        result.models = []
        for model in self._models:
            if model.connector is not None:
                match = None
                for connector in result.model_connectors:
                    if (connector.name == model.connector.name) and \
                       (connector.module_name == model.connector.module_name) and \
                       (connector.class_name == model.connector.class_name) and \
                       equal_name_value_dicts({ma.name: ma.value for ma in connector.model_args}, model.connector.model_args) and \
                       equal_name_value_dicts({ms.name: ms.value for ms in connector.secrets}, model.connector.model_secrets):
                        match = connector
                        break
                if match is None:
                    match = ModelConnector(model.connector.name,
                                           model.connector.module_name,
                                           model.connector.class_name,
                                           model.connector.description,
                                           [],
                                           [ModelArgs(k,v) for k, v in model.connector.model_args.items()],
                                           [ModelConnectorSecrets(k,v) for k, v in model.connector.model_secrets.items()])
                    result.model_connectors.append(match)
                match.model_ids.append(model.id)
            result.models.append(_template_model_from_certifai_model(model))

        result.dataset_schema = _template_schema_from_certifai_schema(self._schema)
        result.datasets = [_template_dataset_from_certifai_dataset(d) for d in self._datasets]
        return result

    @property
    def author(self) -> str:
        """
        Author of the template.

        :getter: Returns the author of the scan template, if defined.
        :setter: Sets the author of the scan template.
        :type: Optional[str]
        """
        return self._template.model_use_case.author

    @author.setter
    def author(self, value):
        self._template.model_use_case.author = value

    @property
    def use_case_name(self) -> str:
        """
        Use case name - human readable name for a use case (i.e. - a prediction task).

        :getter: Returns the use case name.
        :setter: Sets the use case name.
        :type: str
        """
        return self._template.model_use_case.name

    @use_case_name.setter
    def use_case_name(self, value):
        self._template.model_use_case.name = value

    @property
    def use_case_id(self) -> str:
        """
        Use case id - id by which the use case may be referenced.

        :getter: Returns the use case id.
        :setter: Sets the use case id.
        :type: str
        """
        return self._template.model_use_case.model_use_case_id

    @use_case_id.setter
    def use_case_id(self, value):
        self._template.model_use_case.model_use_case_id = value

    @property
    def evaluation_name(self) -> str:
        """
        Evaluation name - name of a particular evaluation (scan run).

        :getter: Returns the evaluation name.
        :setter: Sets the evaluation name.
        :type: str
        """
        return self._template.evaluation.name

    @evaluation_name.setter
    def evaluation_name(self, value):
        self._template.evaluation.name = value

    @property
    def evaluation_environment(self) -> str:
        """
        Evaluation environment - free text string with evaluation environment details.

        :getter: Returns the evaluation environment string.
        :setter: Sets the evaluation environment string.
        :type: str
        """
        return self._template.evaluation.environment

    @evaluation_environment.setter
    def evaluation_environment(self, value):
        self._template.evaluation.environment = value

    @property
    def evaluation_description(self) -> str:
        """
        Evaluation description - free text string describing the evaluation.

        :getter: Returns the evaluation description string.
        :setter: Sets the evaluation description string.
        :type: str
        """
        return self._template.evaluation.description

    @evaluation_description.setter
    def evaluation_description(self, value):
        self._template.evaluation.description = value

    @property
    def evaluation_dataset_id(self) -> str:
        """
        Evaluation dataset id - specifies which dataset to use as the evaluation set.

        :getter: Returns the evaluation dataset id.
        :setter: Sets the evaluation dataset id.
        :type: str
        """
        return self._template.evaluation.evaluation_dataset_id

    @evaluation_dataset_id.setter
    def evaluation_dataset_id(self, value: str):
        self._template.evaluation.evaluation_dataset_id = value

    @property
    def explanation_dataset_id(self) -> Optional[str]:
        """
        Explanation dataset id - specifies which dataset to generate explanations of
        if the 'explanation' evaluation type is included in the scan.

        :getter: Returns the explanation dataset id.
        :setter: Sets the explanation dataset id.
        :type: Optional[str]
        """
        return self._template.evaluation.explanation_dataset_id

    @explanation_dataset_id.setter
    def explanation_dataset_id(self, value: Optional[str]):
        self._template.evaluation.explanation_dataset_id = value

    @property
    def test_dataset_id(self) -> Optional[str]:
        """
        Test dataset id - specifies which dataset to measure metrics on
        if the 'performance' evaluation type is included in the scan.

        :getter: Returns the test dataset id.
        :setter: Sets the test dataset id.
        :type: Optional[str]
        """
        return self._template.evaluation.test_dataset_id

    @test_dataset_id.setter
    def test_dataset_id(self, value: Optional[str]):
        self._template.evaluation.test_dataset_id = value

    def _outcome2prediction_value(self, outcome: CertifaiOutcomeValue) -> PredictionValue:
        return PredictionValue(outcome.name, outcome.value, outcome.favorable)

    def _prediction_value2outcome(self, value: PredictionValue) -> CertifaiOutcomeValue:
        return CertifaiOutcomeValue(value.value, name=value.name, favorable=value.favorable)

    @property
    def prediction_task(self) -> CertifaiPredictionTask:
        """
        Metadata for the prediction task.

        :getter: Returns the prediction task metadata.
        :setter: Sets the prediction task metadata.
        :type: `CertifaiPredictionTask`
        """
        if self._template.model_use_case.task_type in ('binary-classification', 'multiclass-classification'):
            outcomes = CertifaiTaskOutcomes.classification(map(self._prediction_value2outcome,
                                                               self._template.evaluation.prediction_values),
                                                           self._template.evaluation.prediction_favorability,
                                                           self._template.evaluation.last_favorable_prediction,
                                                           self._template.evaluation.favorable_outcome_group_name,
                                                           self._template.evaluation.unfavorable_outcome_group_name)
        elif self._template.model_use_case.task_type == 'regression':
            favorable_outcome = self._template.evaluation.favorable_outcome_value
            outcomes = CertifaiTaskOutcomes.regression(favorable_outcome == 'increased' if favorable_outcome else None,
                                                       self._template.evaluation.regression_standard_deviation,
                                                       self._template.evaluation.regression_boundary,
                                                       self._template.evaluation.regression_boundary_percentile)
        else:
            raise ValueError(f"Unknown task type '{self._template.model_use_case.task_type}'")

        return CertifaiPredictionTask(outcomes, self._template.evaluation.prediction_description)

    @prediction_task.setter
    def prediction_task(self, value: CertifaiPredictionTask):
        self._template.model_use_case.task_type = value.task_type
        self._template.evaluation.prediction_favorability = value.prediction_favorability
        self._template.evaluation.prediction_description = value.prediction_description
        self._template.evaluation.last_favorable_prediction = value.last_favorable_prediction
        self._template.evaluation.favorable_outcome_value = value.favorable_outcome if len(value.prediction_values) == 0 else None
        self._template.evaluation.regression_standard_deviation = value.regression_standard_deviation
        self._template.evaluation.regression_boundary = value.regression_absolute_threshold
        self._template.evaluation.regression_boundary_percentile = value.regression_absolute_percentile
        if (value.regression_absolute_threshold is not None) or (value.regression_absolute_percentile is not None):
            self._template.evaluation.regression_boundary_type = 'absolute'
        self._template.evaluation.prediction_values = [self._outcome2prediction_value(v) for v in value.prediction_values]
        self._template.evaluation.favorable_outcome_group_name = value.favorable_outcome_group_name
        self._template.evaluation.unfavorable_outcome_group_name = value.unfavorable_outcome_group_name

    @property
    def output_path(self) -> Optional[str]:
        """
        Output path to which reports will be written.  If set to `None`
        output will be to './reports' relative to the scan base path unless
        explicitly overriden either by the `run` call or by the `SCAN_RESULTS_DIRECTORY`
        environment variable

        :getter: Returns the output path.
        :setter: Sets the output path of the scan.
        :type: Optional[str]
        """
        return self._template.scan.output.path

    @output_path.setter
    def output_path(self, value: Optional[str]):
        self._template.scan.output.path = value

    def add_evaluation_type(self, value: str):
        """Add an evaluation type to the scan.

        :param str value: type of evaluation to add.  Must be one of
            - 'fairness'
            - 'robustness'
            - 'explanation'
            - 'explainability'
            - 'performance'
        """
        if value not in EVALUATION_TYPES:
            raise ValueError(f"Evaluation type '{value}' is not known.  The supported set is {EVALUATION_TYPES}")
        if value in self._template.evaluation.evaluation_types:
            raise ValueError(f"Evaluation type '{value}' is already present")
        self._template.evaluation.evaluation_types.append(value)

    def remove_evaluation_type(self, value: str):
        """Remove an evaluation type from the scan.

        :param str value:  type of evaluation to remove.
        """
        if value not in self._template.evaluation.evaluation_types:
            raise ValueError(f"Evaluation type '{value}' is not present")
        self._template.evaluation.evaluation_types.remove(value)

    @property
    def evaluation_types(self) -> Iterable[str]:
        """
        Evaluation types included in the scan.

        :getter: Returns the list of included evaluation types.
        :type: Iterable[str]
        """
        return frozenset(self._template.evaluation.evaluation_types)

    @property
    def hyper_parameter_overrides(self) -> dict:
        """
        Hyper-parameter overrides to apply to the analysis.

        :getter: Returns a dictionary of hyper-parameter overrides.
        :setter: Specifies a dictionary of hyper-parameter overrides.
        :type: dict
        """
        return self._template.evaluation.hyperparameters

    @hyper_parameter_overrides.setter
    def hyper_parameter_overrides(self, value: dict):
        self._template.evaluation.hyperparameters = value

    #fairness features
    def add_fairness_grouping_feature(self, feature: CertifaiGroupingFeature):
        """Add a fairness grouping feature.

        :param `CertifaiGroupingFeature` feature: grouping feature definition.
        """
        def _make_template_grouping_feature(f):
            template_buckets = [] if f.buckets is None else [FeatureBucket(description=b.description,
                                                                           max=b.max,
                                                                           values=b.values) for b in f.buckets]
            return FairnessGrouping(name=f.name,
                                    buckets=template_buckets)

        if any([f.name == feature.name for f in self._template.evaluation.fairness_grouping_features]):
            raise ValueError(f"Grouping feature '{feature.name}' is already present")
        self._template.evaluation.fairness_grouping_features.append(_make_template_grouping_feature(feature))

    def remove_fairness_grouping_feature(self, name: str):
        """Remove a fairness grouping feature.

        :param str name: name of the grouping feature to remove.
        """
        for f in self._template.evaluation.fairness_grouping_features:
            if f.name == name:
                self._template.evaluation.fairness_grouping_features.remove(f)
                return
        raise ValueError(f"No grouping feature named '{name}' is present")

    @property
    def fairness_grouping_features(self) -> List[CertifaiGroupingFeature]:
        """
        Fairness grouping features defined for the scan.

        :getter: Returns a list of defined grouping features.
        :type: List[CertifaiGroupingFeature]
        """
        def _make_certifai_grouping_feature(f):
            buckets = None if len(f.buckets) == 0 else [CertifaiGroupingBucket(description=b.description,
                                                                               max=b.max,
                                                                               values=b.values) for b in f.buckets]
            return CertifaiGroupingFeature(f.name, buckets=buckets)

        return [_make_certifai_grouping_feature(f) for f in self._template.evaluation.fairness_grouping_features]

    @property
    def metrics(self) -> List[CertifaiModelMetric]:
        """
        Performance metrics defined for the scan.

        :getter: Returns a list of defined performance metrics.
        :type: List[ModelMetric]
        """
        return [CertifaiModelMetric(m.name, m.metric) for m in self._template.model_use_case.performance_metrics]

    def _find_metric(self, name: str) -> Optional[CertifaiModelMetric]:
        for m in self._template.model_use_case.performance_metrics:
            if m.name == name:
                return CertifaiModelMetric(m.name, m.metric)
        return None

    #metrics
    def add_metric(self, metric: CertifaiModelMetric):
        """Add a performance metric.

        :param `CertifaiModelMetric` metric: metric to add.
        """
        if any([m.name == metric.name for m in self._template.model_use_case.performance_metrics]):
            raise ValueError(f"A metric named '{metric.name}' is already present")
        self._template.model_use_case.performance_metrics.append(Metric(metric.certifai_metric, metric.name))

    def remove_metric(self, name: str):
        """Remove a performance metric

        :param str name: Name of the metric to remove
        """
        if name == self._template.model_use_case.atx_performance_metric_name:
            raise ValueError(f"Metric '{name}' is in use as the atx_performance_metric")

        for m in self._template.model_use_case.performance_metrics:
            if m.name == name:
                self._template.model_use_case.performance_metrics.remove(m)
                return
        raise ValueError(f"No metric named '{name}' is present")

    @property
    def explanation_types(self) -> List[str]:
        """
        Explanation types defined for the scan.

        :getter: Returns a list of defined explanation types.
        :type: List[str]
        """
        return [str(m) for m in self._template.evaluation.explanation_types] or ['counterfactual']

    def add_explanation_type(self, explanation: str):
        """Add a explanation type.

        :param str explanation: explanation type to add.
        """
        ExplanationType.from_str(explanation)  # Validate supported metric
        if any([str(m).lower() == explanation.lower() for m in self.explanation_types]):
            raise ValueError(f"Explanation type '{explanation}' is already present")
        self._template.evaluation.explanation_types = self.explanation_types + [explanation]

    def remove_explanation_type(self, name: str):
        """Remove an explanation type

        :param str name: Name of the explanation type to remove
        """
        # Special case for the virtual default entry if nothing is specified
        if (len(self._template.evaluation.explanation_types) == 0) and (name.lower() == 'counterfactual'):
            raise ValueError(f"Cannot remove final 'counterfactual' entry from explanation types without first adding another type")

        if name.lower() == fmap_opt(lambda _: _.lower(), self._template.evaluation.primary_explanation_type):
            raise ValueError(f"Explanation type '{name}' is specified as the primary_explanation_type")

        for t in self._template.evaluation.explanation_types:
            if t.lower() == name.lower():
                self._template.evaluation.explanation_types.remove(t)

                # Canonicalize for the default case
                if (len(self._template.evaluation.explanation_types) == 1) and\
                    (self._template.evaluation.explanation_types[0].lower() == 'counterfactual'):
                    self._template.evaluation.explanation_types = []
                return

        raise ValueError(f"No explanation type named '{name}' is present")

    @property
    def primary_explanation_type(self) -> str:
        """
        Explanation type to select for the explainability axis of the ATX score.

        :getter: Returns the name of the selected explanation type for use in ATX calculation.
        :setter: Sets the name of the selected explanation type for use in ATX calculation.

        Accepts an `str` specifying the explanation type on set, returns
        `str` of the explanation type on get.
        """
        def default_choice():
            return self._template.evaluation.fairness_metrics[0] if len(self._template.evaluation.fairness_metrics) > 0 \
                else 'counterfactual'
        return self._template.evaluation.primary_explanation_type or default_choice()

    @primary_explanation_type.setter
    def primary_explanation_type(self, name: str):
        if (name is None) or name.lower() not in map(lambda _: _.lower(), self._template.evaluation.explanation_types):
            raise ValueError(f"Explanation type '{name}' is not present in the defined explanation types")
        else:
            self._template.evaluation.primary_explanation_type = name

    @property
    def fairness_metrics(self) -> List[str]:
        """
        Fairness metrics defined for the scan.

        :getter: Returns a list of defined fairness metrics.
        :type: List[str]
        """
        return [str(m) for m in self._template.evaluation.fairness_metrics] or ['burden']

    #fairness metrics
    def add_fairness_metric(self, metric: str):
        """Add a fairness metric.

        :param str metric: metric to add.
        """
        FairnessMetric.from_str(metric)  # Validate supported metric
        if any([str(m).lower() == metric.lower() for m in self.fairness_metrics]):
            raise ValueError(f"Fairness metric '{metric}' is already present")
        self._template.evaluation.fairness_metrics = self.fairness_metrics + [metric]

    def remove_fairness_metric(self, name: str):
        """Remove a fairness metric

        :param str name: Name of the metric to remove
        """
        if name.lower() == fmap_opt(lambda _: _.lower(), self._template.evaluation.primary_fairness_metric):
            raise ValueError(f"Metric '{name}' is specified as the primary_fairness_metric")

        # Special case for the virtual default entry if nothing is specified
        if (len(self._template.evaluation.fairness_metrics) == 0) and (name.lower() == 'burden'):
            raise ValueError(f"Cannot remove final 'burden' entry from fairness metrics without first adding another measure")

        for m in self._template.evaluation.fairness_metrics:
            if m.lower() == name.lower():
                self._template.evaluation.fairness_metrics.remove(m)

                # Canonicalize for the default case
                if (len(self._template.evaluation.fairness_metrics) == 1) and\
                    (self._template.evaluation.fairness_metrics[0].lower() == 'burden'):
                    self._template.evaluation.fairness_metrics = []
                    self._template.evaluation.primary_fairness_metric = None
                return

        raise ValueError(f"No metric named '{name}' is present")

    @property
    def primary_fairness_metric(self) -> Optional[str]:
        """
        Metric to select for the performance axis of the ATX score.

        :getter: Returns the name of the selected performance metric for use in ATX calculation.
        :setter: Sets the name of the selected performance metric for use in ATX calculation.

        Accepts an `Optional[str]` specifying the performance metric name (if any) on set, returns
        `Optional[CertifaiModelMetric]` of the metric instance on get.
        """
        def default_choice():
            return self._template.evaluation.fairness_metrics[0] if len(self._template.evaluation.fairness_metrics) > 0\
                                                                 else 'burden'
        return self._template.evaluation.primary_fairness_metric or default_choice()

    @primary_fairness_metric.setter
    def primary_fairness_metric(self, name: str):
        if (name is None) or name.lower() not in map(lambda _: _.lower(), self._template.evaluation.fairness_metrics):
            raise ValueError(f"Metric '{name}' is not present in the defined fairness metrics")
        else:
            self._template.evaluation.primary_fairness_metric = name

    @property
    def atx_performance_metric(self) -> Optional[CertifaiModelMetric]:
        """
        Metric to select for the performance axis of the ATX score.

        :getter: Returns the name of the selected performance metric for use in ATX calculation.
        :setter: Sets the name of the selected performance metric for use in ATX calculation.

        Accepts an `Optional[str]` specifying the performance metric name (if any) on set, returns
        `Optional[CertifaiModelMetric]` of the metric instance on get.
        """
        name = self._template.model_use_case.atx_performance_metric_name
        return self._find_metric(name) if name else None

    @atx_performance_metric.setter
    def atx_performance_metric(self, name: str):
        if (name is None) or self._find_metric(name):
            self._template.model_use_case.atx_performance_metric_name = name
        else:
            raise ValueError(f"Metric '{name}' is not present in the defined performance metrics")

    #models
    def add_model(self, model: CertifaiModel):
        """Add a model to the scan.

        :param `CertifaiModel` model: metadata of the model to add.
        """
        if any([m.id == model.id for m in self._models]):
            raise ValueError(f"A model with id '{model.id}' is already present")
        self._models.append(model)

    def remove_model(self, id: str):
        """Remove a model from the scan.

        :param str id: Removes the model with the specified id.
        :return:
        """
        for m in self._models:
            if m.id == id:
                self._models.remove(m)
                if id in self._model_headers[ModelHeaderTypeEnum.DEFINED]:
                    del self._model_headers[ModelHeaderTypeEnum.DEFINED][id]
                return
        raise ValueError(f"No model with id '{id}' is present")

    @property
    def models(self) -> List[CertifaiModel]:
        """
        Models included in the scan.

        :getter: Returns a list of included models.
        :type: List[CertifaiModel]
        """
        return self._models

    #datasets
    def add_dataset(self, dataset: CertifaiDataset):
        """Add a dataset.

        :param `CertifaiDataset` dataset: the dataset to add.
        """
        if any([d.id == dataset.id for d in self._datasets]):
            raise ValueError(f"A dataset with id '{dataset.id}' is already present")
        self._datasets.append(dataset)

    def remove_dataset(self, dataset_id: str):
        """Remove a dataset.

        :param str dataset_id: Dataset to remove (by id).
        """
        for d in self._datasets:
            if d.id == dataset_id:
                self._datasets.remove(d)
                return
        raise ValueError(f"No dataset with id '{dataset_id}' is present")

    @property
    def datasets(self) -> List[CertifaiDataset]:
        """
        Datasets defined by the scan.

        :getter: Returns a list of defined datasets.
        :type: List[CertifaiDataset]
        """
        return [d for d in self._datasets]

    #schema
    @property
    def dataset_schema(self) -> CertifaiDataSchema:
        """
        Dataset schema used by the scan use case.

        :getter: Returns the dataset schema.
        :setter: Sets the dataset schema.
        :type: CertifaiDataSchema
        """
        return self._schema

    @dataset_schema.setter
    def dataset_schema(self, value):
        self._schema = value

    @property
    def feature_restrictions(self) -> Dict[str, CertifaiFeatureRestriction]:
        """
        Get restrictions on feature changes made during counterfactual production
        :return: dictionary of restrictions keyed on feature name
        :rtype: Dict[str,CertifaiFeatureRestriction]
        """
        return {r.feature_name: _scan_feature_restriction2api_restriction(r)}

    def add_feature_restriction(self, feature_name: str, restriction: CertifaiFeatureRestriction):
        """
        Add a restriction on the changes that can be made to a feature during counterfactual production
        :param str feature_name: feature to restrict
        :param CertifaiFeatureRestriction restriction: restriction to apply
        """
        self.remove_feature_restriction(feature_name)
        self._template.evaluation.feature_restrictions.append(_api_restriction2scan_feature_restriction(feature_name,
                                                                                                        restriction))

    def remove_feature_restriction(self, feature_name: str):
        """
        Remove a restriction on the changes that can be made to a feature during counterfactual production
        :param str feature_name: feature to de-restrict
        """
        self._template.evaluation.feature_restrictions = [r for r in self._template.evaluation.feature_restrictions if r.feature_name != feature_name]

    def extract_yaml(self) -> str:
        """Extract the scan as a YAML definition.

        :return: string containing the scan template encoded as YAML.
        :rtype: str
        """
        as_dict = self.template.dump(mode='template')
        return yaml.dump(as_dict, default_flow_style=False)

    def save(self, file):
        """Save the scan template to a file.

        :param file: file object opened for write to which the definition is to be saved.
        """
        as_dict = self.template.dump(mode='template')
        yaml.dump(as_dict, file, default_flow_style=False)

    def run_preflight(self,
                      model_id: Optional[str] = None,
                      base_path: Optional[str] = None,
                      callback: Optional[Callable[[ProgressUpdate], None]]=ProgressBarListener(task='checks')):
        """ Run the preflight scan (in-process).

        :param Optional[str] model_id: Optional specific model id to restrict the scan to
        :param Optional[str] base_path: Optional base path to evaluate relative paths in the scan definition
               with respect to (if not specified then current working directory is assumed).
        :param Optional[Callable[[ProgressUpdate], None]] callback: Optional callback function to receive progress
               updates as preflight checks are completed. If not specified, a default will be used that prints to stdout.
               Set to None to receive no progress updates.
        :return: a nested dictionary of messages produced during the preflight scan. The top level keys are model
                ids, second level keys is the message type, within which is a list of strings
        :rtype: dict
        """
        # conform to blueprint schema before running scan
        self.template.model_headers.default = [DefaultModelHeader(name=k, value=v) for k, v in self._model_headers[ModelHeaderTypeEnum.DEFAULT].items()]
        self.template.model_headers.defined = [DefinedModelHeader(name=k, value=v, model_id=model)
                                               for model, header in self._model_headers[ModelHeaderTypeEnum.DEFINED].items() for k,v in header.items()]

        return process_blueprint(self.template,
                                 model=model_id,
                                 base_path=base_path,
                                 progress_listener=callback,
                                 preflight=True)


    def run(self,
            model_id: Optional[str]=None,
            report: Optional[str]=None,
            write_reports: bool=True,
            base_path: Optional[str]=None,
            callback: Optional[Callable[[ProgressUpdate], None]]=ProgressBarListener(task='reports')):
        """Run the scan (in-process).

        :param Optional[str] model_id: Optional specific model id to restrict the scan to.
        :param Optional[str] report: Optional specific report (evaluation type) to restrict the scan to.
        :param bool write_reports: Whether to write report files for each model evaluation to the scan's
               output directory (by default './reports' relative to `base_path`).  Default is True.
        :param Optional[str] base_path: Optional base path to evaluate relative paths in the scan definition
               with respect to (if not specified then current working directory is assumed).
        :param Optional[Callable[[ProgressUpdate], None]] callback: Optional callback function to receive progress
               updates as evaluations are completed. If not specified, a default will be used that prints to stdout.
               Set to None to receive no progress updates.
        :return: nested dictionary of reports.  Top level keys are the evaluation type, second level keys
                 are the model ids, within which is the report JSON represented in dictionary format.
        :rtype: dict
        """
        # conform to blueprint schema before running scan
        self.template.model_headers.default = [DefaultModelHeader(name=k, value=v) for k, v in self._model_headers[ModelHeaderTypeEnum.DEFAULT].items()]
        self.template.model_headers.defined = [DefinedModelHeader(name=k, value=v, model_id=model)
                                               for model, header in self._model_headers[ModelHeaderTypeEnum.DEFINED].items() for k,v in header.items()]

        if callback is None:
            callback = lambda x: None

        return process_blueprint(self.template,
                                 model=model_id,
                                 report=report,
                                 write_reports=write_reports,
                                 base_path=base_path,
                                 progress_listener=callback)

    #instantiation
    @staticmethod
    def from_file(filename: str):
        """Load a scan template from file.

        :param str filename: path to template file to read.
        :return: Instantiated `ScanBuilder` with metadata from the template that was read.
        :rtype: `ScanTemplate`
        """
        template = ScanTemplateSchema().load(read_blueprint(filename), notebook_semantics=True)
        return CertifaiScanBuilder(template)

    @staticmethod
    def from_yaml(as_yaml: str):
        """Load a scan template from file.

        :param str as_yaml: Definition to load as YAML string.
        :return: Instantiated `ScanBuilder` with metadata from the template that was read.
        :rtype: `ScanTemplate`
        """
        template = ScanTemplateSchema().load(yaml.safe_load(as_yaml), notebook_semantics=True)
        return CertifaiScanBuilder(template)

    @staticmethod
    def create(use_case_name: str,
               use_case_id: Optional[str]=None,
               evaluation_name: Optional[str]=None,
               environment: Optional[str]=None,
               description: Optional[str]=None,
               prediction_task: CertifaiPredictionTask = CertifaiPredictionTask(CertifaiTaskOutcomes.classification([])),
               output_path: Optional[str] = None):
        """Create a new template builder.

        :param str use_case_name: Name of the prediction use case.
        :param Optional[str] use_case_id: Id by which the use case will be referenced.  Defaults to the name if omitted.
        :param Optional[str] evaluation_name: Name of the evaluation.  Defaults to the use case name if not provided.
        :param Optional[str] environment: Optional opaque string recording scan environment information.
        :param Optional[str] description: Optional human readable description of the use case.
        :param str prediction_task: Prediction task metadata.
        :param Optional[str] output_path: where to write report files to.  If a relative path evaluated with respect to the base path
                                at evaluation time.  If omitted, reports will be written to './reports'.
        :return: Instantiated `ScanBuilder` with metadata from the template that was read.
        :rtype: `ScanTemplate`
        """
        evaluation_params = {
            'evaluation_dataset_id': DEFAULT_EVAL_DATASET_ID,
            'name': evaluation_name or use_case_name,
            'environment': environment,
            'description': description
        }
        evaluation = Evaluation(**evaluation_params)
        model_use_case = ModelUseCase(use_case_name,
                                      use_case_id or use_case_name,
                                      task_type=prediction_task.task_type)
        scan_template = ScanTemplate(model_use_case=model_use_case,
                                     evaluation=evaluation,
                                     models=[],
                                     scoring=Scoring(),
                                     model_headers=ModelHeaders(),
                                     datasets=[],
                                     dataset_schema=DatasetSchemaDef(),
                                     scan=Scan(),
                                     model_connectors=[])

        scan_template.scan.output.path = output_path
        result = CertifaiScanBuilder(scan_template)
        result.prediction_task = prediction_task
        return result
