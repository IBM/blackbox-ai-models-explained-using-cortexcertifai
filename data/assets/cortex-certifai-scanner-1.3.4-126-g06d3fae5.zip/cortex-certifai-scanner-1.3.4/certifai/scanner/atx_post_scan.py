"""
Utilities for creating an ATX report post parallel scan
"""
import json
from typing import Dict, Optional, List, Set

from certifai.common.file.locaters import make_generic_locater
from certifai.common.file.interface import get_basename, FSLocater
from certifai.common.utils import get_logger
from certifai.common.utils.utils import get_iso8601_datetime
from certifai.common.utils.file_utils import resolve_filepath
from certifai.common.errors import CertifaiException
from certifai.common.types import EvaluationTypeEnum

from certifai.scanner.certifai_scan import read_blueprint, convert_input_data
from certifai.scanner.evaluation import create_atx_report
from certifai.scanner.schemas import ScanTemplateSchema
from certifai.scanner.report_writer import ScanReportWriter, NullReportWriter, filename_safe_muc_id

log = get_logger()


def _get_reports_by_model(reports_location: str,
                          scan_id: str,
                          models: List[str],
                          expected_eval_types: Set[str]) -> Dict[str, List[dict]]:
    """
    Gets the scan reports with the matching scan_id for the given models.

    :param str scan_id: scan id of reports to find
    :param List[str] models: list of models ids
    :param Set[str] expected_eval_types: expected evaluation types for reports to be found
    :return: a dictionary mapping model id's to the list of corresponding reports
    """
    reports = {}
    locater = make_generic_locater(reports_location)
    log.info(f"Searching for scan reports in {reports_location}")

    # filter possible scan reports by filename (must match scan id and eval type filters)
    filenames = set()
    for f in locater.file_lister():
        filename = get_basename(f).strip()
        if _filename_matches_report(filename, scan_id, expected_eval_types):
            filenames.add(filename)

    file_cache = {} # filename -> report data
    for model_id in models:
        reports[model_id] = _get_reports_for_model(model_id, scan_id, filenames, file_cache, locater, expected_eval_types)
    return reports


def _get_reports_for_model(model_id: str,
                           scan_id: str,
                           filenames: Set[str],
                           file_cache: Dict[str, dict],
                           dir_locater: FSLocater,
                           expected_eval_types: Set[str]) -> List[dict]:
    # 1. Sort files based on the distance between model id in the filename and actual model_id
    # 2. for each of the files
    #    - read the file (or get it from cache)
    #    - store the report data if it corresponds to the model
    #    - exit early if we've found all the expected reports
    # 3. if we exhausted the possible files and didn't find the expected reports -> raise
    reports_for_model = {}
    filename_scores = {f: _score_model_abbrev(f, model_id) for f in filenames}
    sorted_filenames = sorted(filenames, key=lambda f: filename_scores[f], reverse=True)
    for f in sorted_filenames:
        if len(reports_for_model) == len(expected_eval_types):
            break

        if f not in file_cache:
            file_locater = dir_locater.join(f)
            try:
                log.info(f"reading scan report: {f}")
                file_cache[f] = _read_report(file_locater)
            except Exception as e:
                log.exception(f"Failed to read report file {f} - {str(e)}", exc_info=True)
                continue

        corresponding_model_id = file_cache[f]['model']['model_id']
        eval_type = file_cache[f]['scan']['evaluation_type']

        if corresponding_model_id == model_id and eval_type in reports_for_model:
            log.warning(f"multiple {eval_type} reports with scan_id '{scan_id}' found for '{model_id}' model")
        elif corresponding_model_id == model_id:
            reports_for_model[eval_type] = file_cache[f]

    if len(reports_for_model) != len(expected_eval_types):
        missing_reports = [e for e in expected_eval_types if e not in reports_for_model]
        raise CertifaiException(f"Unable to find all reports for {model_id} model: missing '{','.join(missing_reports)}' report(s)")

    return list(reports_for_model.values())

def _score_model_abbrev(f, model_id):
    # If the model id in the filename isn't an exact match it'll likely be a substring of the actual
    # model_id or a substring with some randomness appended on. So, the score is just the length of
    # the common substring.
    common_substring_len = 0
    model_abbrev = f.split('.')[0].split('-')[-1]
    for i in range(min(len(model_abbrev), len(model_id))):
        if model_abbrev[i] == model_id[i]:
            common_substring_len += 1
        else:
            break
    return common_substring_len


def _filename_matches_report(filename: str, scan_id: str, eval_type_filters: Set[str]) -> bool:
    if not (filename.startswith('certifai-scan-') and filename.endswith('.json')):
        return False

    try:
        _, _, _, s_id, eval_type, _ = filename.split('-')
        return s_id == scan_id and eval_type in eval_type_filters
    except ValueError:
        return False

def _read_report(report_locater: FSLocater) -> dict:
    with report_locater.text_reader() as stream:
        return json.load(stream)



def atx_from_written_reports(definition_file: str,
                             scan_id: str,
                             reports_dir: str,
                             model_id: Optional[str] = None,
                             write_reports: bool = True) -> Dict[str, Dict[str, dict]]:
    """
    Create and write ATX report from already written reports.

    :param definition_file: location of scan definition file
    :param scan_id: scan id of written reports
    :param reports_dir: location of written reports
    :param model_id: Optional model ID to limit creating ATX report for
    :param write_reports: whether to write atx reports, default True
    :return: report dictionary
    """
    scan_template_schema = ScanTemplateSchema()
    base_path = resolve_filepath(definition_file, '.', is_file=True)
    template = scan_template_schema.load(read_blueprint(definition_file))
    context = convert_input_data(template, base_path)

    if model_id is not None:
        log.info(f"Limiting ATX report creation to a single model: {model_id}")
        context.models = [m for m in context.models if m.model_id == model_id]
        if len(context.models) == 0:
            raise CertifaiException(f"No model with model id of '{model_id}' found in the scan definition")

    muc_id = filename_safe_muc_id(context.use_case.model_use_case_id)
    output_location = resolve_filepath(reports_dir, muc_id)

    # we'll only search for the evaluation types listed in the scan def. (minus explanation)
    expected_eval_types = set(e for e in context.evaluation.evaluation_types if e != EvaluationTypeEnum.explanation)
    try:
        reports_by_model = _get_reports_by_model(output_location,
                                                 scan_id,
                                                 [m.model_id for m in context.models],
                                                 expected_eval_types)
    except Exception as e:
        # if we failed to get the reports then log the exception to get a full stack trace and re-raise
        log.error(f"Failed to get scan reports with scan id {scan_id} - {str(e)}", exc_info=True)
        raise

    if write_reports:
        report_writer = ScanReportWriter(context, '.', output_location=reports_dir, omit_filename_date=False)
    else:
        report_writer = NullReportWriter()

    atx_report_dict = {'atx': {}}
    for model in context.models:
        model_reports = reports_by_model.get(model.model_id, [])

        if len(model_reports) > 0:
            # find earliest & latest times to be used for times in ATX report
            first_report = min(model_reports, key=lambda r: get_iso8601_datetime(r['scan']['started']))
            last_report = max(model_reports, key=lambda r: get_iso8601_datetime(r['scan']['ended']))

            # set scan metadata
            context.scan.scan_id = scan_id
            context.scan.started = first_report['scan']['started']
            context.scan.ended = last_report['scan']['ended']

            atx_report = create_atx_report(context.scan, context.use_case, context.evaluation, model, model_reports, context.atx_weights)
            atx_report_dict['atx'][model.model_id] = atx_report
            report_writer.write_report(atx_report)
        else:
            log.error("Cannot generate ATX report for '{model.model_id}' model - no existing reports were found")
    return atx_report_dict
