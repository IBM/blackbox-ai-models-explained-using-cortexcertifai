"""
Certifai Scan Definition Tester
"""
import numpy as np
from typing import Any, Callable, Sequence, List, NamedTuple
from certifai.common.utils import get_logger
from certifai.common.utils.file_utils import resolve_filepath
from certifai.common.errors import CertifaiException
from certifai.common.hosted_model import IHostedModel
from certifai.common.model_utils import FeatureDrop
from certifai.scanner.certifai_scan import read_blueprint, convert_input_data, find_model
from certifai.scanner.schemas import Model, Dataset, ScanTemplateSchema
from certifai.scanner.evaluation import ScanContext

log = get_logger()

DEFAULT_NUM_RETRIES = 0
DEFAULT_SAMPLE_SIZE = 5
DEFAULT_ROUND_DECIMALS = 7

DEFAULT_OBSERVER = lambda records, predictions=None, err=None: None
DEFAULT_SAMPLE_FUNCTION = lambda data, sample_size: data[:sample_size]

def _verbose_observer(records: list, predictions: list):
    for row, outcome in zip(records, predictions):
        print(f"Sent record: {row}, model returned: {outcome}")


class TestPredictionResult(NamedTuple):
    """Stores summary information for an invidual model being tested against a dataset sample."""
    model_id: str
    dataset_id: str
    status: str
    error: str = None


def _do_model_predict(hosted_model: IHostedModel,
                      sample: Sequence,
                      retries: int = DEFAULT_NUM_RETRIES):
    if not isinstance(sample, np.ndarray):
        sample = np.asarray(sample)

    predict_results = hosted_model.predict(sample, retries=retries)
    if len(predict_results) != len(sample):
        raise CertifaiException(("model returned different number of results than dataset sample size. "
                                 f"result size: {len(predict_results)}, sample size: {len(sample)}"))
    return predict_results

def round_results(predictions: np.ndarray, decimals: int) -> np.ndarray:
    try:
        return np.round(np.asarray(predictions, dtype=np.float), decimals)
    except:
        return predictions # can't round non-float types

def sample_model_against_dataset(model: Model,
                                 dataset: Dataset,
                                 model_features: dict,
                                 sample_size: int = DEFAULT_SAMPLE_SIZE,
                                 sampling_function: Callable[[list, int], list] = DEFAULT_SAMPLE_FUNCTION,
                                 observer: Callable[[list, Any], None] = DEFAULT_OBSERVER,
                                 round_decimals: int = DEFAULT_ROUND_DECIMALS) -> None:
    """
    Tests a model against a dataset by calling predict on a sample set of records.
    :param model: model to test
    :param dataset: dataset to test against
    :param model_features: dictionary of features exposed to model
    :param sample_size: optional sample size
    :param sampling_function: optional function for generating a sample from the dataset
    :param round_decimals: optional number of digits to round decimals too
    :param observer: optional observer function that takes the results of each prediction
    """
    hosted_model = model.hosted_model
    if len(dataset.non_model_column_indexes) > 0:
        hosted_model = hosted_model.contramap(FeatureDrop(dataset.non_model_column_indexes,
                                                          len(model_features)))
    sample = sampling_function(dataset.data, sample_size).values

    batch_predict_results = _do_model_predict(hosted_model, sample)
    rounded_batch_predict_results = round_results(batch_predict_results, round_decimals)

    observer(sample, batch_predict_results)

    for idx in range(sample.shape[0]):
        record = sample[idx]
        predict_result = _do_model_predict(hosted_model, [record])
        observer([record], predict_result)
        if round_results(predict_result, round_decimals) != rounded_batch_predict_results[idx]:
            raise CertifaiException(f"Individual model prediction does not match batch model predictions")

def scan_definition_test(filename: str,
                         sample_size: int = DEFAULT_SAMPLE_SIZE,
                         model_id: str = None,
                         verbose: bool = False,
                         round_decimals: int = DEFAULT_ROUND_DECIMALS) -> List[TestPredictionResult]:
    """
    Parses a scan definition and tests that the models against the datasets in the definition.
    :param filename: path to scan definition
    :param sample_size: optional sample size
    :param model_id: optional model_id to limit which models will be tested
    :param verbose: optional verbose flag for printing sample and prediction results
    :param round_decimals: optional number of digits to round decimals too
    :return: a list of TestPredictionResults containing a summary of the test results
    """
    data_in = ScanTemplateSchema().load(read_blueprint(filename))
    context = convert_input_data(data_in, resolve_filepath(filename, '.', is_file=True))

    models = context.models
    if model_id is not None:
        models = [find_model(models, model_id)]

    # currently only testing datasets used in evaluation
    datasets = filter(lambda ds: ds is not None, [context.eval_dataset, context.expl_dataset, context.test_dataset])

    results = []
    observer = _verbose_observer if verbose else DEFAULT_OBSERVER
    for ds in datasets:
        for model in models:
            try:
                log.info(f"Testing '{model.model_id}' against dataset '{ds.dataset_id}'")
                sample_model_against_dataset(model, ds, context.model_features, sample_size=sample_size,
                                             observer=observer, round_decimals=round_decimals)
                results.append(TestPredictionResult(model.model_id, ds.dataset_id, 'Completed'))
            except Exception as e:
                log.error(f"Prediction test failed for '{model.model_id}' model against dataset '{ds.dataset_id}': {str(e)}", exc_info=True)
                results.append(TestPredictionResult(model.model_id, ds.dataset_id, 'Failed', str(e)))

    return results
