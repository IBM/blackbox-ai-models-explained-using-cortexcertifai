"""
Certifai Scanner
"""
from typing import Union, List, Dict, Optional, Tuple

import re
import os
import yaml
import numpy as np
import pandas as pd
from collections import Counter

from certifai.engine.license.validate import raise_for_invalid_license

from certifai.common.dataset import read_dataset
from certifai.common.errors import CertifaiException, CertifaiValidationException
from certifai.common.features import infer_feature_data_dictionary, infer_feature_single_column, process_data
from certifai.common.features import data_type_to_engine_feature_type, get_feature_type_conversion_func
from certifai.common.helpers import drop_columns_by_label_or_index, normalize_to_header, get_column_indexes
from certifai.common.types import (FileTypeEnum, JsonOrientEnum, FeatureTypeEnum,
                                   EvaluationTypeEnum, ModelTypeEnum, RestrictionStringEnum)
from certifai.common.utils import get_logger
from certifai.common.hosted_model import HostedModel, IHostedModel, ExternalConnectionFactory
from certifai.common.utils.encoding import CatEncoder
from certifai.common.utils.file_utils import resolve_filepath
from certifai.common.progress_task import AbstractTask, ProgressUpdate

from certifai.scanner.schemas import (EVALUATION_TYPES, ExplainabilityScoring, ATXComponentScoring,
                                      Scan, dump_many, ScanTemplateSchema, ScanTemplate, ModelConnector,
                                      ATXComponentScoringSchema, ExplainabilityScoringSchema, ATX_COMPONENTS,
                                      ModelHeadersSchema, Model, ENV_VARIABLE_REGEX, ModelHeaders,
                                      DatasetSchemaDef)

from certifai.scanner.types import ScanContext
from certifai.scanner.evaluation import ScanEvaluator
from certifai.scanner.preflight import get_preflight_report_for_model
from certifai.scanner.preflight_checks import get_recommended_checker, get_preflight_time_estimator
from certifai.scanner.report_writer import ScanReportWriter, NullReportWriter, resolve_report_location
from certifai.scanner.utils import get_file_open_function, convert_numpy_objects


log = get_logger()


#############################################################
## Marshmallow Schemas
#############################################################

# input schema
scan_template_schema = ScanTemplateSchema()

#############################################################
## Input Validation/Deserialization
#############################################################


def feature_names(dataset_schema_def):
    return frozenset([f.feature_name for f in dataset_schema_def.feature_schemas])


def validate_dataset_against_schema(ds, dataset_schema_def):
    non_required_cols = dataset_schema_def.all_non_model_features
    # warn if there are features that are not in the dataset
    for col in feature_names(dataset_schema_def):
        if col not in non_required_cols and normalize_to_header(col, ds.data) is None:
            ds_id = ds.dataset_id
            log.warning(f"{col} is defined in feature schemas but is not in dataset id {ds_id}")


#################################
## Dataset operations
#################################

def _validate_feature_order(df, dataset, feature_order):
    """
    Validates that the specified feature_order is compatible with the dataframe and associated dataset.
    Raise a CertifaiValidationException if the feature_order is invalid.
    """
    errors = []
    if feature_order is None:
        errors.append("'defined_feature_order' is true but no feature order was specified")
    elif len(feature_order) != len(df.columns):
        errors.append("specified feature order length (%d) does not match number of features " \
                      "in '%s' dataset (%d)" % (len(feature_order), dataset.dataset_id, len(df.columns)))
    elif dataset.file_type == FileTypeEnum.json and dataset.orient == JsonOrientEnum.records:
        # need to verify that the feature_order contains the same names as df.columns.values
        # if they are different, then when we reindex - the 'new' column names will be filled with nan

        # using a multiset here because columns can have repeated names
        feature_order_multiset = Counter(feature_order)
        existing_columns_multiset = Counter(df.columns)
        if feature_order_multiset != existing_columns_multiset:
            errors.append("specified features do not match the exisiting json (record) dataset " \
                          "columns - cannot apply specified feature order for %s dataset" % dataset.dataset_id)
    if errors:
        raise CertifaiValidationException('Dataset feature order validation failed', errors)

def _apply_feature_order(df, dataset, feature_order):
    """
    Applies the specified feature_order onto the dataframe and associated dataset - first
    validates the feature_order against the dataset. The resulting pd.Dataframe is returned
    as applying the feature_order may not happen in-place.
    """
    # perform necessary validation
    _validate_feature_order(df, dataset, feature_order)

    if dataset.file_type == FileTypeEnum.csv and dataset.has_header:
        # we're imposing a schema-defined ordering on a CSV that has headers, which is a little odd
        # so warn this case unless the names all match
        if feature_order != list(df.columns):
            log.warning("Feature names and ordering provided by the schema do not match the CSV header line.  Schema order will be used.")

    # csv and json values/columns specify feature order based on indexing - we assume features are
    # in order and the user is just specifying column names
    if dataset.file_type == FileTypeEnum.csv or dataset.orient != JsonOrientEnum.records:
        df.columns = feature_order

    # json records (e.g. {column -> value}) don't have an explicit order, so the df is in
    # an arbitrary order. Have to reindex the columns to get the specified order.
    elif dataset.orient == JsonOrientEnum.records:
        df = df.reindex(labels=feature_order, axis=1) # can't happen in-place
    return df


def drop_dataset_outcomes(df, dataset_schema):
    outcome_column = dataset_schema.outcome_column
    predicted_outcome_column = dataset_schema.predicted_outcome_column
    df, dropped_cols = drop_columns_by_label_or_index([outcome_column, predicted_outcome_column], df, inplace=False)
    return df, dropped_cols[0]


def apply_dataset_schema_changes(df, dataset, dataset_schema, drop_outcomes=True):
    """
    Applies the following changes from the dataset schema onto the dataframe & dataset:
    * Drop outcome & predicted_outcome column(s), if specified in dataset_schema
    * Applies a feature_order on the dataframe, if specified in the dataset_schema
    Returns the resulting df as applying a feature_order cannot be done in-place.
    """
    feature_order = [feat.feature_name for feat in dataset_schema.feature_schemas]

    # feature order should contain outcome/predicted_outcome
    if dataset_schema.defined_feature_order:
        df = _apply_feature_order(df, dataset, feature_order)

    if drop_outcomes:
        return drop_dataset_outcomes(df, dataset_schema)
    else:
        return df, None

def find_model(models, model_id):
    """Finds the model with the specified model_id - raises a CertifaiValidationException if not found."""
    try:
        return next(m for m in models if m.model_id == model_id)
    except:
        errors = [f"No model found with id '{model_id}'"]
        raise CertifaiValidationException("Model validation failed", errors)

def find_dataset(datasets, dataset_id, from_field):
    """Finds the dataset with the specified dataset_id - raises a CertifaiValidationException if not found."""
    try:
        return next(ds for ds in datasets if ds.dataset_id == dataset_id)
    except:
        errors = [f"No dataset found with id '{dataset_id}', which is specified as the value of '{from_field}'"]
        raise CertifaiValidationException("Dataset validation failed", errors)





def separate_dataset_outcomes(dataset, dataset_schema):
    data, ground_truth = drop_dataset_outcomes(dataset.data, dataset_schema)
    dataset.data = data
    dataset.ground_truth = ground_truth
    dataset.non_model_column_indexes = get_column_indexes(dataset_schema.all_non_model_features, data)


def materialize_dataset(dataset, base_path):
    if dataset.data is None:
        if (dataset.url is None) or (dataset.file_type is None):
            # This case can occur when running with a local dataset in a Notebook and that dataset
            # has not been provided
            raise CertifaiException(f"No source provided for dataset '{dataset.dataset_id}'")
        ds_path = resolve_filepath(base_path, dataset.url)
        df, checksum, checksum_type = read_dataset(ds_path, dataset.file_type, **vars(dataset))
        dataset.checksum = checksum
        dataset.checksum_type = checksum_type
        dataset.data = df


def _convert_to_value_encoding(df, schema: DatasetSchemaDef):
    encoded_cat_columns = []
    encoded_cat_col_details = []

    for feature in schema.feature_schemas:
        if (feature.data_type == 'categorical') and (feature.one_hot_columns is not None):
            encoded_cat_columns.append(feature.feature_name)
            encoded_cat_col_details.append([(d.name, d.value) for d in feature.one_hot_columns])

    if len(encoded_cat_columns) > 0:
        # The encoder operates on the model_schema so we need to decode only columns that the model sees
        if len(schema.all_non_model_features) > 0:
            model_df = df.drop(schema.all_non_model_features, axis=1)
        else:
            model_df = df
        encoder = CatEncoder(encoded_cat_columns,
                             model_df,
                             cat_column_value_names=encoded_cat_col_details,
                             data_encoded=True,
                             string_equivalence=False)
        decoded = pd.DataFrame(encoder.decode(model_df.values), columns=encoder.untransformed_features)
        non_cat_cols = [c for c in decoded.columns if c not in encoded_cat_columns]
        # preserve column dtypes for those not encoded
        decoded = decoded.astype({k: model_df[k].dtype for k in non_cat_cols})
        if len(schema.all_non_model_features) > 0:
            df.index = decoded.index
            decoded[list(schema.all_non_model_features)] = df[list(schema.all_non_model_features)]
        return decoded, encoder
    else:
        return df, None


def create_dataset(dataset, dataset_schema, base_path, drop_outcomes=True):
    """Creates the dataset and applies the changes specified in the dataset_schema."""
    try:
        log.details(f"Creating dataset with id: {dataset.dataset_id}")
        if dataset.data is None:
            materialize_dataset(dataset, base_path)
        if dataset.encoder is None:
            dataset.data, dataset.encoder = _convert_to_value_encoding(dataset.data,
                                                                       dataset_schema)
        dataset.rows = len(dataset.data)
        dataset.num_features = len(dataset.data.columns)
        df, ground_truth = apply_dataset_schema_changes(dataset.data, dataset, dataset_schema, drop_outcomes=drop_outcomes)
        dataset.data = df
        dataset.ground_truth = ground_truth
        dataset.non_model_column_indexes = get_column_indexes(dataset_schema.all_non_model_features, df)
        return dataset
    except Exception as e:
        log.error(f"Unable to create dataset with id: {dataset.dataset_id} - {str(e)}", exc_info=True)
        raise CertifaiException(f"Unable to create dataset - {str(e)}")


def create_features(datasets, feature_schema_updates):
    """Creates a list of features from the specified dataset and schema updates."""
    try:
        data = pd.concat([d.data for d in datasets])
        # infer features then apply user overrides
        log.details('Inferring dataset features and applying user overrides')
        features = infer_feature_data_dictionary(data)
        features = apply_feature_schema_overrides(features, feature_schema_updates, data)
        return features
    except Exception as e:
        log.error(f"Unable to create dataset feature schema - {str(e)}", exc_info=True)
        raise CertifaiException(f"Unable to create dataset feature schema - {str(e)}")

#################################
## Feature-schema related overrides
#################################

def _apply_feature_overrides(feature, feature_update, dataframe):
    """
    Applies the specified feature updates to a single feature. A new feature (dict) is returned
    with the applied updates.
    """
    # helper functions
    def category_values_prop(feat):
        return feat.category_values

    def target_encodings_prop(feat):
        return feat.target_encodings

    def min_prop(feat):
        return feat.min

    def max_prop(feat):
        return feat.max

    def spread_prop(feat):
        return feat.spread

    # Lookup of prop name to getter func - note - although this *could* be done
    # with reflection this seems safer in case of future name changes, and also
    # forces deliberation when we add new options
    prop_value = {
        'category_values': category_values_prop,
        'target_encodings': target_encodings_prop,
        'min':             min_prop,
        'max':             max_prop,
        'spread':          spread_prop,
    }

    def _apply_feature_prop_override(feat, feat_update, prop_name, data_type=None):
        value = prop_value[prop_name](feat_update)
        if value is not None:
            log.details("Applying feature override for '%s' attribute of feature '%s'", prop_name, feat['name'])
            feat[prop_name] = data_type(value) if data_type else value

    def _warn_about_invalid_overrides(feat, feat_update, prop_names):
        for prop_name in prop_names:
            if prop_value[prop_name](feat_update):
                log.warning(("non-applicable feature override specified for '%s' attribute of "
                             "feature '%s' of type '%s' - ignoring override"), prop_name, feat['name'], feat['type'])

    new_feature = feature.copy()
    if feature_update.data_type is not None:
        new_type = data_type_to_engine_feature_type(feature_update.data_type)
        if new_type != feature['type']:
            log.details("Overriding inferred type of %s for feature '%s' with %s", feature['type'], feature['name'], new_type)
            log.details("Re-inferring properties for feature '%s'", feature['name'])
            new_feature = infer_feature_single_column(dataframe[feature['name']], type_hint=new_type)
            new_feature.update({
                'name': feature['name'],       # these values cannot be re-computed
                'index': feature['index'],
                'constant': feature.get('constant', False)
            })
        else:
            log.details("Inferred type matches specified type for feature '%s' - skip re-inferring properties", feature['name'])

    def np_object_array(x):
        return np.array(x, dtype='object')

    if new_feature['type'] == FeatureTypeEnum.CAT:
        _apply_feature_prop_override(new_feature, feature_update, 'category_values', data_type=np_object_array)
        _apply_feature_prop_override(new_feature, feature_update, 'target_encodings', data_type=np_object_array)
        _warn_about_invalid_overrides(new_feature, feature_update, ['min', 'max', 'spread'])
        if len(feature_update.one_hot_columns or []) > 0:
            new_feature['one_hot'] = True
    else:
        convert = get_feature_type_conversion_func(feature['type'])
        _apply_feature_prop_override(new_feature, feature_update, 'min', data_type=convert)
        _apply_feature_prop_override(new_feature, feature_update, 'max', data_type=convert)
        _apply_feature_prop_override(new_feature, feature_update, 'spread', data_type=np.float64) # always a float
        _warn_about_invalid_overrides(new_feature, feature_update, ['category_values', 'target_encodings'])

    return new_feature

def apply_feature_schema_overrides(features, feat_schema_updates, dataset_df):
    """
    Returns a new list of features with the given feature schema updates applied to the input features.
    The dataset associated with the features must be passed in order to re-infer certain feature.
    """
    new_features = []
    for feature in features:
        update = next((update for update in feat_schema_updates if feature['name'] == update.feature_name), None)
        if update:
            new_features.append(_apply_feature_overrides(feature, update, dataset_df))
        else:
            new_features.append(feature)

    return new_features


def _normalize_fairness_grouping_features(fairness_grouping_features, features):
    errors = []
    features_by_name = {f['name']: f for f in features}
    for feat in fairness_grouping_features:
        if feat.name not in features_by_name:
            errors.append(f"Unknown feature '{feat.name}' specified in fairness_grouping_features")
        else:
            feature = features_by_name[feat.name]
        explicit_bucket_values = set()
        for bucket in feat.buckets:
            explicit_bucket_values.update(set(bucket.values))
            if (bucket.max is not None) and \
               (feature['type'] == FeatureTypeEnum.CAT) and \
               (type(feature['category_values'][0])!=int):
                    errors.append(f"Grouping feature '{feat.name}' cannot define buckets using max bounds because it is not numeric")
        if len(explicit_bucket_values) > 0:
            cat_vals_as_str = frozenset([str(v) for v in feature['category_values']])
            if feature['type'] != FeatureTypeEnum.CAT:
                errors.append(f"Grouping feature '{feat.name}' cannot define buckets using explicit values because it is not categorical")
            else:
                missing = cat_vals_as_str.difference(explicit_bucket_values)
                if len(missing) > 0:
                    errors.append(f"Grouping feature '{feat.name}' does not define buckets for all possible values. Missing values: {missing}")
        # sort buckets by max bound if any)
        max_bounds = list(filter(None, [b.max for b in feat.buckets]))
        if len(max_bounds) > 0:
            feat.buckets.sort(key=lambda x: x.max if x.max is not None else max(max_bounds)+1)
    if errors:
        raise CertifaiValidationException('Evaluation validation failed', errors)


def _validate_feature_restrictions(feature_restrictions, model_features, non_model_features):
    errors = []
    restrictions_to_remove = [] # contains index of feature restrictions applied to non_model_features
    features_by_name = {f['name']: f for f in model_features}
    for idx, feat in enumerate(feature_restrictions):
        if feat.feature_name in non_model_features and feat.feature_name not in features_by_name:
            restrictions_to_remove.append(idx)
        elif feat.feature_name not in features_by_name:
            errors.append(f"Unknown feature '{feat.feature_name}' specified in feature_restrictions")
        else:
            feature = features_by_name[feat.feature_name]
            if FeatureTypeEnum.is_categorical(feature['type']) and \
               feat.restriction_string in (RestrictionStringEnum.min_max,
                                           RestrictionStringEnum.percentage):
                errors.append(f"Feature restriction '{feat.restriction_string}' cannot be applied to categorical feature {feature['name']}")
    if errors:
        raise CertifaiValidationException('Evaluation validation failed', errors)

    for idx in restrictions_to_remove:
        log.warning(f"Ignoring feature restriction for feature '{feat.feature_name}' because the feature is not exposed to model(s)")
        feature_restrictions.pop(idx)





def _convert_to_engine_explainability_weights(weights: Optional[List[ExplainabilityScoring]]) -> List[int]:
    """
    Transforms the explainability input data into the expected format used by the engine.
    Turns the list of objects to a list of weights indexed by num_features,
    e.g: [{'num_features': 1, 'value': 100}, ...] -> [100, ...].
    """
    if weights is None:
        weights = ExplainabilityScoringSchema.DEFAULTS

    max_num_features = max(map(lambda x: x.num_features, weights))
    explainability = [0]*max_num_features
    for item in weights:
        num_features = item.num_features
        score = item.value
        explainability[num_features - 1] = score

    return explainability


def _convert_to_engine_aspect_weights(weights: Optional[List[ATXComponentScoring]],
                                      evaluation_types: List[str]) -> Dict[str, float]:
    """
    Transforms the atx aspect weights input data into the expected format used by the engine.
    Turns the list of dicts to a single flattened dictionary.
    e.g: [{'robustness': 1.0}, ...] -> {'robustness': 100, ...}
    """
    if weights is None:
        weights = [w for w in ATXComponentScoringSchema.DEFAULTS if w.name in evaluation_types]

    return {item.name: item.value for item in weights}


def _apply_auth(env_var, value):
    pattern = re.compile(ENV_VARIABLE_REGEX)
    match = pattern.findall(str(value))
    if match:
        full_value = value
        for g in match:
            replace_with = os.environ.get(g)
            if replace_with is None:
                error = f'Environment variable {g} not set'
                raise CertifaiValidationException(f'Environment variable injection failed for {env_var}', [error])
            full_value = full_value.replace(
                f'${{{g}}}', replace_with
            )
        return full_value
    return value


def _apply_model_headers_and_connectors(model_headers: Optional[ModelHeaders],
                                        models: List[Model],
                                        connectors: List[ModelConnector]) -> List[Model]:

    for model in models:
        connector_matched = False
        for mc in connectors:
            model_ids = mc.model_ids
            model_args = dict((d.name, d.value) for d in mc.model_args) if mc.model_args is not None else {}
            model_secrets = dict((d.name, d.value) for d in mc.secrets) if mc.secrets is not None else {}
            con = ExternalConnectionFactory(mc.module_name, mc.class_name)

            if model.model_id in model_ids:
                if connector_matched:
                    errors.append(f"Model id '{model.model_id}' is listed in multiple connectors")
                    break
                connector_matched = True
                model.hosted_model = con.get_instance(model.predict_endpoint,
                                                      batch_support=True,
                                                      max_batch_size=model.max_batch_size,
                                                      label_ordering=model.prediction_value_order,
                                                      supports_soft_scores=model.supports_soft_scoring,
                                                      model_args=model_args,
                                                      model_secrets={k: _apply_auth(k, v)
                                                                     for k, v in model_secrets.items()})
        if not connector_matched:
            # Connectors are responsible for their own transport of which headers are a part
            if model_headers and (model_headers.default or model_headers.defined):
                default_headers = {default_header.name: default_header.value for default_header in model_headers.default} \
                    if model_headers.default is not None else {}

                override_headers = {defined_header.name: defined_header.value for defined_header in model_headers.defined
                                    if model.model_id == defined_header.model_id} if model_headers.defined is not None else {}
                headers = {**default_headers, **override_headers} if override_headers else default_headers
                headers = {k: _apply_auth(k,v) for k, v in headers.items()}
                model.hosted_model.headers = headers
    return models


def convert_input_data(scan_template: ScanTemplate, base_path):
    log.info('Validating input data...')

    use_case = scan_template.model_use_case
    evaluation = scan_template.evaluation
    scan = scan_template.scan
    models = scan_template.models
    model_headers = scan_template.model_headers
    models = _apply_model_headers_and_connectors(model_headers, models, scan_template.model_connectors)
    explainability_weights = _convert_to_engine_explainability_weights(scan_template.scoring.explainability)
    atx_weights = _convert_to_engine_aspect_weights(scan_template.scoring.aspect_weights,
                                                    evaluation.evaluation_types)
    test_id = evaluation.test_dataset_id
    dataset_schema = scan_template.dataset_schema
    datasets = scan_template.datasets

    eval_id = evaluation.evaluation_dataset_id
    eval_dataset = create_dataset(find_dataset(datasets, eval_id, 'evaluation_dataset_id'),
                                  dataset_schema,
                                  base_path,
                                  drop_outcomes=False)
    validate_dataset_against_schema(eval_dataset, dataset_schema)

    # Add model encoding if the dataset has an encoder - this is used to encode back into 1-hot
    # space for models with already-encoded data requirements
    if eval_dataset.encoder is not None:
        for model in models:
            model.hosted_model = model.hosted_model.contramap(eval_dataset.encoder)

    # Generate effective feature schema details for the dataset
    feature_schema_updates = dataset_schema.feature_schemas

    unique_datasets = [eval_dataset]

    expl_id = evaluation.explanation_dataset_id
    if expl_id == eval_id:
        expl_dataset = eval_dataset
    elif expl_id is not None:
        expl_dataset = create_dataset(find_dataset(datasets, expl_id, 'explanation_dataset_id'),
                                      dataset_schema,
                                      base_path,
                                      drop_outcomes=False)
        validate_dataset_against_schema(expl_dataset, dataset_schema)
        unique_datasets.append(expl_dataset)
    else:
        expl_dataset = None

    if test_id == eval_id:
        test_dataset = eval_dataset
    elif test_id == expl_id:
        test_dataset = expl_dataset
    elif test_id is not None:
        test_dataset = create_dataset(find_dataset(datasets, test_id, 'test_dataset_id'),
                                      dataset_schema,
                                      base_path,
                                      drop_outcomes=False)
        validate_dataset_against_schema(test_dataset, dataset_schema)
        unique_datasets.append(test_dataset)
    else:
        test_dataset = None

    dataset_features = create_features(unique_datasets, feature_schema_updates)

    # Drop outcome columns and generate the effective feature schema for the data provided to the model
    separate_dataset_outcomes(eval_dataset, dataset_schema)
    if expl_dataset is not None and expl_id != eval_id:
        separate_dataset_outcomes(expl_dataset, dataset_schema)
    if test_dataset is not None and test_id not in (eval_id, expl_id):
        separate_dataset_outcomes(test_dataset, dataset_schema)

    model_features = create_features(unique_datasets, feature_schema_updates)

    # apply extra processing
    def extra_dataset_processing(dataset):
        if not dataset.pre_processed:
            dataset.data = process_data(dataset.data, model_features, len(dataset.data))
            dataset.pre_processed = True

    extra_dataset_processing(eval_dataset)
    if expl_dataset is not None:
        extra_dataset_processing(expl_dataset)
    if test_dataset is not None:
        extra_dataset_processing(test_dataset)

    # Set model label ordering defaults if need be
    if len(evaluation.prediction_values or []) > 0:
        default_ordering = [p.value for p in evaluation.prediction_values]
        for model in models:
            if model.hosted_model.label_ordering is None:
                model.hosted_model.label_ordering = default_ordering

    _normalize_fairness_grouping_features(evaluation.fairness_grouping_features, model_features)
    _validate_feature_restrictions(evaluation.feature_restrictions, model_features, dataset_schema.all_non_model_features)
    log.info('Input validation complete')
    return ScanContext(**{
        'scan': scan,
        'models': models,
        'use_case': use_case,
        'evaluation': evaluation,
        'dataset_schema': dataset_schema,
        'dataset_features': dataset_features,
        'model_features': model_features,
        'eval_dataset': eval_dataset,
        'expl_dataset': expl_dataset,
        'test_dataset': test_dataset,
        'atx_weights': atx_weights,
        'explainability_weights': explainability_weights
    })


def _apply_overrides(parsed_data, model=None, report=None, model_id_tags=None, **kwargs):
    """Applies the specified overrides to the already processed input data."""
    errors = []
    if model:
        log.info(f"Limiting evaluation to single model: '{model}'")
        parsed_data.models = [m for m in parsed_data.models if m.model_id == model]
        if len(parsed_data.models) == 0:
            errors.append(f"Model with id '{model}' not found - cannot apply overrides")

    if model_id_tags:
        models = parsed_data.models
        for id_key_pair in model_id_tags:
            if '=' in id_key_pair and len(id_key_pair.split('=')) == 2:
                model_id,tag_value = id_key_pair.split('=')
                model_matches = list(filter(lambda m: m.model_id == model_id, models))
                if len(model_matches) == 1:
                    model = model_matches[0]
                    model.model_id_tag = tag_value
                else:
                    errors.append(f"Invalid model-id-tag model_id: '{model_id}', no model in scan definition matches this id. Ids found: {[m.model_id for m in models]}")
            else:
                errors.append(f"Invalid model-id-tag '{id_key_pair}', expecting one or more pairs in the form: 'id1=value1 id2=value2', got: {' '.join(model_id_tags)}")

    if report:
        log.info(f"Limiting scan to report type: '{report}'")
        if report not in EVALUATION_TYPES:
            errors.append(f"Unknown report type specified: '{report}' - cannot apply overrides")
        elif report not in parsed_data.evaluation.evaluation_types:
            errors.append(f"Cannot apply report type '{report}', it is not specified in the scan definition - cannot apply overrides")
        else:
            parsed_data.evaluation.evaluation_types = [report]

    scan_id = kwargs.get('scan_id', None) # undocumented kwarg - not for general usage
    if scan_id:
        parsed_data.scan.scan_id = scan_id

    if errors:
        raise CertifaiValidationException('Override validation failed', errors)

    return parsed_data


def read_blueprint(filename):
    try:
        open_fn = get_file_open_function(filename, text=True)
        with open_fn() as yaml_stream:
            data_in = yaml.safe_load(yaml_stream)
        return data_in
    except yaml.YAMLError as yexc:
        if hasattr(yexc, 'problem_mark'):
            mark = yexc.problem_mark
            reason = f"Check error position: (line: {mark.line + 1}, column: {mark.column + 1})"
        else:
            reason = str(yexc)
        error = f"Unable to read scan definition file: {reason}"
        log.error(error, exc_info=True)
        raise CertifaiException(error) from None # suppress yaml error stack-trace



def process_blueprint(template_source: Union[str, ScanTemplate],
                      model=None,
                      report=None,
                      model_id_tags=None,
                      omit_filename_date=False,
                      details=False,
                      output=None,
                      write_reports=True,
                      base_path=None,
                      cwd=None,
                      progress_listener=None,
                      preflight=False,
                      **kwargs) -> list:
    """
    Processes a scan definition.
    :param filename: path to scan definition file
    :param model: optional model id to limit scan to
    :param report: optional report type to limit scan to
    :param model_id_tags: list of model id/tag strings to apply to reports (e.g.: "<model_id>=<a-tag-value>")
    :param details: produce extra details in the scanner reports, default False
    :param output: optional override path to write reports to
    :param omit_filename_date: *Note: this option is not shown in the CLI, it's used only for testing* - Omit date from the filename in output reports, default False
    :param progress_listener: optional callback function that takes a ProgressUpdate object for reporting the status of evaluations
    """
    log.info("Validating license...")
    lic = raise_for_invalid_license()
    log.info(f"License is valid - expires: {lic.expiry if lic else 'n/a'}")

    reports_dict = {}
    try:
        if isinstance(template_source, str):
            if base_path is None:
                base_path = resolve_filepath(template_source, '.', is_file=True)
            data_in = scan_template_schema.load(read_blueprint(template_source))
        else:
            if base_path is None:
                base_path = '.'
            raw_data = template_source.dump(mode='definition') # mode != 'report'
            data_in = scan_template_schema.load(raw_data, notebook_semantics=True) # loose validation
            data_in.models = template_source.models
            data_in.datasets = template_source.datasets

        # transform data
        scan_context = convert_input_data(data_in, base_path)

        # apply overrides
        scan_context = _apply_overrides(scan_context, model, report, model_id_tags, **kwargs)

        # Special case check for condition that can arise in notebook usage where a local model is defined
        # but its implementation has not been provided (parsing ensures this condition cannot happen in
        # scanner usage)
        for m in scan_context.models:
            if m.hosted_model is None:
                raise CertifaiException(f"Model '{m.model_id}' has no model implementation provided")

        output_base_path = cwd if output else base_path
        full_report_path = resolve_report_location(scan_context, output_base_path, output)[1]

        preflight_reports = {}
        for m in scan_context.models:
            preflight_reports[m.model_id] = get_preflight_report_for_model(full_report_path, scan_context.use_case.model_use_case_id, m.model_id)

        if preflight:
            log.info("Running preflight scan")
            # compose preflight checkers for each model into a single task
            composed_checker = AbstractTask.compose([get_recommended_checker(scan_context, m, preflight_reports[m.model_id]) for m in scan_context.models])
            if progress_listener is not None:
                progress_listener(ProgressUpdate(0, composed_checker.estimate(), "Starting Preflight Scan"))

            preflight_dict = {}
            results = composed_checker.run(progress_listener)
            for idx, m in enumerate(scan_context.models):
                preflight_dict[m.model_id] = results[idx].as_dict()
                preflight_reports[m.model_id].save()

            return preflight_dict
        else:
            time_estimator = get_preflight_time_estimator(scan_context, preflight_reports)
            has_atx_component = any((e in ATX_COMPONENTS for e in scan_context.evaluation.evaluation_types))
            evaluator = ScanEvaluator(scan_context, time_estimator)
            if write_reports:
                report_writer = ScanReportWriter(scan_context, output_base_path, output_location=output, omit_filename_date=omit_filename_date)
            else:
                report_writer = NullReportWriter()

            # run evaluations and write reports
            report_results = []
            for report in evaluator.run(progress_listener,
                                        details,
                                        compute_atx=(report is None) and has_atx_component):
                report_writer.write_report(report)
                report_results.append(report)

            # convert report list -> report dictionary
            reports_dict = _build_report_dictionary(report_results)
            return reports_dict
    except Exception as e:
        log.error(f"Scan Failed - {e}", exc_info=True)
        raise

    return reports_dict


def _build_report_dictionary(results):
    result_dict = {}
    for result in results:
        scan = result['scan']
        evaluation_type = scan.get('evaluation_type', 'no_scan_type')
        model_id = result.get('model', {}).get('model_id', 'NO_MODEL_ID')
        eval_type_dict = result_dict.get(evaluation_type, {})
        eval_type_dict[model_id] = result
        result_dict[evaluation_type] = eval_type_dict
    return result_dict
