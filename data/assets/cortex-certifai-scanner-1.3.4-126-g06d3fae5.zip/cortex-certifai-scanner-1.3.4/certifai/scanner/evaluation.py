import os
import copy
import signal
import numpy as np
from copy import deepcopy
from typing import List, Optional, Any, Callable, Iterable
from collections import OrderedDict
from dataclasses import dataclass

from certifai.common.errors import CertifaiException, CertifaiTimeEstimateException
from certifai.common.types import EvaluationTypeEnum, ScanStatusEnum
from certifai.common.utils import get_logger
from certifai.common.utils.utils import get_iso8601_date, to_filename_safe_chars
from certifai.common.signal_handler import sigint_handling
from certifai.common.progress_task import ProgressUpdate, ProgressListener, AbstractTask
from certifai.common.utils.atx import compute_atx_score

from certifai.engine.model import Certifai
from certifai.engine.engine_api_types import CertifaiAnalysis
from certifai.engine.options import get_cfi_hyper_params
from certifai.engine.performance import generate_performance_metrics, metric_evaluators
from certifai.engine.fairness_metrics import fairness_metric_provider, calculate_non_burden_fairness

from certifai.scanner.formatting import format_report
from certifai.scanner.options import (get_evaluation_options,
                                      get_fairness_options,
                                      get_favorable_outcome_value)
from certifai.scanner.types import ScanContext, ScanTimeEstimator
from certifai.scanner.schemas import Model, Dataset

log = get_logger()


@dataclass
class EvaluationResult:
    """Dataclass encapsulating the result of a single evaluation."""
    started: str
    ended: str
    eval_type: EvaluationTypeEnum
    status: ScanStatusEnum
    data: Optional[Any]
    error: Optional[str]


# decorator factory - meant to wrap a method of the ScanEvaluator class and create an EvaluationResult
# object from the returned value
def evaluation(eval_type=None):
    def evaluation_decorator(f):
        def wrapper(self, model):
            start = get_iso8601_date()
            try:
                data = f(self, model)
                return EvaluationResult(start, get_iso8601_date(), eval_type, ScanStatusEnum.completed, data, None)
            except Exception as e:
                log.exception(f"{eval_type} report failed for model {model.model_id} - {str(e)}")
                return EvaluationResult(start, get_iso8601_date(), eval_type, ScanStatusEnum.failed, None, str(e))

        return wrapper
    return evaluation_decorator


class ScanEvaluator(AbstractTask):
    def __init__(self, context: ScanContext, estimator: Optional[ScanTimeEstimator] = None):
        self._context = context
        self._cert = None # Certifai (engine) instance
        self._listeners = []
        self.report_count = 0
        self._estimator = estimator

    def _do_engine_evaluation(self, model: Model, dataset: Dataset, analysis_type: CertifaiAnalysis, get_counterfactuals = False) -> dict:
        ctx = self._context
        cfi_options = get_evaluation_options(ctx.use_case, ctx.evaluation, model, ctx.model_features, ctx.explainability_weights)
        hyper_params = get_cfi_hyper_params(ctx.use_case.task_type, ctx.evaluation.hyperparameters)
        self._cert = Certifai(model.hosted_model,
                              ctx.model_features,
                              analysis_type,
                              non_model_features=dataset.non_model_column_indexes)
        engine_result = self._cert.generate_counterfactuals(dataset.data.values,
                                                            cfi_options,
                                                            return_counterfactual_instances=get_counterfactuals,
                                                            full_data=ctx.eval_dataset.data.values,
                                                            **hyper_params)
        return engine_result


    @evaluation(eval_type=EvaluationTypeEnum.robustness)
    def robustness_evaluation(self, model: Model):
        ctx = self._context
        return self._do_engine_evaluation(model, ctx.eval_dataset, CertifaiAnalysis.ROBUSTNESS, False)

    @evaluation(eval_type=EvaluationTypeEnum.fairness)
    def fairness_evaluation(self, model: Model):
        ctx = self._context
        fairness_results_dict = {}
        canonical_fairness_metrics = [m.lower() for m in ctx.evaluation.fairness_metrics]
        if 'burden' in canonical_fairness_metrics:
            engine_result = self._do_engine_evaluation(model, ctx.eval_dataset, CertifaiAnalysis.FAIRNESS, False)
            engine_scores = engine_result.pop('scores', None)
            case_preserved_name = next(iter([m for m in ctx.evaluation.fairness_metrics if m.lower() == 'burden']))
            fairness_results_dict[case_preserved_name] = engine_scores
            fairness_results_dict[case_preserved_name]['fairness_metric'] = case_preserved_name

        if canonical_fairness_metrics != ['burden']:
            favorable_values = get_favorable_outcome_value(ctx.use_case, ctx.evaluation)
            options = get_fairness_options(ctx.use_case, ctx.evaluation, ctx.model_features)
            X = np.array(ctx.eval_dataset.data, dtype=object)
            y = ctx.eval_dataset.ground_truth
            if y is None:
                raise CertifaiException('Missing required outcome column (ground truth) in the evaluation dataset for calculating non-burden fairness metrics')
            fairness_results_dict.update(calculate_non_burden_fairness(ctx.evaluation.fairness_metrics,
                                                                       ctx.model_features,
                                                                       favorable_values,
                                                                       options['protected_attr'],
                                                                       X,
                                                                       y,
                                                                       model.hosted_model,
                                                                       non_model_feature_idxs=ctx.eval_dataset.non_model_column_indexes))
            engine_result = {}

        # Find correctly cased primary metric key - note that this will exist or scan def validation
        # would have failed.
        key = [k for k in fairness_results_dict if k.lower() == ctx.evaluation.primary_fairness_metric.lower()][0]
        primary_scores = fairness_results_dict.pop(key)
        result = { 'scores': primary_scores, 'secondary_scores': fairness_results_dict }
        result.update(engine_result)    # Put back the rest of the engine result (stats ect)
        return result

    @evaluation(eval_type=EvaluationTypeEnum.explainability)
    def explainability_evaluation(self, model: Model):
        ctx = self._context
        return self._do_engine_evaluation(model, ctx.eval_dataset, CertifaiAnalysis.EXPLAINABILITY, False)

    @evaluation(eval_type=EvaluationTypeEnum.explanation)
    def explanation_evaluation(self, model: Model):
        ctx = self._context
        return self._do_engine_evaluation(model, ctx.expl_dataset, CertifaiAnalysis.EXPLANATION, True)

    @evaluation(eval_type=EvaluationTypeEnum.performance)
    def performance_evaluation(self, model: Model):
        ctx = self._context
        return calculate_metrics(ctx.use_case, model, ctx.test_dataset, ctx.model_features, ctx.evaluation)

    def preflight_evaluation(self, model: Model):
        ctx = self._context
        return self._do_engine_evaluation(model, ctx.eval_dataset, CertifaiAnalysis.PREFLIGHT, False)

    def _alert_listeners(self, update: ProgressUpdate):
        for listener in self._listeners:
            listener(update)

        if len(self._listeners) == 0:
            log.details(update.summary)

    def _start_message(self) -> str:
        ctx = self._context
        if self._estimator is not None:
            try:
                total =  self._estimator.total_in_minutes()
                start_msg = f"Starting scan with model_use_case_id: '{ctx.use_case.model_use_case_id}' and scan_id: '{ctx.scan.scan_id}', total estimated time is {total} minutes"
            except CertifaiTimeEstimateException as ve:
                log.info(str(ve))
                start_msg = f"Starting scan with model_use_case_id: '{ctx.use_case.model_use_case_id}' and scan_id: '{ctx.scan.scan_id}'"
        else:
            start_msg = f"Starting scan with model_use_case_id: '{ctx.use_case.model_use_case_id}' and scan_id: '{ctx.scan.scan_id}'"
        return start_msg

    def _eval_message(self, model_id, eval_type) -> str:
        if self._estimator is not None:
            try:
                time = self._estimator.time_for_evaluation(model_id, eval_type)
                msg = f"Running {eval_type} evaluation for model: {model_id}, estimated time is {time} seconds"
            except CertifaiTimeEstimateException:
                # silently catching this exception to avoid spammy warnings when the
                # preflight scan was explicitly not run
                msg = f"Running {eval_type} evaluation for model: {model_id}"
        else:
            msg = f"Running {eval_type} evaluation for model: {model_id}"
        return msg


    def run(self,
            callback: ProgressListener,
            details: bool = False,
            compute_atx: bool = True) -> Iterable[dict]:
        ctx = self._context
        if callback is not None:
            self._listeners.append(callback)

        evaluators = {
            EvaluationTypeEnum.performance: self.performance_evaluation,
            EvaluationTypeEnum.robustness: self.robustness_evaluation,
            EvaluationTypeEnum.fairness: self.fairness_evaluation,
            EvaluationTypeEnum.explanation: self.explanation_evaluation,
            EvaluationTypeEnum.explainability: self.explainability_evaluation,
        }

        with sigint_handling(self.scan_signal_handler):
            self.report_count = 0
            total_reports = len(ctx.models) * len(ctx.evaluation.evaluation_types)

            start_msg = self._start_message()
            log.info(start_msg)
            self._alert_listeners(ProgressUpdate(self.report_count, total_reports, start_msg))
            for model in ctx.models:
                start_time = get_iso8601_date()
                model_reports = []
                for eval_type in ctx.evaluation.evaluation_types:
                    self._alert_listeners(ProgressUpdate(self.report_count,
                                                         total_reports,
                                                         self._eval_message(model.model_id, eval_type)))
                    evaluator = evaluators[eval_type]
                    report = format_report(ctx, model, evaluator(model), details=details)
                    model_reports.append(report)
                    self.report_count += 1
                    yield report

                end_time = get_iso8601_date()

                if compute_atx:
                    ctx.scan.started = start_time
                    ctx.scan.ended = end_time
                    atx_report = create_atx_report(ctx.scan, ctx.use_case, ctx.evaluation, model, model_reports, ctx.atx_weights)
                    model_reports.append(atx_report)
                    yield atx_report

            self._alert_listeners(ProgressUpdate(total_reports, total_reports, "Completed all evaluations"))
            return

    def attach(self, callback: ProgressListener):
        if callback is not None:
            self._listeners.append(callback)

    def estimate(self) -> int:
        return len(self._context.models) * len(self._context.evaluation.evaluation_types) - self.report_count

    def scan_signal_handler(self, dwCtrlType, hook_sigint=None):
        if (dwCtrlType == 0) and (self._cert is not None): # CTRL_C_EVENT
            log.warning("Handling interrrupt signal. Scan cancellation initiated ..")
            self._cert.cancel()
            import signal
            os.kill(os.getpid(), signal.SIGINT)
            return 1 # don't chain to the next handler
        else:
            log.warning(f"Engine handler received {dwCtrlType}")
        return 0 # chain to the next handler





## Performance Evaluation

def calculate_metrics(use_case,
                      model,
                      dataset,
                      features,
                      evaluation):
    favorable_values = get_favorable_outcome_value(use_case, evaluation)
    fairness = get_fairness_options(use_case, evaluation, features)
    grouping_features={} if fairness is None else fairness['protected_attr']

    all_values = {}
    if dataset is not None:
        if features is not None:
            extra_providers = [fairness_metric_provider(features, grouping_features)]
        else:
            extra_providers = []
        metrics = []
        metric_names = []
        for m in use_case.performance_metrics:
            if m.metric is not None:
                metric_evals = metric_evaluators(m.metric, extra_providers=extra_providers)
                metrics.extend(metric_evals)
                metric_names.extend(m.name for _ in metric_evals)
        if dataset.ground_truth is None:
            raise CertifaiException('Missing required outcome column (ground truth) in the test dataset for calculating performance metrics')
        values = generate_performance_metrics(metrics,
                                              dataset.data.values,
                                              dataset.ground_truth,
                                              model.hosted_model,
                                              favorable_values,
                                              dataset.non_model_column_indexes)
        idx = 0
        for m in metrics:
            all_values[metric_names[idx]] = values[idx]
            idx += 1
    for model_asserted_metric in model.performance_metric_values:
        if model_asserted_metric.name not in all_values:
            all_values[model_asserted_metric.name] = model_asserted_metric.value
    return all_values




### ATX Evaluation


def create_atx_report(scan, use_case, evaluation, model, reports, atx_weights):
    scan_copy = deepcopy(scan)
    scan_copy.evaluation_type = 'atx'
    log.info(f"Creating ATX report for model: {model.model_id}")

    report_failures = False
    scores = {}
    aspect_types = {}
    for r in reports:
        eval_type = r['scan']['evaluation_type']
        if eval_type == 'fairness':
            aspect_type = evaluation.primary_fairness_metric
        elif eval_type == 'performance':
            aspect_type = use_case.atx_performance_metric_name
        elif eval_type in ('explanation', 'explainability'):
            aspect_type = evaluation.primary_explanation_type
        else:
            aspect_type = ''    # encode default as empty string
        aspect_types[eval_type] = aspect_type
        if r['status'] == 'Completed' and eval_type in atx_weights:
            if eval_type == 'performance':
                score = None
                for m in r['performance_metrics']:
                    if m['name'] == use_case.atx_performance_metric_name:
                        score = m['score']
                        break
                assert score is not None
            else:
                score = r[eval_type]['score']
            scores[eval_type] = score
        elif eval_type in atx_weights:
            if atx_weights.get(eval_type) != 0: # required report failed - no score avail.
                report_failures = True

    if report_failures:
        atx_score = 0
        error = 'Individual report failures occured - cannot compute atx score'
    else:
        try:
            atx_score = compute_atx_score(scores, atx_weights)
            error = None
        except Exception as e:
            atx_score = 0
            error = str(e)

    components = sorted(list(atx_weights.keys()))
    result = OrderedDict({
        'scan': scan_copy.dump(),
        'model_use_case': use_case.dump(),
        'model':  model.dump(),
        'atx': atx_score,
        'components_measured': components,
        'component_scores': scores,
        'aspect_weights': atx_weights,
        'aspect_types': aspect_types,
        'status': 'Completed',
    })

    if error is not None:
        result['status'] = 'Failed'
        result['error'] = error

    return result
