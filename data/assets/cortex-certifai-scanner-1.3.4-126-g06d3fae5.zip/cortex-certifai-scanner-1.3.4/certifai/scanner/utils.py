"""
Scanner Utility functions.
"""
import os
import numpy as np
from certifai.common.file.locaters import make_generic_locater
from certifai.common.file import local_filesystem_type
from certifai.common.utils import get_logger

log = get_logger()


def get_file_open_function(filename, write=False, text=False):
    """
    Returns the proper function to open the file referenced by 'filename'.
    Currently supports any filesystem supported by certifai.common.file.

    :param filename:  the name of to open
    :return: function to open the file with the specified 'filename'
    """
    locater = make_generic_locater(filename)
    if write:
        return locater.text_writer if text else locater.writer
    else:
        return locater.text_reader if text else locater.reader


def create_directory_if_not_exists(output_path_locater):
    """
    Creates the directory specified by output path if it is in the local filesystem and does
    not currently exists.
    """
    if output_path_locater is not None:
        #   Auto create is only supported on the local FS
        if output_path_locater.filesystem.type_name == local_filesystem_type:
            os.makedirs(output_path_locater.name, exist_ok=True)


def retrieve_or(d, or_value, keys):
    """
    'Deep get' to retrieve value from nested dictionary specifying key path, returning or_value if
    key missing
    :param d: the dictionary
    :param or_value: What to return if key does not exist
    :param keys: array of keys in the key path, or single key
    :return: value or specified or_value
    """
    if isinstance(keys, str):
        return d.get(keys, or_value)

    if len(keys) == 0:
        return d

    first, *rest = keys
    if first not in d:
        return or_value
    v = d.get(first)
    return retrieve_or(v, or_value, rest)


def retrieve(d, keys):
    """
    'Deep get' to retrieve value from nested dictionary specifying path as ["key1", "key2", "key3"]
    :param d: the dictionary
    :param keys: array of keys in the key path, or single key
    :return: value or None if key does not exist
    """
    return retrieve_or(d, None, keys)


def convert_numpy_objects(dict_to_convert: dict, path='') -> dict:
    """Returns a copy of the given dictionary with instances of NaN, Inf, and -Inf replaced with None."""
    new = {}
    for k, v in dict_to_convert.items():
        new[k] = _convert_numpy_objects_helper(v, f"{path}/{k}")
    return new

def _convert_numpy_objects_helper(v, path):
    if isinstance(v, dict):
        return convert_numpy_objects(v, path)
    elif isinstance(v, list) or isinstance(v, np.ndarray):
        return [_convert_numpy_objects_helper(item, path) for item in v]
    elif isinstance(v, float) and (np.isnan(v) or np.isinf(v)):
        log.warning(f"{v} value was found at {path} within a report - replacing with None")
        return None
    else:
        return v

