"""
Certifai Scanner Report formatting utilities
"""
from typing import Optional, Callable, Dict

from copy import deepcopy

from collections import OrderedDict
from certifai.common.types import ModelTypeEnum, PredictionFavorabilityEnum, EvaluationTypeEnum, ScanStatusEnum
from certifai.scanner.schemas import dump_many
from certifai.engine.fairness import (feature_fairness_scores, detailed_fairness_scores, overall_fairness_score,
                                      fairness_dict)
from certifai.scanner.utils import convert_numpy_objects


def _extract_optional_field(d: dict,
                            field: str,
                            target_name: str,
                            remove_source: bool=False,
                            mapping: Optional[Callable]=None):
    result = {}
    if field in d:
        result[target_name] = d[field] if mapping is None else mapping(d[field])
        if remove_source:
            d.pop(field)
    return result


def _extract_optional_fields(d: dict,
                             field_mappings: Dict[str, str],
                             remove_source: bool=False,
                             mapping: Optional[Callable]=None):
    result = {}
    for source, target in field_mappings.items():
        result.update(_extract_optional_field(d, source, target, remove_source=remove_source, mapping=mapping))
    return result


def _format_robustness_results(report):
    return {
        'robustness': _extract_optional_fields(report['results']['scores'],
                                               {
                                                   'robustness': 'score',
                                                   'robustness_confidence_95_lower': 'score_confidence_95_lower',
                                                   'robustness_confidence_95_upper': 'score_confidence_95_upper'
                                               },
                                               remove_source=True,
                                               mapping=lambda x: x*100)
    }



def _extract_prediction_info(report):
    use_case = report['use_case']
    evaluation = report['evaluation']
    prediction_info = {
        'prediction_description' : evaluation.prediction_description,
        'prediction_favorability': evaluation.prediction_favorability
    }

    if use_case.task_type == ModelTypeEnum.regression:
        prediction_info['favorable_outcome_value'] = evaluation.favorable_outcome_value
        prediction_info['regression_standard_deviation'] = evaluation.regression_standard_deviation
    else: # binary-classification or multiclass-classification
        if use_case.task_type == ModelTypeEnum.multiclass_classification and evaluation.prediction_favorability == PredictionFavorabilityEnum.explicit:
            prediction_info['favorable_outcome_group_name'] = evaluation.favorable_outcome_group_name
            prediction_info['unfavorable_outcome_group_name'] = evaluation.unfavorable_outcome_group_name
        prediction_info['prediction_values'] = dump_many(evaluation.prediction_values)
    return prediction_info


def _format_fairness_results(report):
    def package_scores(target_d, source_d):
        target_d.update({
            'fairness_grouping_features': dump_many(report['evaluation'].fairness_grouping_features),
            'feature_fairness': feature_fairness_scores(source_d),
            'detailed_fairness': detailed_fairness_scores(source_d)
        })

        target_d.update(_extract_optional_fields(source_d,
                                                 {
                                                     'overall_fairness': 'score',
                                                     'fairness_metric': 'fairness_metric',
                                                     'overall_fairness_confidence_95_lower': 'score_confidence_95_lower',
                                                     'overall_fairness_confidence_95_upper': 'score_confidence_95_upper'
                                                 },
                                                 remove_source=True))

    res = {}
    res['feature_restrictions'] = dump_many(report['evaluation'].feature_restrictions)
    res.update(_extract_prediction_info(report))
    scores = report['results']['scores']
    res['fairness'] = {}
    package_scores(res['fairness'], scores)
    if 'secondary_scores' in report['results']:
        res['fairness']['secondary_scores'] = []
        for s in report['results']['secondary_scores'].values():
            score_result = {}
            package_scores(score_result, s)
            res['fairness']['secondary_scores'].append(score_result)

    return res

def _format_explanation_results(report):
    res = {}
    res['feature_restrictions'] = dump_many(report['evaluation'].feature_restrictions)
    res.update(_extract_prediction_info(report))
    res['explanation_types'] = report['evaluation'].explanation_types
    res['explanations'] = report['results']['counterfactuals']
    return res


def _format_explainability_results(report):
    def count_scores(score_map):
        result = deepcopy(score_map)
        for feature in result:
            feature['value'] = feature.get('score')
            feature.pop('score', None)
        return result

    def package_scores(source_d):
        result = {
            'histogram': source_d['XHistogram'],
            'score': source_d['XScore'],
            'count_scores': count_scores(source_d['XScoreMap']),
            'explanation_type': source_d['explanation_type']
        }
        return result

    res = {}
    res['feature_restrictions'] = dump_many(report['evaluation'].feature_restrictions)
    res.update(_extract_prediction_info(report))

    res['explanation_types'] = report['evaluation'].explanation_types
    res['explainability'] = package_scores(report['results']['scores'])
    if 'secondary_scores' in report['results']:
        res['explainability']['secondary_scores'] = list(map(package_scores, report['results']['secondary_scores']))

    # Remove duplicated information
    report['results']['scores'].pop('XScoreMap', None)
    report['results']['scores'].pop('explanation_type', None)
    report['results']['scores'].pop('XHistogram', None)
    report['results']['scores'].pop('XScore', None)
    return res


def _format_performance_results(report):
    performance_metrics = []
    metrics = report['results']
    for name, value in metrics.items():
        performance_metrics.append({
            'name': name,
            'value': value,
            'score': value * 100,
        })
    return { 'performance_metrics': performance_metrics }


def _format_report(report, details=False):
    result = OrderedDict({})

    result['scan'] = report['scan'].dump()
    result['model_use_case'] = report['use_case'].dump()
    result['model'] = report['model'].dump()

    if 'dataset' in report and report['dataset'] is not None:
        result['dataset'] = report['dataset'].dump()

        if report['analysis_type'] != EvaluationTypeEnum.performance:
            result['dataset_schema'] = report['dataset_schema'].dump()
            result['dataset_schema']['feature_schemas'] = report['dataset_features']

    if 'model_features' in report:
        result['model_schema'] = {
            'feature_schemas': report['model_features']
        }

    result['status'] = report['status']
    if report['status'] == 'Completed':
        if 'stats' in report['results']:
            result['engine_stats'] = report['results']['stats']

        if 'scores' in report['results']:
            result['detailed_scores'] = report['results']['scores']

        formatters = {
            EvaluationTypeEnum.robustness: _format_robustness_results,
            EvaluationTypeEnum.fairness: _format_fairness_results,
            EvaluationTypeEnum.explanation: _format_explanation_results,
            EvaluationTypeEnum.explainability: _format_explainability_results,
            EvaluationTypeEnum.performance: _format_performance_results,
        }
        analysis_type = report['analysis_type']
        formatted_engine_results = formatters[analysis_type](report)
        if details:
            formatted_engine_results['details'] = {
                'scores': report['results'].get('scores'),
                'counterfactuals': report['results'].get('counterfactuals'),
                'metadata': report['results'].get('metadata'),
            }
        result.update(formatted_engine_results)
    else:
        result['error'] = report['error']

    return result


def _get_base_report(ctx, model, dataset, eval_type) -> dict:
    # Only using deepcopy for the scan object because we are going to be modifying the start/end times
    # Want to avoid using deepcopy on the entire report though (specifically having multiple copies of the dataset)
    report = {
        'scan': deepcopy(ctx.scan),
        'model': model,
        'dataset': dataset,
        'dataset_features': ctx.dataset_features,
        'use_case': ctx.use_case,
        'evaluation': ctx.evaluation,
        'analysis_type': eval_type,
        'dataset_schema': ctx.dataset_schema
    }
    return report

def _set_results(base_report, engine_result):
    base_report['scan'].started = engine_result.started
    base_report['scan'].ended = engine_result.ended
    base_report['scan'].evaluation_type = engine_result.eval_type.value
    base_report['status'] = engine_result.status
    if engine_result.status == ScanStatusEnum.completed:
        base_report['results'] = engine_result.data
    else:
        base_report['error'] = engine_result.error # failed


def format_report(ctx, model, results, details=False):
    if results.eval_type == EvaluationTypeEnum.explanation:
        dataset = ctx.expl_dataset
    elif results.eval_type == EvaluationTypeEnum.performance:
        dataset = ctx.test_dataset
    else:
        dataset = ctx.eval_dataset # fairness, robustness, or explainability

    base_report = _get_base_report(ctx, model, dataset, results.eval_type)

    if results.eval_type == EvaluationTypeEnum.explanation:
        # Include the model level feature schema only if counterfactuals are provided (since this is the feature
        # schema they adhere to)
        base_report['model_features'] = ctx.model_features

    _set_results(base_report, results)
    return convert_numpy_objects(_format_report(base_report, details))
