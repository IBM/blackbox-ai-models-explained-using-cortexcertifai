import json
from copy import deepcopy
from collections import UserDict
from dataclasses import dataclass, field
from typing import Callable, Optional, List, Set, Tuple, Dict

from certifai.common.file.interface import FSLocater, get_basename
from certifai.common.file.locaters import make_generic_locater
from certifai.common.utils import get_logger
from certifai.common.utils.utils import to_filename_safe_chars
from certifai.common.utils.name_utils import NameCreator, ShorteningResolver, IncrementalUUIDResolver, CompositeResolver
from certifai.common.progress_task import AbstractTask, ProgressUpdate, ProgressListener

from certifai.engine.utils.numpy_json_encoder import NumpyJSONEncoder

log = get_logger()


# By subclassing UserDict this class acts as a dictionary but it is really a wrapper around a
# dictionary stored in the `data` field. The downside of subclassing UserDict, is that this class
# isn't really a dictionary, e.g. `isinstance(PreflightReport(...), dict)` is False
class PreflightReport(UserDict):
    """
    A dictionary-like object that can be saved/loaded from a file.
    """

    def __init__(self, locater: FSLocater):
        """

        :param FSLocater locater: locater object for the file meant to persist the preflight report
        """
        super().__init__()
        self._locater = locater
        self.load()

    @property
    def model_id(self) -> Optional[str]:
        return self.get('model', {}).get('model_id')

    @property
    def model_use_case_id(self) -> Optional[str]:
        return self.get('model_use_case', {}).get('model_use_case_id')

    def load(self):
        """Loads the data from the preflight report's file (if it exists) and resets the instances data."""
        try:
            log.info(f"attempting to load preflight file '{self._locater.name}'")
            with self._locater.text_reader() as stream:
                self.data = json.load(stream)
                log.info(f"Successfully loaded existing preflight file")
        except FileNotFoundError as fe:
            log.info(f"Existing preflight file not found ({str(fe)}) - using empty data source")
            self.data = {}

    def save(self):
        """Writes the contents of this object to its backing file as JSON."""
        try:
            with self._locater.text_writer() as outfile:
                json.dump(self.data, outfile, ensure_ascii=False, indent=4, sort_keys=False, cls=NumpyJSONEncoder)
        except Exception as e:
            log.exception(f"Unable to write preflight file {str(e)}", exc_info=True)

    @staticmethod
    def from_filepath(filepath: str) -> 'PreflightReport':
        return PreflightReport(make_generic_locater(filepath))



def get_preflight_report_for_model(report_directory: str, muc_id: str, model_id: str) -> PreflightReport:
    """
    Retrieve a PreflightReport for the specified model in the given output location. If there is not
    an existing PreflightReport file for the model, a new one will be created.

    :param str report_directory: directory for to search for existing preflight reports
    :param str muc_id: model use case id
    :param str model_id: model id
    :return: A PreflightReport object for the given model
    """
    dir_locater = make_generic_locater(report_directory)
    preflight_files = set(list_existing_preflight_files(dir_locater))

    model_report = None
    possible_matches = _find_possible_matches(preflight_files, model_id)
    for f in possible_matches:
        report = PreflightReport(dir_locater.join(f))
        if report.model_id == model_id and report.model_use_case_id == muc_id:
            model_report = report
            break

    if model_report is None:
        filename = preflight_filename(muc_id, model_id, preflight_files)
        model_report = PreflightReport(dir_locater.join(filename))
        model_report['model'] = {'model_id': model_id}
        model_report['model_use_case'] = {'model_use_case_id': muc_id}
    return model_report

def _find_possible_matches(filenames: Set[str], model_id: str) -> List[str]:
    """Compute a list of possible preflight reports that could belong the given model_id"""
    # The model id abbrevation in the preflight report file name will be some substring of the
    # actual model id (possibly w/ noise). So, the current strategy is to sort the list of model
    # id's based on number of matching characters with the given model_id and filter based on some
    # minimum (in this case 1 to be conservative).
    def _score(model_id_abbrev, model_id):
        num_matching_chars = 0
        for i in range(min(len(model_id_abbrev), len(model_id))):
            if model_id_abbrev[i] == model_id[i]:
                num_matching_chars += 1
            else:
                break
        return num_matching_chars

    scores = {} # filename -> score
    for f in filenames:
        _, _, _, model_id_abbrev = f.split('.')[0].split('-')
        scores[f] = _score(model_id_abbrev, model_id)
    possible = sorted(filter(lambda f: scores[f] >= 1, filenames), key=lambda f: scores[f], reverse=True)
    return possible

def list_existing_preflight_files(dir_locater: FSLocater) -> List[str]:
    """
    Returns a list of existing preflight files in the given directory.
    :param FSLocater dir_locater: locater object for the directory to search
    :return: a list of existing preflight report files
    """
    def _is_preflight_file(filename: str) -> bool:
        return filename.startswith('certifai-preflight-') and filename.endswith('.json')

    try:
        preflight_files = [get_basename(f) for f in dir_locater.file_lister() if _is_preflight_file(get_basename(f))]
    except FileNotFoundError:
        preflight_files = []

    if len(preflight_files) == 0:
        log.info(f"No existing preflight files founds")

    return preflight_files

# The PrelfightReport naming strategy is: `certifai-preflight-<muc_id>-<model_id>.json` where the
# muc_id and model_id are abbreviated/modified versions of the model_use_case_id and model_id
# respectively.
def preflight_filename(muc_id: str, model_id: str, filenames: Set[str]) -> str:
    """
    Creates a new preflight report filename for the given model id. The set of existing preflight
    filenames is used to avoid possible filename collisions.

    :param str muc_id: model use case id
    :param str model_id: model id
    :param Set[str] filenames: set of existng preflight report filename
    :return: a distinct preflight report filename
    """
    stripped_filenames = set(f.split('.')[0] for f in filenames) # remove .json extension
    resolver = NameCreator(CompositeResolver([ShorteningResolver(10), IncrementalUUIDResolver(10, 5)]), stripped_filenames)

    # to_filename_safe_chars will only keep alphanumeric chars and '-' and '_' by default, but dashes
    # in the muc_id will cause issues when parsing filenames, so replace '-' with '_'
    modified_muc_id = to_filename_safe_chars(muc_id, map_to_underscore=('/', '\\', '-'), max_len=30)
    filename = f"certifai-preflight-{modified_muc_id}-{model_id}"
    return resolver.create(filename, length_limit=80) + '.json'



@dataclass
class PreflightResult:
    """The result of a preflight check. Results can be composed together."""
    warnings: List[str] = field(default_factory=list)
    messages: List[str] = field(default_factory=list)
    errors: Optional[List[str]] = None

    def compose(self, other: 'PreflightResult') -> 'PreflightResult':
        return PreflightResult(self.warnings + other.warnings,
                               self.messages + other.messages,
                               (self.errors if self.errors is not None else []) + (other.errors if other.errors is not None else []))

    def as_dict(self) -> Dict[str, List[str]]:
        return {
            'warnings': list(self.warnings),
            'messages': list(self.messages),
            'errors': list(self.errors),
        }

    @staticmethod
    def empty() -> 'PreflightResult':
        return PreflightResult()


# A preflight check is a function that accepts a dictionary (a section of the PreflightReport) and
# produces a Tuple with a dictionary (the updated section of the PreflightReport) and the result of
# the check.
PreflightCheck = Callable[[dict], Tuple[Optional[dict], Optional[PreflightResult]]]

class PreflightChecker(AbstractTask):
    """
    A wrapper around multiple individual preflight checks that will be executed serially.

    Each preflight check will be given a section of the PreflightReport based on its name.
    """

    def __init__(self,
                 report: PreflightReport,
                 checks: Optional[List[PreflightCheck]] = None,
                 keys: Optional[List[str]] = None,
                 names: Optional[List[str]] = None):
        """

        :param PreflightReport report: Preflight Report object to be used for check
        :param Optional[List[PreflightCheck]] checks: starting list of preflight checks
        :param Optional[List[str]] keys: optional list of keys for each given preflight check. The key is used as a
                namespace for persisting data within the preflight report
        :param Optional[List[str]] names: optional list of user facing names for each preflight checks
        """
        self._report = report
        self._checks = list(checks) if checks is not None else []
        self._keys = list(keys) if keys is not None else []
        self._names = list(names) if names is not None else []
        self._num_completed_checks = 0
        self._listeners = []

        if len(self._checks) != len(self._keys):
            raise ValueError("Mismatch between the number of preflight checks and keys given")

        while len(self._names) < len(self._checks):
            self._names.append(self._preflight_name(len(self._names)))

    def _preflight_name(self, index: int):
        return f"check-{index}"

    @property
    def num_checks(self) -> int:
        return len(self._checks)

    def _alert_listeners(self, update: ProgressUpdate):
        for listener in self._listeners:
            listener(update)

        if len(self._listeners) == 0:
            log.details(update.summary)

    def add_check(self, check: PreflightCheck, key: str, name: Optional[str] = None):
        """
        Adds a preflight check function.
        :param PreflightCheck check: check to be add
        :param str key: string key used to be used as a namespace for the check within the preflight report
        :param Optional[str] name: optional name of the check function
        """
        self._checks.append(check)
        self._keys.append(key)
        self._names.append(name if name is not None else self._preflight_name(len(self._checks)))

    def run(self, callback: ProgressListener) -> PreflightResult:
        """
        Executes all registered check functions serially.
        :return: a PreflightResult object
        """
        if callback is not None:
            self._listeners.append(callback)

        result = PreflightResult()
        self._num_completed_checks = 0
        for check, key, name in zip(self._checks, self._keys, self._names):
            try:
                log.debug(f"Exexcuting '{name}' preflight check")
                self._alert_listeners(ProgressUpdate(self._num_completed_checks, self.num_checks,
                                                     f"Running {name} preflight check for model {self._report.model_id}"))

                section = deepcopy(self._report.get(key, {}))
                updated_section, res = check(section)
                if updated_section is not None:
                    self._report[key] = updated_section
                result = result.compose(res or PreflightResult.empty())
            except Exception as e:
                log.exception(f"Failure during {name} preflight check")
                result = result.compose(PreflightResult(errors=[f"Unexpected exception during {name} preflight check - {str(e)}"]))
            self._num_completed_checks += 1

        self._alert_listeners(ProgressUpdate(self.num_checks, self.num_checks,
                                             f"Finished all preflight checks for model {self._report.model_id}"))
        return result

    def attach(self, callback: ProgressListener):
        if callback is not None:
            self._listeners.append(callback)

    def estimate(self) -> int:
        return self.num_checks - self._num_completed_checks
