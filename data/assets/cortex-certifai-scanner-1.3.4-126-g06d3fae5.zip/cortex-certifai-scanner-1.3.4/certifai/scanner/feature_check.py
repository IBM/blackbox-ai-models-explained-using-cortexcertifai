from certifai.common.feature_check import *


FEATURES = {
    'multiclass': Feature('multiclass_classification', 'scanner', 'support_multiclass_beta', False),
    'alternate_fairness': Feature('Alternate fairness metrics', 'scanner', 'support_alternate_fairness_beta', False),
    'alternate_explanations': Feature('Alternate explanation types', 'scanner', 'support_alternate_explanations_beta', False),
    'multiple_explanation_types': Feature('Multiple explanation types', 'scanner', 'support_multiple_explanation_types_beta', False)
}

register_features(FEATURES)
