from typing import Dict
from certifai.common.types import EvaluationTypeEnum
from certifai.scanner.types import ScanContext, ScanTimeEstimator
from certifai.scanner.preflight import PreflightReport
from certifai.scanner.preflight_checks.scan_time_estimate import ScanTimeEstimateCheck
from certifai.common.errors import CertifaiTimeEstimateException

class PreflightTimeEstimator(ScanTimeEstimator):
    """Object for producing time estimates for a Scan using persisted data from preflight reports"""

    def __init__(self, context: ScanContext, preflights: Dict[str, PreflightReport]):
        """
        :param ScanContext context: context for the current scan
        :param Dict[str, PrelfightReport] preflights: a dictionary of preflight reports keyed on model id
        """
        self._ctx = context
        self._preflights = preflights

    def total_in_seconds(self) -> int:
        total = 0
        for m in self._ctx.models:
            preflight = self._preflights.get(m.model_id)
            if preflight is None:
                raise CertifaiTimeEstimateException(f"Unable to offer total time estimate because model {m.model_id} is missing preflight data")

            saved_data = preflight.get(ScanTimeEstimateCheck.KEY)
            if saved_data is None:
                raise CertifaiTimeEstimateException(f"Unable to offer total time estimate because model {m.model_id} is missing preflight data")

            estimator = ScanTimeEstimateCheck(self._ctx, m)
            for e in self._ctx.evaluation.evaluation_types:
                estimate = estimator.estimate_from_saved(saved_data, e)
                if estimate is None:
                    raise CertifaiTimeEstimateException(f"Unable to offer total time estimate, missing estimate for {e} evaluation of model {m.model_id}")
                total += estimate
        return int(round(total))

    def total_in_minutes(self) -> int:
        return (self.total_in_seconds() - 1) // 60 + 1  # plus one to ceil estimate

    def time_for_evaluation(self, model_id: str, eval_type: EvaluationTypeEnum) -> int:
        preflight = self._preflights.get(model_id)
        if preflight is None:
            raise CertifaiTimeEstimateException(f"Unable to offer time estimate for {eval_type} evaluation because model {model_id} is missing preflight data")

        saved_data = preflight.get(ScanTimeEstimateCheck.KEY)
        if saved_data is None:
            raise CertifaiTimeEstimateException(f"Unable to offer time estimate for {eval_type} evaluation because model {model_id} is missing preflight data")

        try:
            model = next(m for m in self._ctx.models if m.model_id == model_id)
        except StopIteration:
            raise CertifaiTimeEstimateException(f"Unable to offer time estimate for {eval_type} evaluation because model {model_id} is not in the given scan context")

        estimator = ScanTimeEstimateCheck(self._ctx, model)
        estimate = estimator.estimate_from_saved(saved_data, eval_type)
        if estimate is None:
            raise CertifaiTimeEstimateException(f"Unable to offer time estimate for model {model_id}, {eval_type} evaluation")
        return int(round(estimate))
