"""Common utilities for preflight checks"""
import numpy as np
import pandas as pd
from certifai.scanner.schemas import Dataset

SAMPLE_SIZE = 50
def sample_dataset(ds: Dataset, sample_size: int = SAMPLE_SIZE) -> np.ndarray:
    if not isinstance(ds.data, pd.DataFrame):
        df = pd.DataFrame(ds.data)
    else:
        df = ds.data
    return df.sample(n=min(sample_size, df.shape[0])).values
