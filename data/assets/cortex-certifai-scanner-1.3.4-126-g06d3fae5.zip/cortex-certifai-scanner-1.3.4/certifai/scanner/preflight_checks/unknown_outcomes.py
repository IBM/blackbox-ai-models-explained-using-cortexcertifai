from typing import Tuple, Optional, List
from certifai.common.errors import CertifaiException
from certifai.common.types import ModelTypeEnum
from certifai.common.model_utils import FeatureDrop

from certifai.scanner.types import ScanContext
from certifai.scanner.schemas import Model
from certifai.scanner.preflight import PreflightResult

from certifai.scanner.preflight_checks.utils import sample_dataset

class UnknownOutcomeClassCheck:
    """
    Preflight check to verify that a given model's predictions match the expected classes defined - only applicable
    for classification task types.
    """
    KEY = 'unknown_outcome_class'
    NAME = 'unknown outcome class'

    def __init__(self, context: ScanContext, model: Model):
        self._ctx = context
        self._model = model

    def __call__(self, data: dict) -> Tuple[Optional[dict], Optional[PreflightResult]]:
        datasets = filter(lambda ds: ds is not None,
                          [self._ctx.eval_dataset, self._ctx.expl_dataset, self._ctx.test_dataset])

        messages, warnings, errors = [], [], []
        if self._ctx.use_case.task_type in (ModelTypeEnum.multiclass_classification, ModelTypeEnum.binary_classification):
            expected_outcomes = set(p.value for p in self._ctx.evaluation.prediction_values)
            for ds in datasets:
                # TODO(la): This check isn't really related to the models - so maybe it should belong somewhere else
                if ds.ground_truth is not None:
                    outcomes_in_dataset = set(ds.ground_truth)

                    # warn for outcomes in the dataset that aren't specified in the scan def
                    unknown_outcomes = outcomes_in_dataset.difference(expected_outcomes)
                    if len(unknown_outcomes) > 0:
                        values = ','.join(map(str, unknown_outcomes))
                        warnings.append(f"Value(s) '{values}' in outcome column of '{ds.dataset_id}' dataset do not match " \
                                        f"possible outcome values specified in the scan definition")

                    # warn for outcomes in the scan def that aren't in the dataset (non-representative dataset)
                    missing_outcomes = expected_outcomes.difference(outcomes_in_dataset)
                    if len(missing_outcomes) > 0:
                        values = ','.join(map(str, missing_outcomes))
                        warnings.append(f"Possible outcome value(s) '{values}' specified in the scan definition are not in the " \
                                        f"outcome column of the '{ds.dataset_id}' dataset. This may affect the quality of results " \
                                        f"produced by Certifai")

                # need to drop features not exposed to the model before calling predict
                hosted_model = self._model.hosted_model
                if len(ds.non_model_column_indexes) > 0:
                    hosted_model = hosted_model.contramap(FeatureDrop(ds.non_model_column_indexes,
                                                                      len(self._ctx.model_features)))

                sample = sample_dataset(ds)
                predictions = hosted_model.predict(sample, retries=0) # no retries
                unknown_outcomes = set(predictions).difference(expected_outcomes)
                if len(unknown_outcomes):
                    values = ','.join(map(str, unknown_outcomes))
                    errors.append(f"Prediction value(s) '{values}' returned by '{self._model.model_id}' model " \
                                    f"against a sample of the '{ds.dataset_id}' dataset do not match possible " \
                                    f"outcome values specified the scan definition")

        if len(warnings) == 0 and len(errors) == 0:
            messages.append(f"Passed unknown outcome classes check")
        return None, PreflightResult(warnings, messages, errors)
