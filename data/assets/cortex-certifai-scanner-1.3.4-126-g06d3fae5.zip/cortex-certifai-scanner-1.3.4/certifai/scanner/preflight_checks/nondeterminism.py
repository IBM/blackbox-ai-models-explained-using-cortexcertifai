from typing import Tuple, Optional, List
from certifai.common.errors import CertifaiException

from certifai.scanner.types import ScanContext
from certifai.scanner.schemas import Model
from certifai.scanner.preflight import PreflightResult

from certifai.scanner.preflight_checks.utils import SAMPLE_SIZE

from certifai.common.utils import get_logger, get_config


log = get_logger()


class DeterministicModelCheck:
    """Preflight check to verify that a given model is deterministic (i.e. makes consistent predictions)."""
    KEY = 'model_nondeterminism'
    NAME = 'model nondeterminism'

    def __init__(self, context: ScanContext, model: Model):
        self._ctx = context
        self._model = model

    def __call__(self, data: dict) -> Tuple[Optional[dict], Optional[PreflightResult]]:
        messages, warnings, errors = [], [], []
        datasets = filter(lambda ds: ds is not None,
                          [self._ctx.eval_dataset, self._ctx.expl_dataset, self._ctx.test_dataset])

        for ds in datasets:
            try:
                from certifai.scanner.tester.definition_test import sample_model_against_dataset
                sample_model_against_dataset(self._model, ds, self._ctx.model_features, sample_size=SAMPLE_SIZE, round_decimals=5)
            except CertifaiException:
                # a CertifaiException will be raised if the results of batch prediction differ from the results
                # of individual predictions. This is effectively checking that the model is deterministic.
                warnings.append(f"Model {self._model.model_id} was found to be non-deterministic against a sample of the {ds.dataset_id} dataset")
            except Exception as e:
                log.exception(str(e))
                errors.append(f"Unexpected exception while testing {self._model.model_id} model against {ds.dataset_id} dataset - {str(e)}")

        if len(warnings) == 0 and len(errors) == 0:
            messages.append(f"Passed model non determinism check")
        return None, PreflightResult(warnings, messages, errors)
