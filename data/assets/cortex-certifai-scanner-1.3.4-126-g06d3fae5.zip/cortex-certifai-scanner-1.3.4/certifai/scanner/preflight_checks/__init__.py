"""Preflight Checks"""
from typing import Dict
from certifai.scanner.types import ScanContext, ScanTimeEstimator
from certifai.scanner.schemas import Model

from certifai.scanner.preflight import PreflightChecker, PreflightResult, PreflightReport
from certifai.scanner.preflight_checks.nondeterminism import DeterministicModelCheck
from certifai.scanner.preflight_checks.unknown_outcomes import UnknownOutcomeClassCheck
from certifai.scanner.preflight_checks.fairness_class_samples import FairnessClassSamplesCheck
from certifai.scanner.preflight_checks.scan_time_estimate import ScanTimeEstimateCheck
from certifai.scanner.preflight_checks.time_estimator import PreflightTimeEstimator
from certifai.common.types import EvaluationTypeEnum


def get_recommended_checker(context: ScanContext, model: Model, r: PreflightReport) -> PreflightChecker:
    """Returns a PrelfightChecker with recommended checks and the PreflightReport for the specified model."""
    checker = PreflightChecker(r)
    checker.add_check(DeterministicModelCheck(context, model), DeterministicModelCheck.KEY, DeterministicModelCheck.NAME)
    checker.add_check(UnknownOutcomeClassCheck(context, model), UnknownOutcomeClassCheck.KEY, UnknownOutcomeClassCheck.NAME)
    checker.add_check(ScanTimeEstimateCheck(context, model), ScanTimeEstimateCheck.KEY, ScanTimeEstimateCheck.NAME)

    # Checks that only apply to fairness
    if EvaluationTypeEnum.fairness in context.evaluation.evaluation_types:
        checker.add_check(FairnessClassSamplesCheck(context), FairnessClassSamplesCheck.KEY, FairnessClassSamplesCheck.NAME)

    return checker


def get_preflight_time_estimator(context: ScanContext, preflights: Dict[str, PreflightReport]) -> ScanTimeEstimator:
    """
    Returns a ScanTimeEstimator for the given the scan context initialized with the existing preflight data.
    """
    return PreflightTimeEstimator(context, preflights)
