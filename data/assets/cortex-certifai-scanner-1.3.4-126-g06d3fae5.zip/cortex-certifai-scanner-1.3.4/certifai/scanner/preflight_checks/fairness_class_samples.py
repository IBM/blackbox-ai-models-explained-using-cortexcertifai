from typing import Tuple, Optional, List

import numpy as np

from certifai.scanner.types import ScanContext
from certifai.scanner.options import get_fairness_options
from certifai.scanner.preflight import PreflightResult


WARN_SAMPLE_SIZE = 100


class FairnessClassSamplesCheck:
    """Preflight check to verify that adequate samples of all protected fairness classes exist."""
    KEY = 'fairness_class_samples'
    NAME = 'fairness class samples'

    def __init__(self, context: ScanContext):
        self._ctx = context

    def __call__(self, data: dict) -> Tuple[Optional[dict], Optional[PreflightResult]]:
        messages, warnings, errors = [], [], []

        # Fairness only runs against the eval dataset
        data = self._ctx.eval_dataset.data

        options = get_fairness_options(self._ctx.use_case, self._ctx.evaluation, self._ctx.model_features)
        protected_attr = options['protected_attr']

        for attr in [self._ctx.model_features[idx]['name'] for idx in protected_attr.keys()]:
            counts = data.groupby(attr).count().values[:, 0]
            min_arg = np.argmin(counts)
            min_count = counts[min_arg]
            if min_count < WARN_SAMPLE_SIZE:
                warnings.append(f"Fairness grouping attribute '{attr}' has small sample size for some values (smallest '{data[attr][min_arg]}' with {min_count} examples)")

        if len(warnings) == 0 and len(errors) == 0:
            messages.append(f"Passed fairness class samples check")
        return None, PreflightResult(warnings, messages, errors)
