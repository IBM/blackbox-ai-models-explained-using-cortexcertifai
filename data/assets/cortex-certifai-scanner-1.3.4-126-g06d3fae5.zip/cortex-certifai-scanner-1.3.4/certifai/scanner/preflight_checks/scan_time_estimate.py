from typing import Tuple, Optional

from certifai.engine.engine_api_types import EnginePreflightStatistics

from certifai.common.types import EvaluationTypeEnum
from certifai.scanner.types import ScanContext
from certifai.scanner.schemas import Model
from certifai.scanner.preflight import PreflightResult
from certifai.scanner.evaluation import ScanEvaluator

from certifai.common.utils import get_logger, get_config


log = get_logger()

# Account a constant amount of time for miscellanious overheads not related to running the GA
# or model predicts
MIN_ESTIMATE = 10
# Explainability is super-easy to converge and almost always does so in the initial min run
# of 128 rows
ASSUMED_EXPLAINABILITY_ROWS = 128
# If dimensionality reduction needs to be run that will add a fixed overhead which is very hard
# to estimate, so just using 5 minutes which is the same order as it seems to take for HSBC data
FEATURE_REDUCTION_OVERHEAD = 300


class _MessageAggregator:
    def __init__(self):
        self.messages = []
        self.warnings = []
        self.errors = []

    def message(self, s: str):
        self.messages.append(s)

    def warning(self, s: str):
        self.warnings.append(s)

    def error(self, s: str):
        self.errors.append(s)


class ScanTimeEstimateCheck:
    """Preflight check to estimate likely time to run a full scan."""
    KEY = 'scan_time_estimate'
    NAME = 'scan time estimate'

    def __init__(self, context: ScanContext, model: Model):
        self._ctx = context
        self._model = model
        self._estimators = {
            EvaluationTypeEnum.performance: self.performance_estimator,
            EvaluationTypeEnum.robustness: self.robustness_estimator,
            EvaluationTypeEnum.fairness: self.fairness_estimator,
            EvaluationTypeEnum.explanation: self.explanation_estimator,
            EvaluationTypeEnum.explainability: self.explainability_estimator
        }

    def __call__(self, data: dict) -> Tuple[Optional[dict], Optional[PreflightResult]]:
        results = _MessageAggregator()

        log.debug(f"Previously persisted data: {data}")

        # Run a preflight scan on the eval dataset to get base statistics from which to compute the full results
        evaluator = ScanEvaluator(self._ctx)
        engine_results = evaluator.preflight_evaluation(self._model)
        stats = engine_results['preflight_stats']

        persisted_result = stats._asdict()

        for eval_type in self._ctx.evaluation.evaluation_types:
            if eval_type in self._estimators:
                self._estimators[eval_type](stats, aggregate_to=results)

        if stats.error_rate > 0.:
            results.warning(f"{int(stats.error_rate*100)}% of rows had errors during counterfactual generation")

        if stats.requires_feature_reduction:
            results.message("Use case data is high dimensional and will use feature reduction")

        if len(results.warnings) == 0 and len(results.errors) == 0:
            results.message(f"Model {self._model.model_id} passed time estimation check")


        return persisted_result, PreflightResult(results.warnings, results.messages, results.errors)

    def estimate_from_saved(self,
                            saved_data: dict,
                            analysis: EvaluationTypeEnum) -> Optional[float]:
        """Estimate time in seconds to run a specified analysis in the current context, given
           previously saved preflight data"""
        stats = EnginePreflightStatistics(**saved_data)
        return self._estimators[analysis](stats)

    def performance_estimator(self,
                              stats: EnginePreflightStatistics,
                              aggregate_to: _MessageAggregator=_MessageAggregator()) -> Optional[float]:
        t = None
        if self._ctx.test_dataset is None:
            # if there is an asserted performance metric value for every metrics, return the min estimate
            if len(self._model.performance_metric_values) == len(self._ctx.use_case.performance_metrics):
                t = MIN_ESTIMATE
            else:
                aggregate_to.error("No test dataset provided for performance analysis")
        else:
            # Model performance just involves one call to the model per row
            rows = len(self._ctx.test_dataset.data)
            t = (rows/max(stats.mean_batch_size, 1))*stats.estimated_batch_predict_time + MIN_ESTIMATE

            aggregate_to.message(f"Expected time for performance analysis is {round(t)} seconds")
        return t

    def robustness_estimator(self,
                             stats: EnginePreflightStatistics,
                             aggregate_to: _MessageAggregator=_MessageAggregator()) -> Optional[float]:
        t = None
        if self._ctx.eval_dataset is None:
            aggregate_to.error("No evaluation dataset provided for robustness analysis")
        else:
            rows = len(self._ctx.eval_dataset.data)
            rows_required = min(rows, stats.estimated_robustness_rows)
            t = rows_required*stats.estimated_row_time + MIN_ESTIMATE
            if stats.requires_feature_reduction:
                t += FEATURE_REDUCTION_OVERHEAD

            aggregate_to.message(f"Expected time for robustness analysis is {round(t)} seconds")
        return t

    def fairness_estimator(self,
                           stats: EnginePreflightStatistics,
                           aggregate_to: _MessageAggregator=_MessageAggregator()) -> Optional[float]:
        t = None
        if self._ctx.eval_dataset is None:
            aggregate_to.error("No evaluation dataset provided for fairness analysis")
        else:
            if stats.estimated_fairness_rows < 0:
                aggregate_to.warning("No fairness protected class information available from preflight analysis")
            else:
                rows = len(self._ctx.eval_dataset.data)
                rows_required = min(rows, stats.estimated_fairness_rows)
                t = rows_required*stats.estimated_row_time + MIN_ESTIMATE
                if stats.requires_feature_reduction:
                    t += FEATURE_REDUCTION_OVERHEAD

                aggregate_to.message(f"Expected time for fairness analysis is {round(t)} seconds")
        return t

    def explanation_estimator(self,
                              stats: EnginePreflightStatistics,
                              aggregate_to: _MessageAggregator=_MessageAggregator()) -> Optional[float]:
        t = None
        if self._ctx.expl_dataset is None:
            aggregate_to.error("No explanation dataset provided for explanation analysis")
        else:
            rows = len(self._ctx.expl_dataset.data)
            t = rows*stats.estimated_row_time + MIN_ESTIMATE
            if stats.requires_feature_reduction:
                t += FEATURE_REDUCTION_OVERHEAD

            if stats.no_cf_rate >= 0.01:
                aggregate_to.warning(f"No counterfactual explanation can be found approximately {int(stats.no_cf_rate*100)}% of rows")

            aggregate_to.message(f"Expected time for explanation analysis is {round(t)} seconds")
        return t

    def explainability_estimator(self,
                                 stats: EnginePreflightStatistics,
                                 aggregate_to: _MessageAggregator=_MessageAggregator()) -> Optional[float]:
        t = None
        if self._ctx.eval_dataset is None:
            aggregate_to.error("No evaluation dataset provided for explainability analysis")
        else:
            rows = len(self._ctx.eval_dataset.data)
            rows_required = min(rows, ASSUMED_EXPLAINABILITY_ROWS)
            t = rows_required*stats.estimated_row_time + MIN_ESTIMATE
            if stats.requires_feature_reduction:
                t += FEATURE_REDUCTION_OVERHEAD

            aggregate_to.message(f"Expected time for explainability analysis is {round(t)} seconds")
        return t
