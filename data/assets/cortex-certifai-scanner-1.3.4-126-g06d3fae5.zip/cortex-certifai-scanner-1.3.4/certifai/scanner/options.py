"""
Certifai option utility functions
"""

import numpy as np
from typing import Optional, Set, Any
import collections
from certifai.common.utils import get_logger
from certifai.common.errors import CertifaiException
from certifai.common.types import FeatureTypeEnum, RestrictionStringEnum, ModelTypeEnum, RegressionBoundaryTypeEnum
from certifai.common.types import EvaluationTypeEnum, PredictionFavorabilityEnum
from certifai.engine.engine_api_types import ClassStructure
from certifai.engine.fairness import Bucketer
from certifai.engine.options import get_cfi_options
from certifai.common.utils.fn_utils import fmap_opt


log = get_logger()


def get_option_feature_bounds(feature_restrictions, features):
    """
    Creates certifai option feature bounds from the feature_restrictions.
    @return Sample: {'BMI': {'type': 'percentage', 'percent': 0.3}, 'Glucose': {'type': 'minmax', 'min': 70, 'max': 150}}
    """
    def feature_type(restriction):
        for feature in features:
            if feature['name'] == restriction.feature_name:
                return feature['type']
        raise ValueError(f"Unknown feature '{restriction.feature_name}' in feature restrictions")

    def validate_numeric(feature_type: FeatureTypeEnum, name: str):
        if feature_type not in (FeatureTypeEnum.INT, FeatureTypeEnum.FLOAT):
            raise CertifaiException(f"Feature restriction specified for '{name}' can only be applied to numeric features")

    feature_bounds = {}
    for restrictions in feature_restrictions:
        restriction_string = restrictions.restriction_string
        ft = feature_type(restrictions)
        if restriction_string == RestrictionStringEnum.no_changes:
            feature_bounds[restrictions.feature_name] = {
                'type': 'constant'
            }
        elif restriction_string == RestrictionStringEnum.percentage:
            validate_numeric(ft, restrictions.feature_name)
            feature_bounds[restrictions.feature_name] = {
                'type': 'percentage',
                'percent': np.float64(restrictions.restriction_numerical_percentage)
            }
        elif restriction_string == RestrictionStringEnum.min_max:
            validate_numeric(ft, restrictions.feature_name)
            convert = np.int64 if ft == FeatureTypeEnum.INT else np.float64
            feature_bounds[restrictions.feature_name] = {
                'type': 'minmax',
                'min': convert(restrictions.restriction_numerical_min),
                'max': convert(restrictions.restriction_numerical_max),
            }

    return feature_bounds if len(feature_bounds) > 0 else None


def get_favorable_outcome_value(use_case, evaluation) -> Optional[Set[Any]]:
    """Finds the favorable outcome value(s) for the given use_case and evalutaion definition."""
    def _multiclass_outcome(evaluation):
        if evaluation.prediction_favorability == PredictionFavorabilityEnum.none:
            return None
        elif evaluation.prediction_favorability == PredictionFavorabilityEnum.ordered:
            result = []
            for p in evaluation.prediction_values:
                result.append(p.value)
                if (evaluation.last_favorable_prediction is None) or (evaluation.last_favorable_prediction == p.value):
                    break
            return result
        else: # explicit
            return [p.value for p in evaluation.prediction_values if p.favorable]

    def _binaryclass_outcome(evaluation):
        return _multiclass_outcome(evaluation)

    def _regression_outcome(evaluation):
        if evaluation.prediction_favorability == PredictionFavorabilityEnum.none:
            return None
        return [evaluation.favorable_outcome_value]

    task_type_map = {
        ModelTypeEnum.binary_classification: _binaryclass_outcome,
        ModelTypeEnum.multiclass_classification: _multiclass_outcome,
        ModelTypeEnum.regression: _regression_outcome,
    }
    return fmap_opt(frozenset, task_type_map[use_case.task_type](evaluation))


def get_fairness_options(use_case, evaluation, features):
    """Creates the fairness options for the specified evaluation and features."""
    if EvaluationTypeEnum.fairness in evaluation.evaluation_types:
        protected_indexes = collections.OrderedDict()
        for feat in evaluation.fairness_grouping_features:
            feature = next((f for f in features if f['name'] == feat.name), None)
            if feature is not None:
                protected_indexes[feature['index']] = Bucketer(feat.buckets, values=feature.get('category_values'))
            else:
                log.warn(f"Unknown feature '{feature['name']}' specified as part of fairness_grouping_features - ignoring value")

        fairness = {
            'protected_attr': protected_indexes,
            'independent_fairness': True  # treat attributes independently, not full cross product
        }
    else:
        fairness = None

    return fairness


def get_evaluation_options(use_case,
                           evaluation,
                           model,
                           model_features,
                           explainability_weights) -> dict:
    fairness = get_fairness_options(use_case, evaluation, model_features)
    options = get_cfi_options(fairness, use_case.task_type, model.name)
    options['feature_bounds'] = get_option_feature_bounds(evaluation.feature_restrictions, model_features)

    if use_case.task_type == ModelTypeEnum.multiclass_classification:
        options['class_structure'] = _prediction_favorability_to_class_structure(evaluation.prediction_favorability)

        if options['class_structure'] == ClassStructure.ORDERED:
            options['label_valuer'] = _create_default_label_valuer(evaluation.prediction_values)

    if (use_case.task_type == ModelTypeEnum.multiclass_classification and options['class_structure'] == ClassStructure.PARTITIONED) or \
            EvaluationTypeEnum.fairness in evaluation.evaluation_types:
            options['favorable_outcome'] = get_favorable_outcome_value(use_case, evaluation)

    if use_case.task_type == ModelTypeEnum.regression:
        options['regression_boundary_type'] = evaluation.regression_boundary_type_enum
        if evaluation.regression_boundary_type_enum == RegressionBoundaryTypeEnum.absolute:
            options['regression_boundary'] = evaluation.regression_boundary
            options['regression_boundary_percentile'] = evaluation.regression_boundary_percentile
        else:
            options['regression_standard_deviation'] = evaluation.regression_standard_deviation

    if EvaluationTypeEnum.explainability in evaluation.evaluation_types:
        options['explainability_score_mappings'] = explainability_weights

    if EvaluationTypeEnum.explainability in evaluation.evaluation_types or EvaluationTypeEnum.explanation in evaluation.evaluation_types:
        # Ensure primary explanation type is first in the list
        canonical_explanation_types = [evaluation.primary_explanation_type]
        for et in evaluation.explanation_types:
            if et not in canonical_explanation_types:
                canonical_explanation_types.append(et)
        options['explanation_types'] = canonical_explanation_types

    return options


# utilities for multiclass options

def _create_default_label_valuer(prediction_values) -> dict:
    """
    Returns a dictionary mapping prediction values to int's based on original order in
    prediction_values list. A higher integer value implies greater favorability.
    """
    label_valuer = {} # prediction value -> int
    for idx, prediction in enumerate(prediction_values):
        label_valuer[prediction.value] = len(prediction_values) - idx
    return label_valuer

class_structure_map = {
    PredictionFavorabilityEnum.none: ClassStructure.UNSTRUCTURED,
    PredictionFavorabilityEnum.ordered: ClassStructure.ORDERED,
    PredictionFavorabilityEnum.explicit: ClassStructure.PARTITIONED,
}

def _prediction_favorability_to_class_structure(favorability: PredictionFavorabilityEnum) -> ClassStructure:
    return class_structure_map[favorability]
