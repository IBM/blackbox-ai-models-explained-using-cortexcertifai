from typing import Any, List, Dict, Iterable, Optional
from abc import ABC

import numpy as np

from certifai.engine.engine_api_types import ExplanationType


class Explanation(ABC):
    """Abstract base class for explanations - different analyses will have different forms
       of explanation, so this class just serves as a type-root"""
    pass


class IExplainedPrediction(ABC):
    """Interface for prediction instance explanation

    """
    @property
    def explanation_type(self) -> ExplanationType:
        """Returns the type of explanation (e.g. - counterfactual, shap, ...)"""
        pass

    @property
    def prediction(self) -> Any:
        """Return the proediction the mole made for the instance to which this
            explanation pertains"""
        pass

    @property
    def instance(self) -> np.ndarray:
        """Return the instance data for the instance to which this
            explanation pertains"""
        pass

    @property
    def field_names(self) -> List[str]:
        """Return the names of fields in the order they appear as columns in other structures such
           as the `instance` property or aspects of the particular explanation"""
        pass

    @property
    def explanation(self) -> Explanation:
        """Details of the explanation.  The exact form will vary depending on what type
           of explanation analysis was run"""
        pass

    @property
    def alternate(self) -> bool:
        """If True then this expalnation is an alternate explanation rather than the primary"""
        return False


class ShapExplanation(Explanation):
    """SHAP-specific explanation details"""
    def __init__(self,
                 class_expected_score: float,
                 features_weights: np.ndarray):
        self._class_expected_score = class_expected_score
        self._feature_weights = features_weights

    @property
    def class_expected_score(self) -> float:
        """Expected model score for the class being predicted

        :return: baseline soft score from the model for examples of this class
        """
        return self._class_expected_score

    @property
    def feature_weights(self) -> np.ndarray:
        """SHAP values for each feature

        :return: numpy array of feature weights (same order as `field_names` in the parent
                 `IExplainedPrediction`)
        """
        return self._feature_weights


class Counterfactual:
    """A specific counterfactual instance

    """
    def __init__(self,
                 counterfactual_type: str,
                 prediction: Any,
                 data: np.ndarray):
        self._counterfactual_type = counterfactual_type
        self._prediction = prediction
        self._data = data

    @property
    def counterfactual_type(self) -> str:
        """Type of counterfactual
           Current possible values are:
           * "prediction more beneficial"
           * "prediction less beneficial"
           * "prediction changed"
           * "prediction decreased" (regression tasks only)
           * "prediction increased" (regression tasks only)

        :return: human-readable string describing the type of change the counterfactual illustrates
        """
        return self._counterfactual_type

    @property
    def prediction(self) -> Any:
        """Prediction from the model for this example

        :return: model predicted class or value
        """
        return self._prediction

    @property
    def data(self) -> np.ndarray:
        """Example field values for this example

        :return: numpy array of feature values (same order as `field_names` in the parent
                 `IExplainedPrediction`)
        """
        return self._data


class CounterfactualExplanation(Explanation):
    """Counterfactual explanation details

    """
    def __init__(self,
                 best_individuals: List[Counterfactual]):
        self._best_individuals = best_individuals

    @property
    def best_individuals(self):
        """Illustrative set of counterfactal instances for this example

        :return: list of `Counterfactual`
        """
        return self._best_individuals


class ExplainedPrediction(IExplainedPrediction):
    def __init__(self,
                 input_features: np.ndarray,
                 feature_names: Iterable[str],
                 prediction: Any,
                 explanation_type: ExplanationType,
                 explanation: Explanation,
                 is_alternate: bool=False):
        self._instance = input_features
        self._field_names = list(feature_names)
        self._prediction = prediction
        self._explanation_type = explanation_type
        self._explanation = explanation
        self._is_alternate = is_alternate

    @property
    def explanation_type(self) -> ExplanationType:
        """Returns the type of explanation (e.g. - counterfactual, shap, ...)"""
        return self._explanation_type

    @property
    def prediction(self) -> Any:
        """Return the prediction the model made for the instance to which this
            explanation pertains"""
        return self._prediction

    @property
    def instance(self) -> np.ndarray:
        """Return the instance data for the instance to which this
            explanation pertains"""
        return self._instance

    @property
    def field_names(self) -> List[str]:
        """Return the names of fields in the order they appear as columns in other structures such
           as the `instance` property or aspects of the particular explanation"""
        return self._field_names

    @property
    def explanation(self) -> Explanation:
        """Details of the explanation.  The exact form will vary depending on what type
           of explanation analysis was run"""
        return self._explanation

    @property
    def alternate(self):
        return self._is_alternate

    @staticmethod
    def shap_explanation(input_features: np.ndarray,
                         feature_names: Iterable[str],
                         prediction: Any,
                         explanation: ShapExplanation) -> IExplainedPrediction:
        return ExplainedPrediction(input_features,
                                   feature_names,
                                   prediction,
                                   ExplanationType.SHAP,
                                   explanation)

    @staticmethod
    def counterfactual_explanation(input_features: np.ndarray,
                                   feature_names: Iterable[str],
                                   prediction: Any,
                                   explanation: CounterfactualExplanation,
                                   is_alternate: bool=False) -> IExplainedPrediction:
        return ExplainedPrediction(input_features,
                                   feature_names,
                                   prediction,
                                   ExplanationType.Counterfactual,
                                   explanation,
                                   is_alternate=is_alternate)


def explanations(report: dict,
                 model_id: Optional[str]=None,
                 include_alternates: bool=False) -> Dict[str, Iterable[IExplainedPrediction]]:
    """Extract all the explanations from a scan output dictionary

    :param dict report: dictionary produced by a scan
    :param Optional[str] model_id: Optional model id to restrict to (default `None`)
    :return: Dictionary keyed on model_id whose values are `Iterable[IExplainedPrediction]`
    """
    def model_explanations(md):
        fields = [f['name'] for f in md.get('model_schema', md.get('dataset_schema'))['feature_schemas']]
        for exp in md['explanations']:
            input_features = np.array(exp['inputFeatures'], dtype='object')
            input_prediction = exp['inputPrediction']
            cfs = [Counterfactual(ind['counterfactualType'],
                                  ind['prediction'],
                                  np.array(ind['data'], dtype='object')) for ind in exp.get('bestIndividuals',[])
                   if len(ind.get('data',[])) > 0]
            if len(cfs) > 0:
                yield ExplainedPrediction.counterfactual_explanation(input_features,
                                                                     fields,
                                                                     input_prediction,
                                                                     CounterfactualExplanation(cfs))
                if include_alternates:
                    a_cfs = [Counterfactual(ind['counterfactualType'],
                                            ind['prediction'],
                                            np.array(ind['data'], dtype='object')) for ind in exp.get('additionalCFs',[])
                             if len(ind.get('data',[])) > 0]
                    # Gather by counterfactual type and reconstitute a single explanation with best individuals
                    # for each type as a single explanation
                    by_type = {}
                    for a_cf in a_cfs:
                        by_type[a_cf.counterfactual_type] = by_type.get(a_cf.counterfactual_type, []) + [a_cf]
                    idx = 0
                    while True:
                        best_individuals = []
                        for typed_a_cfs in by_type.values():
                            if len(typed_a_cfs) > idx:
                                best_individuals.append(typed_a_cfs[idx])
                        idx += 1
                        if len(best_individuals) > 0:
                            yield ExplainedPrediction.counterfactual_explanation(input_features,
                                                                                 fields,
                                                                                 input_prediction,
                                                                                 CounterfactualExplanation(best_individuals),
                                                                                 is_alternate=True)
                        else:
                            break
            shap = exp.get('kernel_shap', {})
            if len(shap) > 0:
                yield ExplainedPrediction.shap_explanation(input_features,
                                                           fields,
                                                           input_prediction,
                                                           ShapExplanation(shap['expected_class_value'],
                                                                           np.array(shap['shap_values'])))

    result = {}
    for m_id, md in report.get('explanation', {}).items():
        if (model_id is None) or (model_id == m_id):
            result[m_id] = list(model_explanations(md))

    return result

