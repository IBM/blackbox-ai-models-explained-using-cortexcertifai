from dataclasses import dataclass
from typing import List, Optional, Any, Dict
from abc import ABC, abstractmethod

from certifai.common.types import EvaluationTypeEnum
from certifai.scanner.schemas import (Scan, Model, ModelUseCase, Evaluation, DatasetFeatureSchema, Dataset)

@dataclass
class ScanContext:
    """Dataclass encapsulating the information needed to perform a scan."""
    scan: Scan
    models: List[Model]
    use_case: ModelUseCase
    evaluation: Evaluation
    dataset_schema: DatasetFeatureSchema
    dataset_features: List[dict]
    model_features: List[dict]
    eval_dataset: Dataset
    expl_dataset: Optional[Dataset]
    test_dataset: Optional[Dataset]
    atx_weights: dict    # already converted to engine format (hence dict)
    explainability_weights: dict


class ScanTimeEstimator(ABC):
    """
    Abstract base class for offering time estimates for a scan.

    Implementations should raise a CertifaiTimeEstimateException if a time estimate cannot be produced
    because of insufficient data.
    """

    @abstractmethod
    def total_in_seconds(self) -> int:
        """Offer an estimate for the number of seconds the overall scan will take"""
        ...

    @abstractmethod
    def total_in_minutes(self) -> int:
        """Offer an estimate for the number of minutes the overall scan will take"""
        ...

    @abstractmethod
    def time_for_evaluation(model_id: str, eval_type: EvaluationTypeEnum) -> int:
        """
        Returns an estimate for the number of seconds an evaluation will take for the given model
        :param str model_id: id of model to use for estimation
        :param EvaluationTypeEnum eval_type: analysis type to offer an estimate for
        :return: estimate for the number of seconds the evaluation will take
        """
        ...
