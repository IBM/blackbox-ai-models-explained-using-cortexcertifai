"""
Marshmallow Schemas used by the scanner.
"""
import os
import re
from typing import Optional, List, Sequence, Any, Iterable, Dict, Union, Callable
import pandas as pd
from copy import copy
import inspect
from marshmallow import (Schema, fields, validates, validate, validates_schema,
                         pre_load, post_load, pre_dump, post_dump, ValidationError)
from certifai.common.utils import get_logger
from certifai.common.errors import (CertifaiValidationException,
                                    CertifaiUnknownMetricException,
                                    CertifaiMetricSpecifierException)
from certifai.common.hosted_model import HostedModel, IHostedModel
from certifai.common.types import EncodingEnum, ModelTypeEnum, AtxComponentsEnum, FileTypeEnum
from certifai.common.types import (EvaluationTypeEnum, RestrictionStringEnum, DataTypeEnum, JsonOrientEnum,
                                   ExplanationTypeEnum, RegressionBoundaryTypeEnum)
from certifai.common.types import PredictionFavorabilityEnum, RegressionOutcomeValueEnum
from certifai.common.helpers import enum_values
from certifai.common.utils.fn_utils import fmap_opt
from certifai.engine.performance import validate_metric_supported
from certifai.common.utils.utils import generate_uuid
from certifai.engine.fairness_metrics import is_valid_fairness
from certifai.scanner.version import get_full_version
from dataclasses import dataclass, field
import dataclasses

log = get_logger()

# Constants used in schemas

ALPHA_NUMERIC_REGEX = '^[a-zA-Z0-9_]+$' # alphanumeric & underscore
ALPHA_NUMERIC_REGEX_ERROR = 'Input string {input} is not alphanumeric.'
ENV_VARIABLE_REGEX = r'.*?\${(\w+)}.*?'
JSON_ORIENTS = enum_values(JsonOrientEnum)
DEFAULT_JSON_ORIENT = JsonOrientEnum.records.value
DEFAULT_JSON_LINES = True
DEFAULT_CSV_HAS_HEADER = True
EVALUATION_TYPES = enum_values(EvaluationTypeEnum)
EXPLANATION_TYPES = enum_values(ExplanationTypeEnum)
DATASET_ENCODINGS = enum_values(EncodingEnum)
ATX_COMPONENTS = enum_values(AtxComponentsEnum)
FILE_TYPES = enum_values(FileTypeEnum)
DATA_TYPES = enum_values(DataTypeEnum)
PREDICTION_TYPES = enum_values(PredictionFavorabilityEnum)
REGRESSION_PREDICTION_VALUES = enum_values(RegressionOutcomeValueEnum)
REGRESSION_BOUNDARY_TYPES = enum_values(RegressionBoundaryTypeEnum) + [e.lower() for e in enum_values(RegressionBoundaryTypeEnum)]

# no longer support classification (use binary-classification instead)
TASK_TYPES = enum_values(ModelTypeEnum)
TASK_TYPES.remove(ModelTypeEnum.classification)

# RestrictionStringEnum.percentage string is currently '+-%', but the scanner supports
# the word 'percentage' instead. It will be mapped back during deserilization.
RESTRICTIONS = enum_values(RestrictionStringEnum)
RESTRICTIONS.remove(RestrictionStringEnum.percentage.value)
RESTRICTIONS.append(RestrictionStringEnum.percentage.name)


def _dataclass_from_dict(klass, d):
    """Instantiate a dataclass from a field name: value dict
       Note - supports fields and properties of the dataclasses"""
    try:
        fieldtypes = {f.name:f.type for f in dataclasses.fields(klass)}
        propnames = [name for (name, value) in inspect.getmembers(klass, lambda p: isinstance(p, property) and p.fset)]
        args = {}
        for f, v in d.items():
            if f in fieldtypes:
                args[f] = _dataclass_from_dict(fieldtypes[f], v)
            elif f not in propnames:
                raise ValueError(f"Missing filed/property '{f}' on dataclass")

        result = klass(**args)
        for f, v in d.items():
            if f in propnames:
                p = getattr(klass, f)
                p.fset(result, v)
        return result

    except Exception as e:
        return d # Not a dataclass field


# Common base type for objects that are serialized/deserialized
class BaseObject:
    SCHEMA_NAME = None

    def dump(self, mode='report'):
        if self.SCHEMA_NAME is None:
            return self
        else:
            # Allow individual schema classes to interpret the mode
            # (usually as on or more excludes) and also pass the mode through
            # via the serialization context
            klass = globals()[self.SCHEMA_NAME]
            mode_args_gen = getattr(klass, 'interpret_mode', None)
            if mode_args_gen is not None:
                extra_args = mode_args_gen(mode)
            else:
                extra_args = {}
            extra_args['context'] = {'mode': mode}
            return globals()[self.SCHEMA_NAME](**extra_args).dump(self, contextual=True)


# Helper function to dump a list of objects
def dump_many(m: Iterable[BaseObject], mode='report'):
    return list(map(lambda _: _.dump(mode=mode), m))


# Common Schema that wraps ValidationException's

class BaseSchema(Schema):
    DATACLASS = None

    @property
    def notebook_semantics(self):
        return 'notebook' in self.context

    # To ensure that mode handling applies recursively to embedded objects
    # we need to modify the behavior of dump to redirect via the dataclass'
    # dump, but in doing so we also need to protect against recursion loops
    # since that method will ultimately call back to this one.  The addition
    # of the 'contextual' parameter is used to provide this protection
    def dump(self, data, **kwargs):
        if (self.DATACLASS is not None) and ('contextual' not in kwargs):
            if self.many or kwargs.get('many', False):
                return dump_many(data, mode=self.context.get('mode'))
            return data.dump(mode=self.context.get('mode'))
        else:
            kwargs.pop('contextual', None)
            return super().dump(data, **kwargs)

    def dataclass_args(self, data: dict) -> dict:
        """
        Override to provide representation translation between
        the schema representation and the dataclass
        :param dict: deserialized parameter dictionary
        :return: param dict to be used to initialize the dataclass
        """
        return data

    @pre_load
    def pre_load(self, data, **kwargs):
        if not isinstance(data, dict):
            raise ValidationError({'': 'object required'})
        return data

    @post_load
    def to_dataclass(self, data, **kwargs):
        if self.DATACLASS is not None:
            result = _dataclass_from_dict(self.DATACLASS, self.dataclass_args(data))
            return result
        else:
            return data

    def omit(self, data, key, value):
        def isempty(value):
            # Handling of optional strings that are empty is different between serializing into
            # a report vs a template.  In templates we just want to omit those fields, but in
            # reports it may be that consuming code is expecting the field to be unconditionally
            # present, so we retain the empty strings for backward compatibility
            if isinstance(value, str):
                return (self.context != 'report') and (len(value) == 0)
            else:
                return hasattr(value, '__len__') and len(value) == 0

        if key not in self.fields:
            return True
        else:
            return (not self.fields[key].required) and ((value is None) or isempty(value))

    @post_dump
    def remove_null_values(self, data, **kwargs):
        return {
            key: value for key, value in data.items()
            if not self.omit(data, key, value)
        }

    def handle_error(self, error, data, **kwargs):
        """
        Custom error handler that logs all validation errors and raises a CertifaiValidationException.
        Child classes can specify a 'CORRESPONDING_YAML_SECTION' attribute that will be used for better
        error messaging.
        """
        if hasattr(self, 'CORRESPONDING_YAML_SECTION'):
            schema_name = self.CORRESPONDING_YAML_SECTION
        else:
            schema_name = str(self.__class__.__name__)[:-len('schema')]

        attribute_error = lambda attribute, message: f"Attribute '{attribute}' {message}"
        error_list = []
        for attribute in error.messages:
            errors_per_attribute = error.messages[attribute]
            if isinstance(errors_per_attribute, str):
                error_list.append(attribute_error(attribute, errors_per_attribute))
            elif not isinstance(errors_per_attribute, list):
                error_list.append(attribute_error(attribute, errors_per_attribute))
            else:
                error_list.extend([attribute_error(attribute, message) for message in errors_per_attribute])
        raise CertifaiValidationException(f"Validation of '{schema_name}' section of input failed", error_list)


@dataclass
class Metric(BaseObject):
    SCHEMA_NAME = 'MetricSchema'

    metric: Optional[str] = None
    name: str = ''


# Metrics Schemas
class MetricSchema(BaseSchema):
    metric = fields.String(required=False)
    name = fields.String(required=True)
    CORRESPONDING_YAML_SECTION = 'model_use_case.performance_metrics'
    DATACLASS = Metric

    @validates('metric')
    def validate_metric(self, value):
        try:
            validate_metric_supported(value)
        except (CertifaiUnknownMetricException, CertifaiMetricSpecifierException) as ex:
            raise ValidationError(str(ex))


@dataclass
class MetricValue(BaseObject):
    SCHEMA_NAME = 'MetricValueSchema'

    value: float
    name: str


class MetricValueSchema(BaseSchema):
    value = fields.Number(required=True, validate=validate.Range(min=0, max=1))
    name = fields.String(required=True)
    CORRESPONDING_YAML_SECTION = 'models.performance_metric_values'
    DATACLASS = MetricValue


## Schema's for validating input metadata

@dataclass
class Output(BaseObject):
    SCHEMA_NAME = 'OutputSchema'

    path: Optional[str] = None

    def is_default(self):
        return self.path is None


class OutputSchema(BaseSchema):
    """Schema for 'Output' options (e.g. writing results to a file) - Used as part of ScanSchema"""
    class Meta:
        ordered = True

    path = fields.Str()
    CORRESPONDING_YAML_SECTION = 'scan.output'
    DATACLASS = Output


@dataclass
class Scan(BaseObject):
    SCHEMA_NAME = 'ScanSchema'

    scan_id: Optional[str] = None
    evaluation_type: Optional[str] = None
    output: Output = Output()
    started: Optional[str] = None
    ended: Optional[str] = None
    name: Optional[str] = None
    environment: Optional[str] = None
    description: Optional[str] = None
    scanner_version: Optional[str] = None


class ScanSchema(BaseSchema):
    """Schema for the scan metadata found in output reports (used for both input & output) formatting."""
    scan_id = fields.Str()
    evaluation_type = fields.Str()
    output = fields.Nested(OutputSchema)
    started = fields.Str()
    ended = fields.Str()
    scanner_version = fields.Str()

    CORRESPONDING_YAML_SECTION = 'scan'
    DATACLASS = Scan

    @staticmethod
    def interpret_mode(mode: str):
        if mode == 'report':
            return {
                'exclude': ('output',)
            }
        else:
            return {
                'exclude': ("scan_id", "evaluation_type", "started", "ended", "name", "environment",
                    "description", "scanner_version" )
            }

    # used in input

    class Meta:
        ordered = True
        additional = ("name", "environment", "description", "scanner_version")


@dataclass
class ModelUseCase(BaseObject):
    SCHEMA_NAME = 'ModelUseCaseSchema'

    name: str
    model_use_case_id: str
    performance_metrics: List[Metric] = field(default_factory=list)
    atx_performance_metric_name: Optional[str] = None
    task_type: str = ''
    description: Optional[str] = None
    author: Optional[str] = None


class ModelUseCaseSchema(BaseSchema):
    """Schema for a use_case (e.g. project) metadata"""
    name = fields.Str(required=True)
    model_use_case_id = fields.Str(required=True)
    performance_metrics = fields.List(fields.Nested(MetricSchema), required=False, missing=[])
    atx_performance_metric_name = fields.Str(required=False)
    task_type = fields.Str(required=True, validate=validate.OneOf(TASK_TYPES))
    CORRESPONDING_YAML_SECTION = 'model_use_case'
    DATACLASS = ModelUseCase

    class Meta:
        ordered = True
        additional = ("description", "author")

    @validates_schema
    def valid_atx_performance_metric(self, data, **kwargs):
        atx_metric = data.get('atx_performance_metric_name')
        if len(data['performance_metrics']) > 0:
            if atx_metric is None:
                raise ValidationError({'atx_performance_metric_name': f"An atx_performance_metric_name value must be provided to select the appropriate metric"})
        if (atx_metric is not None) and (atx_metric not in [m.name for m in data['performance_metrics']]):
            raise ValidationError({'atx_performance_metric_name': f"Metric '{data['atx_performance_metric_name']}' not in list of defined performance metrics"})

# model headers schema


@dataclass
class DefaultModelHeader(BaseObject):
    SCHEMA_NAME = 'DefaultModelHeaderSchema'

    name: str
    value: str


class DefaultModelHeaderSchema(BaseSchema):
    """Schema for default model header section of input - used as part of @ModelHeadersSchema."""

    name = fields.Str(required=True)
    value = fields.Str(required=True)
    CORRESPONDING_YAML_SECTION = 'model_headers.default'
    DATACLASS = DefaultModelHeader


@dataclass
class DefinedModelHeader(BaseObject):
    SCHEMA_NAME = 'DefinedModelHeaderSchema'

    model_id: str
    name: str
    value: str


class DefinedModelHeaderSchema(BaseSchema):
    """Schema for overriding default model headers section of input(based on model_id) - used as part of @ModelHeadersSchema."""

    model_id = fields.String(required=True, validate=validate.Regexp(ALPHA_NUMERIC_REGEX,
                                                                     error=ALPHA_NUMERIC_REGEX_ERROR))
    name = fields.Str(required=True)
    value = fields.Str(required=True)
    CORRESPONDING_YAML_SECTION = 'model_headers.defined'
    DATACLASS = DefinedModelHeader


@dataclass
class ModelHeaders(BaseObject):
    SCHEMA_NAME = 'ModelHeadersSchema'

    default: Optional[List[DefaultModelHeader]] = None
    defined: Optional[List[DefinedModelHeader]] = None


class ModelHeadersSchema(BaseSchema):
    """Schema for the Model Header section of the input data."""

    default = fields.List(fields.Nested(DefaultModelHeaderSchema), validate=validate.Length(min=1))
    defined = fields.List(fields.Nested(DefinedModelHeaderSchema), validate=validate.Length(min=1))
    CORRESPONDING_YAML_SECTION = 'model_headers'
    DATACLASS = ModelHeaders

    @validates_schema
    def unique_model_headers(self, data, **kwargs):
        """
        Performs extra validation on the model header input data, such as validating the
        header input contains unique keys. headers in defined section can override the default section
        """
        errors = {}
        default_headers = data.get('default')
        if default_headers is not None:
            default_header_names = list(map(lambda x: x.name, default_headers))
            if len(set(default_header_names)) != len(default_headers):
                errors['default'] = ['contains duplicate keys']

        defined_headers = data.get('defined')
        if defined_headers is not None:
            unique_models_ids = set(list(map(lambda x: x.model_id, defined_headers)))
            for model_id in unique_models_ids:
                defined_headers_name = list(map(lambda x: x.name, filter(lambda x: x.model_id == model_id, defined_headers)))
                if len(set(defined_headers_name)) != len(defined_headers_name):
                    errors['defined'] = ['contains duplicate keys']
        if errors:
            raise ValidationError(errors)


# model connector schema
@dataclass
class ModelConnectorSecrets(BaseObject):
    SCHEMA_NAME = 'ModelConnectorSecretsSchema'
    name: str
    value: str


class ModelConnectorSecretsSchema(BaseSchema):
    """Schema for Model Connector Secrets """

    name = fields.Str(required=True)
    value = fields.Str(required=True)
    CORRESPONDING_YAML_SECTION = 'model_connectors.secrets'
    DATACLASS = ModelConnectorSecrets


# mode args
@dataclass
class ModelArgs(BaseObject):
    SCHEMA_NAME = 'ModelArgsSchema'
    name: str
    value: str


class ModelArgsSchema(BaseSchema):
    """Schema for Model Args"""
    name = fields.Str(required=True)
    value = fields.Str(required=True)
    CORRESPONDING_YAML_SECTION = 'model_connectors.model_args'
    DATACLASS = ModelArgs


@dataclass
class ModelConnector(BaseObject):
    SCHEMA_NAME = 'ModelConnectorSchema'

    name: str
    module_name: str
    class_name: str
    description: Optional[str] = None
    model_ids: List[str] = field(default_factory=list)
    model_args: Optional[List[ModelArgs]] = None
    secrets: Optional[List[ModelConnectorSecrets]] = None


class ModelConnectorSchema(BaseSchema):
    name = fields.Str(required=True)
    module_name = fields.Str(required=True)
    class_name = fields.Str(required=True)
    model_ids = fields.List(fields.Str(), required=True)
    model_args = fields.List(fields.Nested(ModelArgsSchema), validate=validate.Length(min=1))
    secrets = fields.List(fields.Nested(ModelConnectorSecretsSchema), validate=validate.Length(min=1))

    class Meta:
        additional = ('description', 'model_args')

    CORRESPONDING_YAML_SECTION = 'model_connectors'
    DATACLASS = ModelConnector


@dataclass
class Model(BaseObject):
    SCHEMA_NAME = 'ModelSchema'

    model_id: str
    name: str
    max_batch_size: Optional[int] = None
    predict_endpoint: Optional[str] = None
    performance_metric_values: List[MetricValue] = field(default_factory=list)
    description: Optional[str] = None
    version: Optional[str] = None
    author: Optional[str] = None
    model_id_tag: Optional[str] = None
    supports_soft_scoring: bool = False
    prediction_value_order: Optional[List[Any]] = None

    # Internal representation
    hosted_model: IHostedModel = None

    def __init__(self,
                 model_id: str,
                 name: str,
                 max_batch_size: Optional[int] = None,
                 predict_endpoint: Optional[str] = None,
                 performance_metric_values: List[MetricValue] = [],
                 description: Optional[str] = None,
                 version: Optional[str] = None,
                 author: Optional[str] = None,
                 model_id_tag: Optional[str] = None,
                 hosted_model: Optional[IHostedModel]=None,
                 prediction_value_order: Optional[List[Any]]=None,
                 supports_soft_scoring: bool=False):
        self.model_id = model_id
        self.name = name
        self.max_batch_size = max_batch_size
        self.predict_endpoint = predict_endpoint
        self.performance_metric_values = performance_metric_values
        self.description = description
        self.version = version
        self.author = author
        self.model_id_tag = model_id_tag

        # Internal representation
        if hosted_model is None:
            if predict_endpoint is not None:
                self.hosted_model = HostedModel(predict_endpoint,
                                                batch_support=True, # always true
                                                max_batch_size=max_batch_size,
                                                label_ordering=prediction_value_order,
                                                supports_soft_scores=supports_soft_scoring)
            else:
                self.hosted_model = None
                self.supports_soft_scoring = supports_soft_scoring
                self.prediction_value_order = prediction_value_order
        else:
            self.hosted_model = hosted_model

        if self.hosted_model is not None:
            self.supports_soft_scoring = self.hosted_model.supports_soft_scores
            self.prediction_value_order = self.hosted_model.label_ordering


class ModelSchema(BaseSchema):
    """Schema for model metadata in the scanner"""
    model_id = fields.Str(required=True, validate=validate.Regexp(ALPHA_NUMERIC_REGEX, error=ALPHA_NUMERIC_REGEX_ERROR))
    name = fields.Str(required=True)
    max_batch_size = fields.Int(validate=validate.Range(min=1))
    predict_endpoint = fields.Str(required=False)   # validation function will ensure it is required except for notebook usage
    performance_metric_values = fields.List(fields.Nested(MetricValueSchema))
    supports_soft_scoring = fields.Bool(default=False)
    prediction_value_order = fields.List(fields.Inferred(), required=False)
    CORRESPONDING_YAML_SECTION = 'models'
    DATACLASS = Model

    class Meta:
        ordered = True
        additional = ("description", "version", "author", "model_id_tag", "hosted_model")
        exclude = ("hosted_model",)

    @validates_schema
    def check_source_specified(self, data, **kwargs):
        endpoint_specified = data.get('predict_endpoint') is not None
        name = data.get('model_id', 'UNKNOWN')
        if not (endpoint_specified or self.notebook_semantics):
            raise ValidationError(f"Model '{name}' must specify a value for 'predict_endpoint'")

    def omit(self, data, key, value):
        if (key == 'supports_soft_scoring') and not value:
            return True
        else:
            return super().omit(data, key, value)


# Dataset & Feature schemas

@dataclass
class Dataset(BaseObject):
    SCHEMA_NAME = 'DatasetSchema'

    dataset_id: str = ''
    url: Optional[str] = None
    has_header: bool = True
    file_type: Optional[str] = None
    encoding: Optional[str] = None

    # used in output (not in input)
    checksum_type: Optional[str] = None
    checksum: Optional[str] = None
    num_features: int = 0
    rows: int = 0

    # json specific
    lines: bool = True
    orient: str = ''

    name: str = ''
    description: str = ''
    delimiter: str = ','
    escape_character: Optional[str] = None
    quote_character: str = '"'

    # Internal state (not serialized)
    data: pd.DataFrame = None
    pre_processed: bool = False
    ground_truth: Sequence = None
    non_model_column_indexes: List[int] = field(default_factory=list)
    encoder: Optional[Callable] = None

    @property
    def encodes_feature_order(self):
        return ((self.file_type == 'json') and (self.orient in ('columns', 'values'))) or \
               (self.file_type == 'csv') or \
               (self.file_type == 'loaded')


class DatasetSchema(BaseSchema):
    """Schema for the dataset specification in metadata and in output report."""
    dataset_id = fields.Str(required=True, validate=validate.Regexp(ALPHA_NUMERIC_REGEX, error=ALPHA_NUMERIC_REGEX_ERROR))
    # validation will check that the 3 fields `url`, `file_type`, and `encoding` are either all present or all absent
    url = fields.Str(required=False)
    has_header = fields.Bool()
    file_type = fields.Str(required=False)
    encoding = fields.Str(validate=validate.OneOf(DATASET_ENCODINGS))

    # used in output (not in input)
    checksum_type = fields.Str(missing='None')
    checksum = fields.Str(missing=None)
    num_features = fields.Int()
    rows = fields.Int()

    # json specific
    lines = fields.Bool()
    orient = fields.Str(validate=validate.OneOf(JSON_ORIENTS))

    CORRESPONDING_YAML_SECTION = 'datasets'
    DATACLASS = Dataset

    @staticmethod
    def interpret_mode(mode: str):
        if mode == 'report':
            return {
                'exclude': ('has_header', 'file_type', 'encoding', 'delimiter', 'escape_character',
                            'quote_character', 'lines', 'orient', 'data', 'ground_truth', 'pre_processed')
            }
        else:
            return {
                'exclude': ('rows', 'num_features', 'checksum_type', 'checksum', 'data', 'ground_truth', 'pre_processed')
            }

    def omit(self, data, key, value):
        if 'file_type' in data:
            if data['file_type'] == 'json':
                omit_list = ('has_header', 'delimiter', 'escape_character', 'quote_character')
            else:
                omit_list = ('lines', 'orient')
        else:
            omit_list = []
        if key in omit_list:
            return True
        else:
            return super().omit(data, key, value)

    class Meta:
        ordered = True
        additional = ('name', 'description', 'delimiter', 'escape_character', 'quote_character', 'data', 'ground_truth', 'pre_processed')

    @validates_schema
    def check_file_type(self, data, **kwargs):
        file_type = data.get('file_type')
        name = data.get('dataset_id', 'UNKNOWN')
        valid_file_types = [f for f in FILE_TYPES]
        if self.notebook_semantics:
            valid_file_types.append('loaded')

        if file_type not in valid_file_types:
            raise ValidationError(f"'Dataset '{name}' has an invalid file_type. Must be one of: {', '.join(valid_file_types)}")

    @validates_schema
    def check_source_specified(self, data, **kwargs):
        url_specified = data.get('url') is not None
        file_type_specified = data.get('file_type') is not None
        specified = (url_specified, file_type_specified)
        name = data.get('dataset_id', 'UNKNOWN')

        if not (all(specified) or self.notebook_semantics):
            raise ValidationError(f"Dataset '{name}' must specify both 'url' and 'file_type'")
        if any(specified) and not all(specified) and not self.notebook_semantics:
            raise ValidationError(f"Dataset '{name}' must specify both of 'url and 'file_type' or neither of them")

    @pre_load
    def set_default_values(self, data, **kwargs):
        """
        Sets the appropriate defaults for data based on file_type (if set). Because default
        values are dependent on file_type (e.g. 'orient' for json vs 'has_header' for csv), we
        should only set the related attributes.

        Note: This is a pre_load method, so when this is executed the data has not gone through
        schema validation of any kind.
        """
        data = super().pre_load(data, **kwargs)

        if data.get('file_type') == FileTypeEnum.csv:
            data.setdefault('has_header', DEFAULT_CSV_HAS_HEADER)
        elif data.get('file_type') == FileTypeEnum.json:
            data.setdefault('lines', DEFAULT_JSON_LINES)
            data.setdefault('orient', DEFAULT_JSON_ORIENT)
        return data


class CategoryValue(fields.Field):
    """A category value may be either a string or an int.
    """

    def _serialize(self, value, attr, obj, **kwargs):
        return value

    def _deserialize(self, value, attr, data, **kwargs):
        if not (isinstance(value, str) or isinstance(value, int)):
            raise ValidationError("Category field values must be integers or strings")
        return value


@dataclass
class OneHotColumn(BaseObject):
    SCHEMA_NAME = 'OneHotColumnSchema'

    name: str
    value: Union[str, int]


class OneHotColumnSchema(BaseSchema):
    name = fields.Str(required=True)
    value = CategoryValue(required=True)
    CORRESPONDING_YAML_SECTION = 'dataset_schema.feature_schemas.one_hot_columns'
    DATACLASS = OneHotColumn


@dataclass
class DatasetFeatureSchema(BaseObject):
    SCHEMA_NAME = 'DatasetFeatureSchemaSchema'

    feature_name: Union[str, int] = ''
    category_values: Optional[List[Union[str, int]]] = None
    one_hot_columns: Optional[List[OneHotColumn]] = None
    target_encodings: Optional[List[float]] = None
    data_type: Optional[str] = None
    min: Optional[Union[int, float]] = None
    max: Optional[Union[int, float]] = None
    spread: Optional[float] = None


class IntOrFloat(fields.Field):
    """A field that can be either an int or a float.
    """

    def _serialize(self, value, attr, obj, **kwargs):
        return value

    def _deserialize(self, value, attr, data, **kwargs):
        if not (isinstance(value, float) or isinstance(value, int)):
            raise ValidationError("Field must be numeric")
        return value


class StringOrInt(fields.Field):
    """A field that can either be an string or int."""

    def _serialize(self, value, attr, obj, **kwargs):
        return value

    def _deserialize(self, value, attr, data, **kwargs):
        if not (isinstance(value, str) or isinstance(value, int)):
            raise ValidationError("Field must a string or integer")
        return value


class DatasetFeatureSchemaSchema(BaseSchema):
    """Schema for the dataset feature schema updates in the metadata - used as part of DatasetSchemaSchema"""
    class Meta:
        ordered = True

    feature_name = StringOrInt(required=True)
    category_values = fields.List(CategoryValue)
    one_hot_columns = fields.List(fields.Nested(OneHotColumnSchema))
    target_encodings = fields.List(fields.Number)
    data_type = fields.Str(validate=validate.OneOf(DATA_TYPES))
    min = IntOrFloat()
    max = IntOrFloat()
    spread = fields.Number()
    CORRESPONDING_YAML_SECTION = 'dataset_schema.feature_schemas'
    DATACLASS = DatasetFeatureSchema

    @validates_schema
    def check_bounds(self, data, **kwargs):
        min = data.get('min')
        max = data.get('max')
        data_type = data.get('data_type')
        one_hot_colummns = data.get('one_hot_columns')
        target_encodings = data.get('target_encodings')
        category_values = data.get('category_values')
        if data_type == 'numerical-int':
            if (min is not None) and not isinstance(min, int):
                raise ValidationError("Min field must be integral for a data_type of 'numerical-int'")
            if (max is not None) and not isinstance(max, int):
                raise ValidationError("Min field must be integral for a data_type of 'numerical-int'")
        if (min is not None) and (max is not None) and (min > max):
            raise ValidationError("'min' bound must be <= 'max' bound")
        if one_hot_colummns is not None:
            if data_type != 'categorical':
                raise ValidationError("'one_hot_columns' cannot be specified for datatypes other than 'categorical'")
            if category_values is None:
                raise ValidationError("'one_hot_columns' cannot be specified without 'category_values'")
            val_set = set()
            for oc in one_hot_colummns:
                if oc.value in val_set:
                    raise ValidationError(f"Value '{oc.value}' is specified for multiple one hot columns")
                val_set.add(oc.value)
            unknown_one_hot_vals = val_set.difference(set(category_values))
            missing_one_hot_vals = set(category_values).difference(val_set)
            if len(unknown_one_hot_vals) > 0:
                formated = [f"'{v.value}'" for v in one_hot_colummns if v.value in unknown_one_hot_vals]
                raise ValidationError(f"Unknown values {', '.join(formated)} listed in 'one_hot_columns' but not 'category_values'")
            if len(missing_one_hot_vals) > 0:
                formated = [f"'{v}'" for v in category_values if v in missing_one_hot_vals]
                raise ValidationError(f"Category values {', '.join(formated)} not specified in 'one_hot_columns'")
        if target_encodings is not None:
            if data_type != 'categorical':
                raise ValidationError("'target_encodings' cannot be specified for datatypes other than 'categorical'")
            if category_values is None:
                raise ValidationError("'target_encodings' cannot be specified without 'category_values'")
            if one_hot_colummns is not None:
                raise ValidationError("'target_encodings' cannot be specified with 'one_hot_colummns'")
            if len(target_encodings) != len(category_values):
                raise ValidationError(f"Number of specified target encodings ({len(target_encodings)}) does not match number of values ({len(category_values)})")


@dataclass
class DatasetSchemaDef(BaseObject):
    SCHEMA_NAME = 'DatasetSchemaSchema'

    outcome_column: Optional[Union[str, int]] = None
    predicted_outcome_column: Optional[Union[str, int]] = None
    hidden_columns: List[str] = field(default_factory=list)
    feature_schemas: List[DatasetFeatureSchema] = field(default_factory=list)
    defined_feature_order: bool = False

    @property
    def all_non_model_features(self) -> Iterable[str]:
        return set(filter(lambda x: x is not None,
                          self.hidden_columns + [self.outcome_column, self.predicted_outcome_column]))


class DatasetSchemaSchema(BaseSchema):
    """Schema for validating Dataset Schema definition in metadata"""
    class Meta:
        ordered = True

    outcome_column = StringOrInt()
    predicted_outcome_column = StringOrInt()
    hidden_columns = fields.List(fields.Str(), missing=[])
    feature_schemas = fields.List(fields.Nested(DatasetFeatureSchemaSchema), missing=[])
    defined_feature_order = fields.Bool(missing=False)
    CORRESPONDING_YAML_SECTION = 'dataset_schema'
    DATACLASS = DatasetSchemaDef

    def omit(self, data, key, value):
        if (key == 'defined_feature_order') and not value:
            return True
        else:
            return super().omit(data, key, value)

# Evaluation Schemas


@dataclass
class FeatureRestrictions(BaseObject):
    SCHEMA_NAME = 'FeatureRestrictionsSchema'

    feature_name: Union[str, int]
    restriction_string: str = RestrictionStringEnum.no_restrictions.value
    restriction_numerical_percentage: Optional[float] = None
    restriction_numerical_min: Optional[float] = None
    restriction_numerical_max: Optional[float] = None


class FeatureRestrictionsSchema(BaseSchema):
    """Schema for the feature restrictions in the metadata - used as part of evaluation"""
    class Meta:
        ordered = True

    feature_name = StringOrInt(required=True)
    restriction_string = fields.Str(validate=validate.OneOf(RESTRICTIONS),
                                    missing=RestrictionStringEnum.no_restrictions.value)
    restriction_numerical_percentage = fields.Number()
    restriction_numerical_min = fields.Number()
    restriction_numerical_max = fields.Number()
    CORRESPONDING_YAML_SECTION = 'evaluation.feature_restrictions'
    DATACLASS = FeatureRestrictions

    @validates_schema
    def correct_restriction_applications(self, data, **kwargs):
        errors = {}
        restriction = data.get('restriction_string')
        error_msg = f"required when restriction_string is '{restriction}'"
        if restriction == RestrictionStringEnum.min_max:
            if 'restriction_numerical_min' not in data:
                errors['restriction_numerical_min'] = error_msg
            if 'restriction_numerical_max' not in data:
                errors['restriction_numerical_max'] = error_msg
        if restriction == RestrictionStringEnum.percentage.name: # RestrictionStringEnum.percentage is '+-%' not 'percentage'
            if 'restriction_numerical_percentage' not in data:
                errors['restriction_numerical_percentage'] = error_msg

        if errors:
            raise ValidationError(errors)

    @post_load
    def fix_percentage_restriction(self, data, **kwargs):
        """
        Converts the restriction_string from 'percentage' to RestrictionStringEnum.percentage.value,
        as the two are currently not aligned ('percentage' vs '+-%').
        """
        if data.get('restriction_string') == RestrictionStringEnum.percentage.name:
            data['restriction_string'] = RestrictionStringEnum.percentage.value
        return data

    @pre_dump
    def revert_fix_percentage_restriction(self, data, **kwargs):
        """
        Converts the restriction_string from '+-%' to RestrictionStringEnum.percentage.name ('percentage'),
        """
        if data.restriction_string == RestrictionStringEnum.percentage.value:
            data.restriction_string = RestrictionStringEnum.percentage.name
        return data


@dataclass
class FeatureBucket(BaseObject):
    SCHEMA_NAME = 'FeatureBucketSchema'

    description: str
    max: Optional[float] = None
    values: Optional[List[str]] = field(default_factory=list)


class FeatureBucketSchema(BaseSchema):
    """Schema specifying buckets for fairness grouping features, used as part of the evaluation spec"""
    class Meta:
        ordered = True

    description = fields.Str(required=True)
    max = fields.Number(required=False)
    values = fields.List(fields.Str(), required=False)
    CORRESPONDING_YAML_SECTION = 'evaluation.fairness_grouping_features.buckets'
    DATACLASS = FeatureBucket


@dataclass
class FairnessGrouping(BaseObject):
    SCHEMA_NAME = 'FairnessGroupingSchema'

    name: Union[str, int]
    buckets: List[FeatureBucket] = field(default_factory=list)


class FairnessGroupingSchema(BaseSchema):
    """Schema specifying fairness grouping features, used as part of the evaluation spec"""
    class Meta:
        ordered = True

    name = StringOrInt(required=True)
    buckets = fields.List(fields.Nested(FeatureBucketSchema), missing=[])
    CORRESPONDING_YAML_SECTION = 'evaluation.fairness_grouping_features'
    DATACLASS = FairnessGrouping

    @validates_schema
    def is_complete_bucketing_definition(self, data, **kwargs):
        if len(data['buckets']) > 0:
            all_values = set()

            # All buckets should use a consistent constraint type, and exactly one
            # should be unconstrained for max-bounded, and none for explicit subsets
            contains_max_bounded = False
            contains_explicit_subsets = False
            num_unconstrained = 0
            error = None
            for bucket in data['buckets']:
                if bucket.max is not None:
                    contains_max_bounded = True
                elif len(bucket.values) > 0:
                    contains_explicit_subsets = True
                    for v in bucket.values:
                        if v in all_values:
                            error = f"Feature value '{v}' occurs multiple times in the bucket values of feature '{data['name']}'"
                            break
                        all_values.add(v)
                else:
                    num_unconstrained += 1
            if error is None:
                if contains_max_bounded and contains_explicit_subsets:
                    error = "A feature's buckets cannot mix buckets defined by max bounds with buckets defined by explicit value subsets"
                elif contains_max_bounded:
                    if num_unconstrained != 1:
                        error = "Features whose buckets are defined by max bounds must include one bucket without a bound to capture all values above the highest bound"
                elif num_unconstrained != 0:
                    error = "Features whose buckets are defined by explicit subsets must have defined subsets for all buckets"
            if error is not None:
                raise ValidationError({
                    'feature.buckets': error
                })


@dataclass
class PredictionValue(BaseObject):
    SCHEMA_NAME = 'PredictionValueSchema'

    name: str
    value: Any
    favorable: bool = False


class PredictionValueSchema(BaseSchema):
    """Schema for specifying prediction values in scanner input, used as part of evaluation spec"""
    class Meta:
        ordered = True

    name = fields.Str(required=True)
    value = fields.Raw(required=True)
    favorable = fields.Bool(missing=False)
    CORRESPONDING_YAML_SECTION = 'evaluation.prediction_values'
    DATACLASS = PredictionValue


@dataclass
class HyperParameter(BaseObject):
    SCHEMA_NAME = 'HyperParameterSchema'

    name: str
    value: Any


class HyperParameterSchema(BaseSchema):
    """Schema for specifying hyperparameter overrides in scanner input, used as part of evaluation spec"""
    class Meta:
        ordered = True

    name = fields.Str(required=True)
    value = fields.Raw(required=True)
    CORRESPONDING_YAML_SECTION = 'evaluation.hyperparameters'
    DATACLASS = HyperParameter


@dataclass
class Evaluation(BaseObject):
    SCHEMA_NAME = 'EvaluationSchema'

    evaluation_dataset_id: str
    explanation_dataset_id: Optional[str] = None
    test_dataset_id: Optional[str] = None
    evaluation_types: List[str] = field(default_factory=list)
    fairness_metrics: List[str] = field(default_factory=list)
    _primary_fairness_metric: Optional[str] = None
    fairness_grouping_features: List[FairnessGrouping] = field(default_factory=list)
    regression_boundary_type: Optional[str] = None
    regression_boundary: Optional[float] = None
    regression_boundary_percentile: Optional[float] = None
    regression_standard_deviation: Optional[float] = None
    prediction_values: List[PredictionValue] = field(default_factory=list)
    last_favorable_prediction: Optional[Any] = None
    feature_restrictions: List[FeatureRestrictions] = field(default_factory=list)
    hyperparameters: Dict[str, Any] = field(default_factory=dict)
    name: str = ''
    environment: str = ''
    description: str = ''
    prediction_description: Optional[str] = None
    favorable_outcome_value: Optional[str] = None # only for regression
    prediction_favorability: Optional[str] = None
    favorable_outcome_group_name: Optional[str] = None    # only for explicit multiclass
    unfavorable_outcome_group_name: Optional[str] = None  # only for explicit multiclass
    explanation_types: List[str] = field(default_factory=list)
    _primary_explanation_type: Optional[str] = None

    @property
    def primary_fairness_metric(self):
        if self._primary_fairness_metric is None:
            return self.fairness_metrics[0] if len(self.fairness_metrics) > 0 else None
        else:
            return self._primary_fairness_metric

    @primary_fairness_metric.setter
    def primary_fairness_metric(self, value):
        self._primary_fairness_metric = value

    @property
    def primary_explanation_type(self):
        if self._primary_explanation_type is None:
            return self.explanation_types[0] if len(self.explanation_types) > 0 else None
        else:
            return self._primary_explanation_type

    @primary_explanation_type.setter
    def primary_explanation_type(self, value):
        self._primary_explanation_type = value

    @property
    def regression_boundary_type_enum(self) -> RegressionBoundaryTypeEnum:
        if fmap_opt(lambda _: _.lower(),
                    self.regression_boundary_type) == RegressionBoundaryTypeEnum.absolute.name.lower():
            return RegressionBoundaryTypeEnum.absolute
        else:
            return RegressionBoundaryTypeEnum.relative


class EvaluationSchema(BaseSchema):
    @staticmethod
    def interpret_mode(mode: str):
        if mode == 'report':
            return {
                'exclude': ('environment',)
            }
        else:
            return {}

    """Schema for Evaluation specification in the scanner."""
    evaluation_dataset_id = fields.Str(required=True, validate=validate.Regexp(ALPHA_NUMERIC_REGEX, error=ALPHA_NUMERIC_REGEX_ERROR))
    explanation_dataset_id = fields.Str(validate=validate.Regexp(ALPHA_NUMERIC_REGEX, error=ALPHA_NUMERIC_REGEX_ERROR))
    test_dataset_id = fields.Str(validate=validate.Regexp(ALPHA_NUMERIC_REGEX, error=ALPHA_NUMERIC_REGEX_ERROR))
    evaluation_types = fields.List(fields.Str(),
                                   validate=[
                                        validate.ContainsOnly(EVALUATION_TYPES),
                                        validate.Length(min=1)
                                   ],
                                   required=True)

    fairness_grouping_features = fields.List(fields.Nested(FairnessGroupingSchema), missing=[])
    fairness_metrics = fields.List(fields.Str, missing=['burden'])
    primary_fairness_metric = fields.Str()
    regression_boundary_type = fields.Str(missing=None, validate=validate.OneOf(REGRESSION_BOUNDARY_TYPES))
    regression_boundary = fields.Number(missing=None)
    regression_boundary_percentile = fields.Number(missing=None)
    regression_standard_deviation = fields.Number(missing=None)
    prediction_values = fields.List(fields.Nested(PredictionValueSchema), missing=[])
    last_favorable_prediction = fields.Raw(missing=None)
    feature_restrictions = fields.List(fields.Nested(FeatureRestrictionsSchema), missing=[])
    hyperparameters = fields.List(fields.Nested(HyperParameterSchema), missing=[])
    prediction_favorability = fields.Str(validate=validate.OneOf(PREDICTION_TYPES))
    favorable_outcome_value = fields.Str(validate=validate.OneOf(REGRESSION_PREDICTION_VALUES))
    explanation_types = fields.List(fields.Str(), missing=['counterfactual'], validate=[
        validate.ContainsOnly(EXPLANATION_TYPES),
        validate.Length(min=1)
    ])
    primary_explanation_type = fields.Str()
    CORRESPONDING_YAML_SECTION = 'evaluation'
    DATACLASS = Evaluation

    def dataclass_args(self, data: dict) -> dict:
        if 'hyperparameters' in data:
            data['hyperparameters'] = {p.name: p.value for p in data['hyperparameters']}
        return data

    class Meta:
        ordered = True
        additional = ('name', 'environment', 'description', 'prediction_description',
                      'favorable_outcome_group_name', 'unfavorable_outcome_group_name')

    @pre_dump
    def convert_hyperparameters(self, data, **kwargs):
        """Convert hyperparam dict back to list of HyperParameter"""
        result = copy(data)
        result.hyperparameters = [HyperParameter(key, value) for key, value in data.hyperparameters.items()]
        return result

    @validates_schema
    def explanation_dataset_required(self, data, **kwargs):
        """Validates that `explanation dataset_id` is set if an explanation evaluation is going to be run."""
        if 'explanation' in data['evaluation_types'] and 'explanation_dataset_id' not in data:
            error = ['explanation dataset must be specified if an explanation report will be run']
            raise ValidationError({'explanation_dataset_id': error})

    @validates_schema
    def require_grouping_features_for_fairness_report(self, data, **kwargs):
        fairness_grouping_features = data.get('fairness_grouping_features', [])
        performing_fairness_report = 'fairness' in data.get('evaluation_types', [])
        if performing_fairness_report and len(fairness_grouping_features) == 0:
            error = ['fairness grouping features must be specified if a fairness report will be run']
            raise ValidationError({'fairness_grouping_features': error})

    @validates_schema
    def valid_fairness_metrics(self, data, **kwargs):
        fairness_metrics = data.get('fairness_metrics', [])
        primary_fairness_metric = data.get('primary_fairness_metric')
        for m in fairness_metrics:
            if (not is_valid_fairness(m)) and (m.lower() != 'burden'):
                error = [f"fairness metric '{m}' is not supported"]
                raise ValidationError({'fairness_metrics': error})

        if (primary_fairness_metric is not None) and\
           (primary_fairness_metric.lower() not in [m.lower() for m in fairness_metrics]):
            error = [f"metric '{primary_fairness_metric}' is not in the list of specified fairness metrics"]
            raise ValidationError({'primary_fairness_metric': error})

    @validates_schema
    def valid_primary_explanation_types(self, data, **kwargs):
        explanation_types = data.get('explanation_types', [])
        primary_explanation_type = data.get('primary_explanation_type')

        if (primary_explanation_type is not None) and \
            (primary_explanation_type.lower() not in [m.lower() for m in explanation_types]):
            error = [f"Explanation type '{primary_explanation_type}' is not in the list of specified explanation types"]
            raise ValidationError({'primary_explanation_type': error})

    @validates_schema
    def valid_regression_spec(self, data, **kwargs):
        regression_type = data.get('regression_boundary_type')
        regression_boundary = data.get('regression_boundary')
        regression_boundary_percentile = data.get('regression_boundary_percentile')
        regression_standard_deviation = data.get('regression_standard_deviation')

        errors = {}
        if (regression_type is None) or (regression_type == RegressionBoundaryTypeEnum.relative.name):
            if (regression_boundary_percentile is not None):
                errors['regression_boundary_percentile'] = "'regression_boundary_percentile' cannot be used with a 'regression_boundary_type' of 'relative'"
            if (regression_boundary is not None):
                errors['regression_boundary'] = "'regression_boundary' cannot be used with a 'regression_boundary_type' of 'relative'"
        else:
            if regression_standard_deviation is not None:
                errors['regression_standard_deviation'] = "'regression_standard_deviation' cannot be specified with a 'regression_boundary_type' of 'absolute'"
            if (regression_boundary_percentile is not None) and \
               ((regression_boundary_percentile <= 0.) or (regression_boundary_percentile >= 100.)):
                errors['regression_boundary_percentile'] = "'regression_boundary_percentile' must be within the interval (0,100)"
            if (regression_boundary_percentile is None) and (regression_boundary is None):
                errors['regression_boundary_type'] = "One of 'regression_boundary_percentile' or 'regression_boundary' must be specified when using a 'regression_boundary_type' of 'absolute'"
            elif (regression_boundary_percentile is not None) and (regression_boundary is not None):
                errors['regression_boundary_type'] = "Only one of 'regression_boundary_percentile' or 'regression_boundary' can be specified"
        if len(errors) > 0:
            raise ValidationError(errors)

    @post_dump
    def remove_default_metrics(self, data, **kwargs):
        if data.get('fairness_metrics') == ['burden']:
            data.pop('fairness_metrics', None)

        if data.get('fairness_metrics', None) is None:
            data.pop('primary_fairness_metric')

        effective_explanation_types = data.get('explanation_types', [])
        is_default_explanation_type = (list(map(lambda x: x.lower(),
                                                effective_explanation_types)) == ['counterfactual']) or \
                                      len(effective_explanation_types) == 0
        if is_default_explanation_type:
            data.pop('explanation_types', None)
            data.pop('primary_explanation_type')

        return data

# Scoring Schemas

@dataclass
class ExplainabilityScoring(BaseObject):
    SCHEMA_NAME = 'ExplainabilityScoringSchema'

    num_features: int
    value: float


class ExplainabilityScoringSchema(BaseSchema):
    """Schema for explainability scoring section of input - used as part of @ScoringSchema."""
    class Meta:
        ordered = True

    num_features = fields.Int(required=True, strict=True, validate=validate.Range(min=1, max=10)) # scoring goes up to 10 features
    value = fields.Number(validate=validate.Range(0, 100))
    CORRESPONDING_YAML_SECTION = 'scoring.explainability'
    DATACLASS = ExplainabilityScoring

    # default based on engine fields
    from certifai.engine.explainability import ExplainabilityStats
    DEFAULTS = [ExplainabilityScoring(*args.values())
                for args in ExplainabilityStats(ExplainabilityStats.DEFAULT_SCORE_MAPPINGS).score_map]


@dataclass
class ATXComponentScoring(BaseObject):
    SCHEMA_NAME = 'ATXComponentScoringSchema'

    name: str
    value: float


class ATXComponentScoringSchema(BaseSchema):
    """Schema for a atx scoring (e.g. aspect_weights) section of input - used as part of @ScoringSchema."""
    class Meta:
        ordered = True

    name = fields.String(required=True, validate=validate.OneOf(ATX_COMPONENTS))
    value = fields.Number(required=True, validate=validate.Range(min=0.0)) # non-negative
    CORRESPONDING_YAML_SECTION = 'scoring.aspect_weights'
    DATACLASS = ATXComponentScoring

    # defaut scoring values
    DEFAULTS = [ATXComponentScoring(component, 1.0) for component in ATX_COMPONENTS]


@dataclass
class Scoring(BaseObject):
    SCHEMA_NAME = 'ScoringSchema'

    explainability: Optional[List[ExplainabilityScoring]] = None
    aspect_weights: Optional[List[ATXComponentScoring]] = None


class ScoringSchema(BaseSchema):
    """Schema for the scoring section of the input data."""
    class Meta:
        ordered = True

    explainability = fields.List(fields.Nested(ExplainabilityScoringSchema),
                                 validate=validate.Length(min=1))
    aspect_weights = fields.List(fields.Nested(ATXComponentScoringSchema),
                                 validate=validate.Length(min=1))
    CORRESPONDING_YAML_SECTION = 'scoring'
    DATACLASS = Scoring

    def omit(self, data, key, value):
        if ((key == 'aspect_weights') and (value == dump_many(ATXComponentScoringSchema.DEFAULTS))) or \
           ((key == 'explainability') and (value == dump_many(ExplainabilityScoringSchema.DEFAULTS))):
            return True
        else:
            return super().omit(data, key, value)

    @validates_schema
    def unique_scoring_keys(self, data, **kwargs):
        """
        Performs extra validation on the Scoring input data, such as validating that the
        explainability input contains unique keys.
        """
        errors = {}
        atx_weights = data.get('aspect_weights')
        if atx_weights is not None:
            atx_components = list(map(lambda x: x.name, atx_weights))
            if len(set(atx_components)) != len(atx_components):
                errors['aspect_weights'] = ['contains duplicate keys']

        explainability_weights = data.get('explainability')
        if explainability_weights is not None:
            feature_nums = list(map(lambda x: x.num_features, explainability_weights))
            if len(set(feature_nums)) != len(feature_nums):
                errors['explainability'] = ['contains duplicate keys']

        if errors:
            raise ValidationError(errors)

# Overall template schema

@dataclass
class ScanTemplate(BaseObject):
    SCHEMA_NAME = 'ScanTemplateSchema'

    model_use_case: ModelUseCase
    evaluation: Evaluation
    models: List[Model]
    scoring: Scoring
    datasets: List[Dataset]
    dataset_schema: DatasetFeatureSchema
    scan: Scan
    model_headers: ModelHeaders
    model_connectors: List[ModelConnector]


class ScanTemplateSchema(BaseSchema):
    model_use_case      = fields.Nested(ModelUseCaseSchema, required=True)
    evaluation          = fields.Nested(EvaluationSchema, required=True)
    models              = fields.List(fields.Nested(ModelSchema),
                                      validate=validate.Length(min=1),
                                      required=True)
    scoring             = fields.Nested(ScoringSchema,
                                        missing=ScoringSchema().load({}))
    datasets            = fields.List(fields.Nested(DatasetSchema),
                                      missing=[])
    dataset_schema      = fields.Nested(DatasetSchemaSchema,
                                        missing=DatasetSchemaSchema().load({}))
    scan                = fields.Nested(ScanSchema, missing=Scan())
    model_headers       = fields.Nested(ModelHeadersSchema, missing=ModelHeadersSchema().load({}))
    model_connectors    = fields.List(fields.Nested(ModelConnectorSchema),
                                      missing=[])

    CORRESPONDING_YAML_SECTION = '/'
    DATACLASS = ScanTemplate

    def load(self, data, notebook_semantics: bool=False, **kwargs):
        """

        :param notebook_semantics: If True allow load and save of datasets with unspecified sources
                                   and models with unspecified endpoints (which the notebook can
                                   inject local dataframes and models into)
        """
        if notebook_semantics:
            self.context = 'notebook'
        return super().load(data, **kwargs)

    @validates_schema
    def validate_evaluation(self, data, **kwargs):
        if EvaluationTypeEnum.performance in data['evaluation'].evaluation_types and \
           len(data['model_use_case'].performance_metrics) == 0:
            error = ["'performance' listed as evaluation type, but no performance metrics are listed in the mode use case"]
            raise ValidationError({'evaluation': error})

        if (EvaluationTypeEnum.explainability in data['evaluation'].evaluation_types or \
            EvaluationTypeEnum.explanation in data['evaluation'].evaluation_types) and \
           ExplanationTypeEnum.shap in data['evaluation'].explanation_types and \
           data['model_use_case'].task_type != ModelTypeEnum.regression and \
           not all(map(lambda m: m.supports_soft_scoring, data['models'])):
            error = ["'shap' listed as an explanation_type, but usage requires models to support soft scoring for non-regression task types"]
            raise ValidationError({'evaluation': error})

    @post_load
    def fill_out_scan(self, data, **kwargs):
        scan = data['scan']
        evaluation_data = data['evaluation']
        scan.scan_id = generate_uuid(max_len=12)
        scan.name = evaluation_data.name
        scan.environment = evaluation_data.environment  #TODO: should fields copied like this, evaluation -> scan; be documented?
        scan.description = evaluation_data.description
        scan.scanner_version = get_full_version()
        log.details(f"Generated unique scan id: {scan.scan_id}")
        return data

    @validates_schema
    def validate_models(self, data, **kwargs):
        errors = []
        models = data['models']
        model_connectors = data['model_connectors']
        evaluation = data['evaluation']
        use_case = data['model_use_case']

        # Validate we don't have an attempt to use multiple connectors on a single model
        for model in models:
            connector_matched = False
            for mc in model_connectors:
                if model.model_id in mc.model_ids:
                    if connector_matched:
                        errors.append(f"Model id '{model.model_id}' is listed in multiple connectors")
                        break
                    connector_matched = True

        # validate that all defined model metric values are defined by the user-case and
        # that all models provide a value for any metrics that are not
        # calculable by Certifai
        test_set_provided = (evaluation.test_dataset_id is not None)
        unsupported_metrics = frozenset([m.name for m in use_case.performance_metrics if m.metric is None])
        defined_metrics = frozenset([m.name for m in use_case.performance_metrics])
        for model in models:
            unsupported_provision = {m: False for m in defined_metrics}
            for metric in model.performance_metric_values:
                if metric.name not in defined_metrics:
                    errors.append(f"Metric '{metric.name}' on model '{model.name}' is not defined by the model_use_case")
                else:
                    unsupported_provision[metric.name] = True
            for m in defined_metrics:
                if not unsupported_provision[m]:
                    if m in unsupported_metrics:
                        errors.append(f"Model '{model.name}' does not provide a metric value for '{m}'")
                    elif not test_set_provided:
                        errors.append(f"Model '{model.name}' does not provide a metric value for '{m}' which is required in the absence of a test set")
        if len(errors) > 0:
            raise ValidationError({'Model metrics': errors})

    @validates_schema
    def validate_dataset_schema(self, data, **kwargs):
        dataset_schema = data['dataset_schema']
        evaluation = data['evaluation']
        if (evaluation.test_dataset_id is not None) and dataset_schema.outcome_column is None:
            raise ValidationError("'outcome_column' is required because 'test_dataset_id' is specified")


    @validates_schema
    def feature_order_check(self, data, **kwargs):
        """Ensures that json datasets have a value of True for 'defined_feature_order' if the schema does not define it."""
        errors = []
        schema_defines_order = data.get('dataset_schema', DatasetSchemaSchema().load({})).defined_feature_order
        for dataset in data['datasets']:
            if not (dataset.encodes_feature_order or schema_defines_order):
                errors.append(f"Dataset '{dataset.dataset_id}' has a format that does not encode a feature column order.  This cannot be consumed without asserting an order in the 'dataset_schema''")
        if len(errors) > 0:
            raise ValidationError({'Feature ordering': errors})

    @validates_schema
    def model_id_in_headers(self, data, **kwargs):
        """Ensure model_id in model headers is present in models"""
        model_headers = data.get('model_headers')
        model_ids = [model.model_id for model in data['models']]
        if model_headers and model_headers.defined is not None:
            errors = [f'model_id {model.model_id} in model_headers.defined not present in models section of schema'
                      for model in model_headers.defined if model.model_id not in model_ids]
            if errors:
                raise CertifaiValidationException('Model Headers validation failed', errors)

    @post_load
    def check_scoring_weights(self, data, **kwargs):
        scoring = data.get('scoring')
        evaluation = data.get('evaluation')

        # validate the effective weights
        aspect_weights = scoring.aspect_weights or [w for w in ATXComponentScoringSchema.DEFAULTS if w.name in evaluation.evaluation_types]

        # validate ATX weights against evaluation
        for weight in aspect_weights:
            if weight.name not in evaluation.evaluation_types:
                raise CertifaiValidationException(
                    'ATX aspect weights validation failed',
                    ['weights can only be specified for evaluation types in the scan definition'])

        if len(aspect_weights) > 0:
            non_zero_weights = [weight for weight in aspect_weights if weight.value != 0]
            if len(non_zero_weights) == 0:
                raise CertifaiValidationException('ATX aspect weights validation failed',
                                                  ['weights must include at least one non-zero value'])

        return data

    @validates_schema
    def validate_explicit_multiclass_group_names(self, data, **kwargs):
        """
        Validates that the favorable_outcome_group_name & unfavorable_outcome_group_name are required for explicit
        multiclass and not applicable in any other situation.
        """
        task_type = data['model_use_case'].task_type
        evaluation = data['evaluation']
        favorability = evaluation.prediction_favorability
        props = ('favorable_outcome_group_name', 'unfavorable_outcome_group_name')
        errors = []

        is_required = (task_type == ModelTypeEnum.multiclass_classification and favorability == PredictionFavorabilityEnum.explicit)
        for prop in props:
            prop_set = getattr(evaluation, prop) is not None
            if is_required and not prop_set:
                errors.append(f"'{prop}' field is required for {task_type} task type when the prediction favorability is {favorability}")
            elif not is_required and prop_set:
                errors.append(f"'{prop}' field does not apply to {task_type} task type when the prediction favorability is {favorability}")

        if errors:
            raise CertifaiValidationException("evaluation validation failed", errors)

        return data

    @validates_schema
    def validate_prediction_outcomes(self, data, **kwargs):
        use_case = data['model_use_case']
        evaluation = data['evaluation']
        errors = []

        # set default
        if evaluation.prediction_favorability is None:
            evaluation.prediction_favorability = ScanTemplateSchema._default_favorability_format(use_case, evaluation)
            if use_case.task_type != ModelTypeEnum.regression:
                log.warning(f"Missing prediction_favorability field - inferring '{evaluation.prediction_favorability}' based on evaluation information")

        # require a favorable outcome for fairness (limiting favorability to != 'none' is sufficient)
        performing_fairness_report = EvaluationTypeEnum.fairness in evaluation.evaluation_types
        prediction_favorability = evaluation.prediction_favorability
        if performing_fairness_report and prediction_favorability == PredictionFavorabilityEnum.none:
            errors.append("fairness is not a valid evaluation type when prediction_favorability is 'none'")

        # validate predictions & favorability based on task_type
        validator_map = {
            ModelTypeEnum.multiclass_classification: ScanTemplateSchema._validate_classification_outcome,
            ModelTypeEnum.binary_classification: ScanTemplateSchema._validate_classification_outcome, # same as multi-class
            ModelTypeEnum.regression: ScanTemplateSchema._validate_regression_outcome,
        }

        errors.extend(validator_map[use_case.task_type](use_case, evaluation))
        if errors:
            raise CertifaiValidationException("invalid 'evaluation' section", errors)

        return data

    @staticmethod
    def _default_favorability_format(use_case, evaluation):
        if use_case.task_type == ModelTypeEnum.regression:
            has_favorable_outcome = evaluation.favorable_outcome_value is not None
            return PredictionFavorabilityEnum.ordered if has_favorable_outcome else PredictionFavorabilityEnum.none

        # else - classification
        has_favorable_outcome = any(x.favorable for x in evaluation.prediction_values)
        if not has_favorable_outcome:
            log.warning("Cannot distinguish between prediction favorability of 'ordered' and 'none' based on evaluation - assuming 'ordered'")
            return PredictionFavorabilityEnum.ordered
        return PredictionFavorabilityEnum.explicit

    @staticmethod
    def _validate_regression_outcome(use_case, evaluation):
        errors = []
        task_type = use_case.task_type
        favorability = evaluation.prediction_favorability
        has_favorable_outcome = evaluation.favorable_outcome_value is not None

        if favorability not in (PredictionFavorabilityEnum.ordered, PredictionFavorabilityEnum.none):
            errors.append(f"prediction_favorability of '{favorability}' is not supported for {task_type} task_type")
        elif favorability == PredictionFavorabilityEnum.none and has_favorable_outcome:
            errors.append(f"'favorable_outcome_value' is not applicable to {task_type} task_type when prediction_favorability is {favorability}")
        elif favorability == PredictionFavorabilityEnum.ordered and not has_favorable_outcome:
            errors.append(f"'favorable_outcome_value' is required for {task_type} task_type when prediction_favorability is {favorability}")

        if any([m.lower() != 'burden' for m in evaluation.fairness_metrics]):
            errors.append("Fairness metrics other than 'burden' are not supported for regression tasks")

        if len(evaluation.prediction_values) != 0:
            errors.append(f"'prediction_values' are not applicable to {task_type} task_type")
        return errors

    @staticmethod
    def _validate_classification_outcome(use_case, evaluation):
        errors = []
        task_type = use_case.task_type
        favorability = evaluation.prediction_favorability
        has_prediction_values = len(evaluation.prediction_values) > 0
        has_favorable_prediction = any(x.favorable for x in evaluation.prediction_values)

        if favorability == PredictionFavorabilityEnum.none:
            # okay to have prediction_values - but nothing should be favorable
            if has_favorable_prediction:
                errors.append(f"'prediction_values' cannot be specified as favorable for {task_type} task_type when prediction_favorability is {favorability}")

        if favorability == PredictionFavorabilityEnum.ordered:
            # prediction values are ordered from most to least favorable - none should be marked as 'favorable'
            if not has_prediction_values:
                errors.append(f"'prediction_values' are required for {task_type} task_type when prediction_favorability is {favorability}")
            if has_favorable_prediction:
                errors.append(f"'prediction_values' cannot be specified as favorable for {task_type} task_type when prediction_favorability is {favorability}")

        if favorability == PredictionFavorabilityEnum.explicit:
            if not has_prediction_values:
                errors.append(f"'prediction_values' are required for {task_type} task_type when prediction_favorability is {favorability}")
            if not has_favorable_prediction:
                errors.append(f"At least one prediction_value must be specified as favorable for {task_type} task_type when prediction_favorability is {favorability}")

        if evaluation.favorable_outcome_value is not None:
            errors.append(f"'favorable_outcome_value' is not applicable to {task_type} task_type")
        return errors
