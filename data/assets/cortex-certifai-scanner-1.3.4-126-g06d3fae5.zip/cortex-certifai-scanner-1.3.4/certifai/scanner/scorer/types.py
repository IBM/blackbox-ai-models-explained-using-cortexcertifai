from enum import Enum

valid_report_types = ['robustness', 'atx', 'performance', 'fairness', 'explainability', 'explanation']
score_types = ['robustness', 'atx', 'performance', 'fairness', 'explainability', 'feature_fairness']


class ScoreColumn(Enum):
    MODEL_USE_CASE_ID = 'usecase'
    MODEL_USE_CASE_NAME = 'usecase_name'
    DATETIME = 'date'
    SCAN_ID = 'scan'
    MODEL_ID = 'model'
    MODEL_NAME = 'model_name'
    TIME = 'time_in_mins'
    TYPE = 'score_type'
    NAME = 'metric'
    FEATURE = 'feature'
    SCORE = 'score'
    CONFIDENCE_LOWER = 'confidence_lower'
    CONFIDENCE_UPPER = 'confidence_upper'
    IS_PRIMARY = 'is_primary'

    @classmethod
    def order(cls):
        return [
            cls.MODEL_USE_CASE_ID, cls.MODEL_USE_CASE_NAME, cls.DATETIME,
            cls.SCAN_ID, cls.MODEL_ID, cls.MODEL_NAME, cls.TIME, cls.TYPE,
            cls.NAME, cls.FEATURE, cls.SCORE, cls.CONFIDENCE_LOWER, cls.CONFIDENCE_UPPER, cls.IS_PRIMARY
        ]

    def name(self):
        return self.value


COLUMN_ORDER = ScoreColumn.order()
COLUMN_NAMES = list(map(lambda n: n.name(), COLUMN_ORDER))
