import glob
import os
import re
import json
import dateutil
import pandas as pd
from certifai.scanner.scorer.types import (ScoreColumn, COLUMN_NAMES, COLUMN_ORDER,
                                           valid_report_types)
from certifai.scanner.utils import retrieve, retrieve_or
from certifai.common.utils import get_logger
from certifai.common.errors import CertifaiValidationException

log = get_logger()


def list_files(path):
    glob_path = os.path.join(path, "certifai-scan*.json")
    file_list = glob.glob(glob_path)
    file_list.sort(key=os.path.getmtime)
    return file_list


def parse_file_name(path):
    # certifai-scan[-<datetime>]-<scanId>-<reportType>-<modelId>-<datetime>.json
    file_name = os.path.basename(path)
    name_match = re.match(r'^certifai-scan(-\w+)?-(\w+)-(\w+)-(\w+)\.json$', file_name)
    if name_match is not None and name_match[3] in valid_report_types:
        return {
            'scan_id': name_match[2],
            'report_type': name_match[3],
            'model_abbrev': name_match[4], # this isn't necessarily the model id (may be modified)
            'file_path': path
        }
    return None


def parse_file_list(file_list):
    return list(filter(None, map(parse_file_name, file_list)))


def validate_report_entry(report, entry):
    fail_msg = "Report validation failed"
    file_name = os.path.basename(entry['file_path'])
    scan_id = retrieve(report, ['scan', 'scan_id'])
    if scan_id != entry['scan_id']:
        raise CertifaiValidationException(
            fail_msg,
            [f"Scan ID {scan_id} does not match filename {file_name}"])

    status = retrieve_or(report, 'Unknown', 'status')
    if status != 'Completed':
        raise CertifaiValidationException(
            fail_msg,
            [f"Report {file_name} did not complete: {retrieve_or(report, status, 'error')}"])

    report_type = entry['report_type']

    field = report_type
    if report_type == 'performance':
        field = 'performance_metrics'
    if report_type == 'explanation':
        field = 'explanations'

    if retrieve(report, field) is None:
        raise CertifaiValidationException(
            fail_msg,
            [f"Report type {report_type} not found in file {file_name}"])

    return True


# read a report from an entry and make sure it matches
def read_report(entry):
    with open(entry['file_path']) as json_file:
        report = json.load(json_file)
        # check basics match
        validate_report_entry(report, entry)
    return report


def get_common_columns(report):
    started = retrieve_or(report, '', ['scan', 'started'])
    ended = retrieve_or(report, '', ['scan', 'ended'])
    elapsed_mins = 0
    try:
        elapsed = dateutil.parser.parse(ended) - dateutil.parser.parse(started)
        elapsed_mins = round(elapsed.total_seconds()/60, 1)
    except Exception:
        pass

    return {
        ScoreColumn.MODEL_USE_CASE_ID: retrieve_or(report, '', ['model_use_case', 'model_use_case_id']),
        ScoreColumn.MODEL_USE_CASE_NAME: retrieve_or(report, '', ['model_use_case', 'name']),
        ScoreColumn.MODEL_ID: retrieve_or(report, '', ['model', 'model_id']),
        ScoreColumn.MODEL_NAME: retrieve_or(report, '', ['model', 'name']),
        ScoreColumn.SCAN_ID: retrieve_or(report, '', ['scan', 'scan_id']),
        ScoreColumn.DATETIME: retrieve_or(report, '', ['scan', 'ended']),
        ScoreColumn.TIME: elapsed_mins,
        ScoreColumn.IS_PRIMARY: 'true',
    }


def get_feature_fairness_columns(details, is_primary):
    return {
        ScoreColumn.SCORE: details.get('value', ''),
        ScoreColumn.TYPE: 'feature_fairness',
        ScoreColumn.FEATURE: details.get('feature', ''),
        ScoreColumn.CONFIDENCE_LOWER: details.get('value_confidence_95_lower', ''),
        ScoreColumn.CONFIDENCE_UPPER: details.get('value_confidence_95_upper', ''),
        ScoreColumn.IS_PRIMARY: is_primary
    }


# returns array of score rows
def read_scores_from_report(report, entry):
    common_cols = get_common_columns(report)
    if entry['report_type'] == 'atx':
        score_cols = {
            ScoreColumn.SCORE: retrieve_or(report, '', 'atx'),
            ScoreColumn.TYPE: 'atx'
        }
        return [{**common_cols, **score_cols}]
    elif entry['report_type'] == 'robustness':
        robust = retrieve_or(report, {}, ['robustness'])
        score_cols = {
            ScoreColumn.SCORE: robust.get('score', ''),
            ScoreColumn.CONFIDENCE_LOWER: robust.get('score_confidence_95_lower', ''),
            ScoreColumn.CONFIDENCE_UPPER: robust.get('score_confidence_95_upper', ''),
            ScoreColumn.TYPE: 'robustness'
        }
        return [{**common_cols, **score_cols}]
    elif entry['report_type'] == 'explainability':
        score_cols = {
            ScoreColumn.SCORE: retrieve_or(report, '', ['explainability', 'score']),
            ScoreColumn.TYPE: 'explainability',
            ScoreColumn.NAME: ','.join(retrieve_or(report, ['counterfactual'], 'explanation_types'))
        }
        return [{**common_cols, **score_cols}]
    if entry['report_type'] == 'explanation':
        score_cols = {
            ScoreColumn.TYPE: 'explanation',
            ScoreColumn.NAME: ','.join(retrieve_or(report, ['counterfactual'], 'explanation_types'))
        }
        return [{**common_cols, **score_cols}]
    elif entry['report_type'] == 'fairness':
        fair = retrieve_or(report, {}, ['fairness'])
        primary_metric = fair.get('fairness_metric', '')
        score_cols = {
            ScoreColumn.SCORE: fair.get('score', ''),
            ScoreColumn.CONFIDENCE_LOWER: fair.get('score_confidence_95_lower', ''),
            ScoreColumn.CONFIDENCE_UPPER: fair.get('score_confidence_95_upper', ''),
            ScoreColumn.TYPE: 'fairness',
            ScoreColumn.NAME: primary_metric
        }
        rows = [{**common_cols, **score_cols}]
        by_feature = retrieve_or(report, [], ['fairness', 'feature_fairness'])
        for f in by_feature:
            feat_score_cols = get_feature_fairness_columns(f, 'true')
            row = {**common_cols, **feat_score_cols}
            row[ScoreColumn.NAME] = primary_metric
            row.pop(ScoreColumn.TIME)  # time only applies to overall fairness
            rows.append(row)

        secondary_scores = retrieve_or(report, [], ['fairness', 'secondary_scores'])
        for sec in secondary_scores:
            sec_feature_fairness = retrieve_or(sec, [], ['feature_fairness'])
            secondary_metric = sec.get('fairness_metric', '')
            for f in sec_feature_fairness:
                sec_feat_score_cols = get_feature_fairness_columns(f, 'false')
                row = {**common_cols, **sec_feat_score_cols}
                row[ScoreColumn.NAME] = secondary_metric
                row.pop(ScoreColumn.TIME)  
                rows.append(row)
        return rows
    elif entry['report_type'] == 'performance':
        rows = []
        metrics = retrieve_or(report, [], ['performance_metrics'])
        atx_perf_metric = retrieve_or(report, '', ['model_use_case', 'atx_performance_metric_name'])
        for m in metrics:
            p_score_cols = {
                ScoreColumn.SCORE: m.get('score', ''),
                ScoreColumn.TYPE: 'performance',
                ScoreColumn.NAME: m.get('name', '')
            }
            # remove time column from all except atx metric as we only collect overall time
            row = {**common_cols, **p_score_cols}
            if p_score_cols[ScoreColumn.NAME] != atx_perf_metric:
                row.pop(ScoreColumn.TIME)
            rows.append(row)
        return rows

    return []


def row_to_array(row):
    return list(map(lambda c: row.get(c, ''), COLUMN_ORDER))


# read reports and returns csv rows
def entries_to_csv(entries):
    data = []
    for entry in entries:
        try:
            report = read_report(entry)
            rows = read_scores_from_report(report, entry)
            array_rows = list(map(lambda r: row_to_array(r), rows))
            data.extend(array_rows)
        except CertifaiValidationException as cve:
            log.exception(str(cve))
        except Exception as e:
            log.exception(f"Unable to read report {entry['file_path']}: {str(e)}")

    df = pd.DataFrame.from_records(data, columns=COLUMN_NAMES)
    return df.to_csv(index=False)


def read_scores_as_csv(path):
    files = list_files(path)
    entries = parse_file_list(files)
    return entries_to_csv(entries)
