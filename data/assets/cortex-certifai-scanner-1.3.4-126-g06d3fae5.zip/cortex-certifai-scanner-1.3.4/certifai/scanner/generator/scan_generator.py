"""
Module for generating scan definitions
"""
import yaml
from typing import Tuple
from certifai.common.features import data_type_from_engine_feature_type
from certifai.common.helpers import enum_values
from certifai.common.types import EvaluationTypeEnum, FeatureTypeEnum
from certifai.common.utils.file_utils import resolve_filepath
from certifai.scanner.schemas import DatasetSchema, DatasetFeatureSchemaSchema, DatasetSchemaDef
from certifai.scanner.certifai_scan import create_dataset, create_features
from certifai.scanner.generator.template_utils import TemplateUtils


## Default Values

DEFAULT_TEMPLATE_FILE = 'default_template.yaml.jinja'
DEFAULT_EMPTY_VALUE = "\'FILL_ME\'"
DEFAULT_TASK_TYPE = 'binary-classification'
DEFAULT_MODEL_USE_CASE_ID = "\'CHANGE_ME\'"
DEFAULT_EVALUATION_TYPES = enum_values(EvaluationTypeEnum)
DEFAULT_EVALUATION_TYPES.remove(EvaluationTypeEnum.explanation.value)  # ignore explanation

DEFAULT_CSV_DATASET = {
    'dataset_id': 'eval',
    'url': 'FILL_ME',
    'file_type': 'csv',
    'has_header': True
}

DEFAULT_JSON_DATASET = {
    'dataset_id': 'eval',
    'url': 'FILL_ME',
    'file_type': 'json',
    'orient': 'records',
    'lines': True,
    'defined_feature_order': True,
}

DEFAULT_DATASET_SCHEMA = {
    'outcome_column': DEFAULT_EMPTY_VALUE,
    'feature_schemas': []
}

DEFAULT_ARGS = {
    'task_type': DEFAULT_TASK_TYPE,
    'model_use_case_id': DEFAULT_MODEL_USE_CASE_ID,
    'evaluation_types': DEFAULT_EVALUATION_TYPES,
    'default_empty_value': DEFAULT_EMPTY_VALUE,
    'dataset_schema': DEFAULT_DATASET_SCHEMA,
    'datasets': [DEFAULT_CSV_DATASET], # default to csv
}

# Allow pyyaml to represent OrderedDict data - preserving order in yaml
# sort_keys=False <- not used in yaml.safe_dump for backward compatibility
# More: https://stackoverflow.com/a/31609484/47551 ; https://stackoverflow.com/a/8661021
def represent_dict_order(self, data):
    return self.represent_mapping('tag:yaml.org,2002:map', data.items())

yaml.SafeDumper.add_representer(dict, represent_dict_order)


def convert_features_to_scanner_input_format(features: dict) -> dict:
    """
    Converts the engine representation of a feature schema to the corresponding scanner input
    representation.
    """
    feature_schema = []
    for feature in features:
        feature_schema_item = {
            'feature_name': feature['name'],
            'data_type': data_type_from_engine_feature_type(feature['type']).value,
        }

        if FeatureTypeEnum.is_categorical(feature['type']):
            feature_schema_item['category_values'] = feature['category_values']
        else: # numeric
            feature_schema_item['min'] = feature['min']
            feature_schema_item['max'] = feature['max']
            feature_schema_item['spread'] = feature['spread']

        feature_schema.append(feature_schema_item)
    return feature_schema


def generate_scan_definition(model_use_case_id, task_type, dataset_def, output_location) -> str:
    """Generates a scan definition from the provided information
        Return is a human readable summary string containing
        information that should be noted
    """
    # deserialize data - generate full definition
    dataset = generate_dataset(dataset_def, output_location)
    feature_schemas, summary = generate_feature_schemas(dataset)

    # serialize to yaml
    datasets_yaml = serialize_dataset_to_yaml(dataset)
    feature_schemas_yaml = serialize_feature_schemas_to_yaml(feature_schemas)

    # create template
    template_args = create_template_args(model_use_case_id, task_type, datasets_yaml,
                                         feature_schemas_yaml)
    write_scan_definition(DEFAULT_TEMPLATE_FILE, template_args, output_location)

    return summary



def generate_dataset(dataset_def: dict, scandef_path: str) -> dict:
    """Generates a full dataset representation from the starter definition."""
    # validate input
    dataset_input_schema = DatasetSchema()
    dataset = dataset_input_schema.load(dataset_def)
    dataset.defined_feature_order = False # features will be inferred - no feature order to apply

    # fill out dataset data - passing empty dict for dataset_schema to not apply changes
    base_path = resolve_filepath(scandef_path, '.', is_file=True)
    dataset = create_dataset(dataset, DatasetSchemaDef(), base_path)
    dataset.defined_feature_order = (dataset.file_type == 'json' and dataset.orient != 'columns')
    return dataset


def generate_feature_schemas(dataset: dict) -> Tuple[dict, str]:
    """
    Generates a full dataset_schema definition (with inferred feature_schemas), from the
    starter definition.
    Return is a tuple of the definition, and a human readable summary string containing
    information that should be noted
    """
    # infer dataset features
    features = create_features([dataset], [])
    feature_schemas_list = convert_features_to_scanner_input_format(features)

    # Create summary string for noting heuristically inferred features
    summary = ''
    inferred_cat = [f['name'] for f in features if f.get('heuristically_inferred', False) and f['type'] == FeatureTypeEnum.CAT]
    inferred_int = [f['name'] for f in features if f.get('heuristically_inferred', False) and f['type'] == FeatureTypeEnum.INT]
    if len(inferred_cat) > 0:
        summary += "The following integer-valued features were inferred to be categoricals:\n"
        for f in inferred_cat:
            summary += f"\t{f}\n"
    if len(inferred_int) > 0:
        summary += "The following integer-valued features were inferred to be numeric:\n"
        for f in inferred_int:
            summary += f"\t{f}\n"
    feature_schema_schema = DatasetFeatureSchemaSchema()
    feature_schemas = [feature_schema_schema.load(f) for f in feature_schemas_list]
    return feature_schemas, summary


def serialize_dataset_to_yaml(dataset: dict) -> str:
    """Converts the dataset data to yaml."""
    dataset_input_schema = DatasetSchema()
    datasets = [dataset_input_schema.dump(dataset)]
    return yaml.safe_dump(datasets, default_flow_style=False) # sort_keys=False (done @ representer)


def serialize_feature_schemas_to_yaml(feature_schemas: dict) -> str:
    """Converts the dataset_schema data to yaml."""
    feature_schemas_input_schema = DatasetFeatureSchemaSchema(many=True)
    feature_schemas = feature_schemas_input_schema.dump(feature_schemas) # remove extra keys
    return yaml.safe_dump(feature_schemas, default_flow_style=False) # sort_keys=False (done @ representer)


def create_template_args(model_use_case_id: str, task_type: str, datasets: str, feature_schemas: str) -> dict:
    """Creates the template arguments based on default values and input params."""
    template_args = DEFAULT_ARGS.copy()
    template_args.update({
        'model_use_case_id': model_use_case_id,
        'task_type': task_type,
        'datasets': datasets.strip(),
        'feature_schemas': feature_schemas.replace('\n', '\n  ').strip()
    })
    return template_args


def write_scan_definition(template_file: str, args: dict, output: str):
    """Renders specified template and writes it to the output location."""
    templating = TemplateUtils()
    templating.render_and_save_template(template_file, args, output)
