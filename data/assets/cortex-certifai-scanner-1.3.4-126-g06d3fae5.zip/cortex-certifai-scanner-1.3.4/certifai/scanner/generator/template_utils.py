"""
Utility class for interacting with templates in the certifai package.
"""
from jinja2 import Environment, PackageLoader
from certifai.common.file.locaters import make_generic_locater


class TemplateUtils():
    def __init__(self, templates_dir='templates'):
        self.templates_dir = templates_dir
        self.env = Environment(loader=PackageLoader('certifai.scanner.generator', templates_dir))

    def load_template(self, filename):
        return self.env.get_template(filename)

    def render_template(self, filename, args):
        template = self.load_template(filename)
        return template.render(**args)

    def render_and_save_template(self, filename, args, output_dest):
        contents = self.render_template(filename, args)
        with make_generic_locater(output_dest).text_writer() as f:
            f.write(contents)
