"""
Classes and utilities for writing scan report files
"""
import os
import json
import yaml
from typing import Dict, Optional, Any, Tuple

from certifai.engine.utils.numpy_json_encoder import NumpyJSONEncoder

from certifai.common.utils import get_logger
from certifai.common.utils.utils import get_iso8601_date, to_filename_safe_chars
from certifai.common.utils.name_utils import (NameCreator, CompositeResolver, ShorteningResolver,
                                              IncrementalUUIDResolver, CollisionResolutionException)
from certifai.common.utils.file_utils import resolve_filepath
from certifai.common.file.locaters import make_generic_locater, local_filesystem_type, locater_to_path
from certifai.common.file.interface import FilePath, FSLocater
from certifai.common.report_writer import ReportWriter

from certifai.scanner.types import ScanContext
from certifai.scanner.utils import create_directory_if_not_exists

log = get_logger()

USECASE_YAML_FILENAME = 'usecase.yaml'
SCAN_RESULTS_DIRECTORY_ENV_VAR = 'SCAN_RESULTS_DIRECTORY'


class NullReportWriter(ReportWriter):
    """Null object that implements the ReportWriter interface but does NOT actually write to file."""
    def write_report(self, report: dict):
        report['reports_written'] = False

    @property
    def report_location(self) -> Optional[str]:
        return None

class ScanReportWriter(ReportWriter):
    """Class for writing scan reports"""

    def __init__(self,
                 scan_context: ScanContext,
                 base_path: str,
                 output_location: Optional[str] = None,
                 write_usecase: bool = True,
                 omit_filename_date: bool = False,
                 filename_date: Optional[str] = None):
        """

        :param scan_context: context of the scan
        :param base_path: base path to interpret the resulting report location w.r.t (if it is a relative path)
        :param output_location: optional output path that overrides the content of the scan_context. Default None
        :param omit_filename_date: whether to omit the date section in report filenames. Default False
        :param filename_date: optional date string to be used in report filenames. If not specified a datetime
               will be generated when before writing files. Default None
        :param write_usecase: whether to write the model use case file, default True
        """
        self._context = scan_context
        self._write_usecase = write_usecase
        self._omit_filename_date = omit_filename_date
        self._date_ts = filename_date

        self._is_directory_setup = False
        self._resolver = NameCreator(CompositeResolver([ShorteningResolver(10), IncrementalUUIDResolver(10, 5)]))

        base_report_path, full_report_path = resolve_report_location(self._context, base_path, output_location)
        self._base_locater = make_generic_locater(base_report_path)
        self._output_locater = make_generic_locater(full_report_path)

    @property
    def report_location(self):
        """Location where reports will be written to - includes the model use case folder"""
        # Return just the locater name for local files - avoiding `local://` protocol prefix for local files
        if self._output_locater.filesystem.type_name == local_filesystem_type:
            return self._output_locater.name
        return locater_to_path(self._output_locater)

    @property
    def report_base_location(self):
        """Base location where reports are being written - excludes model use case folder"""
        # Return just the locater name for local files - avoiding `local://` protocol prefix for local files
        if self._base_locater.filesystem.type_name == local_filesystem_type:
            return self._base_locater.name
        return locater_to_path(self._base_locater)

    def write_report(self, report: dict):
        if not self._is_directory_setup:
            self._setup_directory()

        report['reports_written'] = True
        report['reports_location'] = self.report_location
        report['reports_base_location'] = self.report_base_location
        try:
            filename = self.report_filename(report)
            log.info(f"Writing {filename} to {self._output_locater.name}")
            write_to_file(report, self._output_locater.join(filename))
        except (IOError, CollisionResolutionException) as e:
            log.error(f"Failed to write {filename}: {str(e)}")

    def report_filename(self, report: dict):
        """Creates a unique filename where the given report should be written to."""
        eval_type = report.get('scan', {}).get('evaluation_type', 'NO_SCAN_TYPE')
        model_id = report.get('model', {}).get('model_id', 'NO_MODEL_ID')
        scan_id = self._context.scan.scan_id
        if self._omit_filename_date:
            partial_filename = f"certifai-scan-{scan_id}-{eval_type}-{model_id}"
        else:
            partial_filename = f"certifai-scan-{self._date_ts}-{scan_id}-{eval_type}-{model_id}"
        filename = to_filename_safe_chars(partial_filename, keep_chars=('-', '_'), max_len=80)

        # resolve possible filename collisions based on model_id
        return self._resolver.create(filename, 80) + '.json'

    def _setup_directory(self):
        create_directory_if_not_exists(self._output_locater)
        if self._date_ts is None:
            self._date_ts = get_iso8601_date(replace=[(':', ''), ('-', '')])  # remove dashes to allow dash between tokens

        if self._write_usecase:
            self._write_usecase_file()
        self._is_directory_setup = True

    def _write_usecase_file(self):
        try:
            model_use_case_obj = self._context.use_case
            # Creating use case meta-data
            use_case_obj = {
                'model_use_case': model_use_case_obj.dump(),
                'created': self._date_ts
            }
            log.info(f"Writing '{USECASE_YAML_FILENAME}' for '{model_use_case_obj.model_use_case_id}'")
            write_to_file(use_case_obj, self._output_locater.join(FilePath(USECASE_YAML_FILENAME)), 'yaml')
        except Exception as e:
            log.error(f"Failed to write {USECASE_YAML_FILENAME}: {str(e)}")


def write_to_file(data: dict, file_locater: FSLocater, file_format: str = 'json'):
    """Writes result to file."""
    fp_open_fn = file_locater.text_writer
    with fp_open_fn() as outfile:
        if file_format == 'json':
            json.dump(data, outfile, ensure_ascii=False, indent=4, sort_keys=False, cls=NumpyJSONEncoder)
        else:
            yaml.safe_dump(data, outfile, default_flow_style=False)


def filename_safe_muc_id(model_use_case_id: str, max_len=50) -> str:
    """Returns a copy of the given model_use_case_id string with filename safe characters"""
    return to_filename_safe_chars(model_use_case_id, max_len=max_len)


def resolve_report_location(scan_context: ScanContext,
                            base_path: str,
                            output_override: Optional[str] = None) -> Tuple[str, str]:
    """
    Finds the location w.r.t to the given base path that scan reports should be written to.
    A tuple will be returned containing the base report location (without the model use case
    folder) and the full report path (including the modle use case directory).

    The precedence for finding the output location is:
     1. output_override
     2. SCAN_RESULTS_DIRECTORY_ENV_VAR
     3. scan_context.scan.output.path
     4. default of ./reports

    :param scan_context: context of the scan
    :param base_path: base path that the output location should be interpreted with respect to
    :param output_override: optional override for the report location
    :return: a tuple containing the base report location and the report location including the model
    use case directory
    """
    output_path_unresolved = output_override or \
                             os.environ.get(SCAN_RESULTS_DIRECTORY_ENV_VAR) or \
                             scan_context.scan.output.path or \
                             os.path.join('.', 'reports')
    report_location = resolve_filepath(base_path, output_path_unresolved)
    report_location_with_muc_id = resolve_filepath(report_location,
            filename_safe_muc_id(scan_context.use_case.model_use_case_id))
    return report_location, report_location_with_muc_id
