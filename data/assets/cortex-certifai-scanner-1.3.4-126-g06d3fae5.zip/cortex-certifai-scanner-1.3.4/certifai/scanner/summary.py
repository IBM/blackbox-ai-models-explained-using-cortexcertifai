"""
Data objects for summarizing the results of a scan.
"""
from typing import NamedTuple, Optional, Dict, Callable, List

class ScanSummary(NamedTuple):
    """Object for summarizing the results of a scan"""
    num_failed_reports: int
    num_completed_reports: int
    reports_location: Optional[str] = None
    reports_base_location: Optional[str] = None
    error: Optional[str] = None

    @property
    def num_total_reports(self) -> int:
        return self.num_failed_reports + self.num_completed_reports

    @property
    def reports_written(self) -> bool:
        return self.reports_location is not None

    def print(self, output_fn: Callable[[str], None] = print):
        """
        Prints a formatted version of the summary objects content.
        :param Callable[[Any], None] output_fn: Optional function to send string output to. If not
             specified, builtins.print will be used
        """
        overall_result = f"Scan Failed\n{self.error}" if self.error else "Scan Completed"
        output_fn(overall_result)
        if self.num_total_reports > 0:
            output_fn("\n====== Report Summary ======")
            output_fn(f"Total number of evaluations performed: {self.num_total_reports}")
            output_fn(f"Number of successful reports: {self.num_completed_reports}")
            output_fn(f"Number of failed reports: {self.num_failed_reports}")
            if self.reports_written:
                output_fn(f"Reports written to: {self.reports_location}")
                output_fn(f"Reports base folder: {self.reports_base_location}")
        else:
            output_fn('No reports generated')

    @staticmethod
    def from_report_dictionary(reports_dict: Dict[str, Dict[str, dict]], error: Optional[str] = None) -> 'ScanSummary':
        """
        Constructs a ScanSummary from the given dictionary of reports.
        :param Dict[str, Dict[str, dict]] reports_dict: dictionary of scan reports (eval_type -> model_id -> report)
        :param Optional[str] error: optional string error message if an error occured while running the scan.
        :return ScanSummary: returns a ScanSummary object
        """
        num_failed_reports = 0
        num_completed_reports = 0
        reports_location = None
        reports_base_location = None
        for _, model_reports in reports_dict.items():
            if not isinstance(model_reports, dict):
                continue

            for _, report in model_reports.items():
                if report.get('status') == 'Completed':
                    num_completed_reports += 1
                else:
                    num_failed_reports += 1

                if report.get('reports_written'):
                    reports_location = report.get('reports_location')
                    reports_base_location = report.get('reports_base_location')


        if error is None and num_failed_reports > 0:
            error = "Report(s) in scan failed"

        return ScanSummary(num_failed_reports,
                           num_completed_reports,
                           reports_location,
                           reports_base_location,
                           error)


class PreflightSummary(NamedTuple):
    """Object for summarizing the results of a preflight scan"""
    preflight_dict: dict
    error: Optional[str] = None

    # 'observations' is synonymous with 'messages' in the PreflightResult object
    @property
    def total_num_observations(self) -> int:
        return sum(len(res['messages']) for _, res in self.preflight_dict.items())

    @property
    def total_num_warnings(self) -> int:
        return sum(len(res['warnings']) for _, res in self.preflight_dict.items())

    @property
    def total_num_errors(self) -> int:
        return sum(len(res['errors']) for _, res in self.preflight_dict.items())

    @property
    def total(self) -> int:
        return self.total_num_observations + \
               self.total_num_warnings + \
               self.total_num_errors

    def num_results_for_model(self, model_id: str) -> int:
        """Returns the number of results (messages + warnings + errors) produced for the given model"""
        return sum(len(res) for _, res in self.preflight_dict.get(model_id, {}).items())

    def print(self, output_fn: Callable[[str], None] = print):
        """
        Prints a formatted version of the summary object.
        :param Callable[[Any], None] output_fn: Optional function to send string output to. If not
             specified, builtins.print will be used
        """
        overall_result = f"Preflight Scan Failed\n{self.error}" if self.error else "Preflight Scan Completed"
        output_fn(overall_result)

        if self.total > 0:
            output_fn("\n====== Preflight Summary ======")
            output_fn(f"Total number of results: {self.total}")
            output_fn(f"Number of observations: {self.total_num_observations}")
            output_fn(f"Number of warnings: {self.total_num_warnings}")
            output_fn(f"Number of errors: {self.total_num_errors}")
            output_fn('\n')

            for model_id, result in self.preflight_dict.items():
                if self.num_results_for_model(model_id) == 0:
                    output_fn(f"No results produced for model {model_id}")
                else:
                    def _print_indented(msgs):
                        for s in msgs:
                            output_fn('  ' + s)

                    if len(result['messages']) > 0:
                        output_fn(f"Observations for {model_id} model:")
                        _print_indented(result['messages'])
                        output_fn('')

                    if len(result['warnings']) > 0:
                        output_fn(f"Warnings for {model_id} model:")
                        _print_indented(result['warnings'])
                        output_fn('')

                    if len(result['errors']) > 0:
                        output_fn(f"Errors for {model_id} model:")
                        _print_indented(result['errors'])
                        output_fn('')
        else:
            output_fn('No results produced')


    @staticmethod
    def from_preflight_dictionary(preflight_dict: Dict[str, Dict[str, List[str]]], error: Optional[str] = None) -> 'PreflightSummary':
        """
        Constructs a PreflightSummary from the given dictionary of results.
        :param Dict[str, Dict[str, List[str]]] preflight_dict: dictionary of preflight results
        :param Optional[str] error: optional string error message if an error occured while running the preflight scan
        :return PreflightSummary: returns a PreflightSummary object
        """
        return PreflightSummary(preflight_dict, error)
