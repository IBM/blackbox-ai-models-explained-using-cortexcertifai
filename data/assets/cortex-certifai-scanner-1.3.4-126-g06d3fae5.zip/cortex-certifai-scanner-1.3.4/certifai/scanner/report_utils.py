from typing import NamedTuple, Optional, Iterable, List, Generator, Any, Callable
import pandas as pd

from collections import Counter

from certifai.common.utils.fn_utils import fmap_opt


class _ScoreSource(NamedTuple):
    """Source metadata from which a score derives

    :param context: optional string providing a titular context for names
    :param name: Optional literal specification for the name of the score (overridden by name_source if present)
    :param name_source: Optional element name from which to take the score name (see below)
    :param type_source: Optional element name from which to take a score type name
    :param value_source: Optional element name from which to take the score value
    :param confidence_source: Optional element name prefix from which to take 95% confidence values
    :param path: Element path to traverse from current to reach the score/name values
    :param children: list of child score specifiers for hierarchically nested scores

    *Notes*

    the `path` list traverses dictionary keys in the nested report structure.  Lists encountered automatically
    generate scores for each element encountered.  The special values `..` and `..!` both pop from the
    path (move upward in the nested report structure), with the `..!` variant pushing the current node onto a
    context stack, for use in source resolution (see below)

    The `value_source` and `name_source` fields define dictionary keys (with respect to the context reached via
    `path`) to provide the score name and value from.  Special values '.' and '*', and strings of the form
    `<target_key>=<source_key>` are supported with the following meanings:

        `.` indicates that the current resolved context from the `path` *is* the value
        `*` is valid *only* in `name_source` and is defined when the current context is a dictionary.  The result
            is one score for each element of the dictionary with the name being the key value and the value generating
            context being the item value
        `<target_key>=<source_key>` is valid *only* whe the current context is a list of dictionaries and asserts
            that the element of the list to be selected is the one in which <target_key> has the value that
            <source_key> has on the element popped from the top of the context stack.  This allows joining
            of data which does not have a hierarchical nature in the report structure on a key to manifest it in
            a hierarchical structure in the resulting score tree (used for detailed fairness to place it under
            the corresponding parent feature fairness)
    """
    context: Optional[str]
    name: Optional[str]
    name_source: Optional[str]
    type_source: Optional[str]
    value_source: Optional[str]
    confidence_source: Optional[str]
    path: List[str]
    children: Iterable['ScoreSource']


# Static representation of where to gather scores from in the report dictionaries

# Source for individual fairness bucket burden values
_burden_score_source = _ScoreSource('Group details',
                                    None,
                                    'label',
                                    None,
                                    'value',
                                    'value',
                                    ['..!', '..', 'detailed_fairness', 'feature=feature', 'groups'],
                                    [])

# Source for individual feature fairness values
_feature_fairness_score_source = _ScoreSource('Feature',
                                              None,
                                              'feature',
                                              None,
                                              'value',
                                              'value',
                                              ['feature_fairness'],
                                              [_burden_score_source])

# Fairness score node source
_fairness_source = _ScoreSource(None,
                                'overall fairness',
                                None,
                                "fairness_metric",
                                'score',
                                'score',
                                ['fairness'],
                                [_feature_fairness_score_source])

# Source for fairness secondary scores
_secondary_fairness_source = _ScoreSource(None,
                                          'overall fairness',
                                           None,
                                          "fairness_metric",
                                          'score',
                                          'score',
                                          ['fairness', 'secondary_scores'],
                                          [_feature_fairness_score_source])

# Source for ATX component score values
_atx_component_source = _ScoreSource(None,
                                     None,
                                     '*',
                                     None,
                                     '.',
                                     None,
                                     ['component_scores'],
                                     [])

# Source for explainability feature count component values
_explainability_component_source = _ScoreSource('Num features',
                                                None,
                                                'num_features',
                                                None,
                                                'percentage',
                                                None,
                                                ['histogram'],
                                                [])

# Mapping from evaluation type to generated score sources
_score_sources = {
    'fairness': [_fairness_source, _secondary_fairness_source],
    'robustness': [_ScoreSource(None,
                                'robustness',
                                None,
                                None,
                                'score',
                                'score',
                                ['robustness'],
                                [])],
    'atx': [_ScoreSource(None,
                         'ATX',
                         None,
                         None,
                         'atx',
                         None,
                         [],
                         [_atx_component_source])],
    'explainability': [_ScoreSource(None,
                                    'explainability',
                                    None,
                                    None,
                                    'score',
                                    None,
                                    ['explainability'],
                                    [_explainability_component_source])]
}


class ConfidenceBounds(NamedTuple):
    """Confidence bounds for a value

    :param low: Lower confidence bound
    :param high: Upper confidence bound
    :param confidence_percent: Percentage confidence of the bound
    """
    low: float
    high: float
    confidence_percent: int


class Score(NamedTuple):
    """Score element
    :param value: The score value
    :param confidence_bounds: The optional confidence bounds
    :param context: Optional titular context of the score
    :param name: Name of the score
    :param children: Nested child scores
    """
    value: Optional[float]
    confidence_bounds: Optional[ConfidenceBounds]
    context: Optional[str]
    name: str
    type_name: Optional[str]
    children: Iterable['Score']


def _nodes_of(d: Any, path, ancestors=[], sources=[]) -> Generator[Any, None, None]:
    """Generate the context nodes for score sources from a starting context
    given a relative path

    :param d: Context to start from (node in the nested report structure)
    :param path: Relative path to traverse
    :param ancestors: Ancestor nodes of `d`
    :param sources: Context stack pushed by `!` suffix on previously traversed paths
    :return: generator of nodes in the report structure
    """
    component = path[0] if len(path) > 0 else None
    if (component is not None) and component.startswith('..'):
        if len(ancestors) == 0:
            raise ValueError(f"Bad source path '{path}' at node {d}")
        if component == '..!':
            if not isinstance(d, dict):
                raise ValueError(f"Invalid source for component '{component} in path '{path}'")
            sources = sources + [d]
        yield from _nodes_of(ancestors[-1], path[1:], ancestors=ancestors[:-1], sources=sources)
    elif isinstance(d, list):
        if (component is not None) and component.startswith('..'):
            if len(ancestors) == 0:
                raise ValueError(f"Bad source path '{path}' at node {d}")
            if component == '..!':
                if not isinstance(d, dict):
                    raise ValueError(f"Invalid source for component '{component} in path '{path}'")
                sources = sources + [d]
            yield from _nodes_of(ancestors[-1], path[1:], ancestors=ancestors[:-1], sources=sources)
        elif (component is not None) and ('=' in component):
            if len(sources) == 0:
                raise ValueError(f"Bad source path '{path}'")
            if not isinstance(d, list):
                raise ValueError(f"Bad source path '{path}' at non-list node {d}")
            keys = component.split('=')
            if len(keys) != 2:
                raise ValueError(f"Bad path component '{component}'")
            for child in d:
                if (not isinstance(child, dict)) or (keys[1] not in child):
                    raise ValueError(f"Badly report dictionary, missing {keys[1]}")
                if keys[0] not in sources[-1]:
                    raise ValueError(f"Bad source path anchor {path}'")
                if child[keys[1]] == sources[-1][keys[0]]:
                    yield from _nodes_of(child, path[1:], ancestors=ancestors + [d], sources=sources[:-1])
        else:
            for child in d:
                yield from _nodes_of(child, path, ancestors=ancestors + [d], sources=sources)
    elif len(path) == 0:
        yield d, ancestors
    elif (not isinstance(d, dict)) or (path[0] not in d):
        pass
    else:
        yield from _nodes_of(d[path[0]], path[1:], ancestors=ancestors + [d], sources=sources)


def _extract_from(d: Any,
                  key: str,
                  path,
                  key_map: Optional[Callable[[str],str]]=None,
                  allow_missing:bool=False) -> Optional[Any]:
    """Extract value from a context given a key

    :param d: context to extract from
    :param key: key to extract
    :param key_map: optional lambda to apply to keys before using
    :param allow_missing: If `True` will cause `None` to be returned if the key is not present (else raise)
    :return: Extracted value (or `None` if not found and `allow_missing`)
    """
    if key is not None:
        if key_map is not None:
            key = key_map(key)
        if key == '.':
            extracted = d
        elif isinstance(d, dict) and (key in d):
            extracted = d[key]
        elif not allow_missing:
            raise ValueError(f'Badly formed report dictionary, missing {key} in {d} @ {path}')
        else:
            extracted = None
    else:
        extracted = None
    return extracted


def _materialize_scores(source: _ScoreSource,
                        data: Any,
                        title: Optional[str]=None,
                        max_depth: int=0,
                        root_ancestry: List[Any]=[],
                        depth: int=0) -> Generator[Score, None, None]:
    """Generate scores from provided report context and source

    :param source: source metadata for the root score
    :param data: report root context (node in nested report structure)
    :param title: optional asserted contextual title to use
    :param root_ancestry: ancestors in the report structure of `source` that may require upward traversal
    :return: generator of `Score` instances
    """
    for score_node, ancestors in _nodes_of(data, source.path, ancestors=root_ancestry):
        def score_from(node, name=None):
            children = []
            conf_low = _extract_from(node, source.value_source, source.path, lambda k: k + '_confidence_95_lower', allow_missing=True)
            conf_high = _extract_from(node, source.value_source, source.path, lambda k: k + '_confidence_95_upper', allow_missing=True)
            score = _extract_from(node, source.value_source, source.path)
            type_name = _extract_from(node, source.type_source, source.path)
            if name is None:
                if source.name_source is not None:
                    name = fmap_opt(str, node.get(source.name_source))
                if name is None:
                    name = source.name or '<Unknown>'

            if max_depth != 0:
                for child in source.children:
                    children.extend(_materialize_scores(child,
                                                        node,
                                                        root_ancestry=ancestors,
                                                        max_depth=max_depth,
                                                        depth=depth+1))

            if (conf_low is not None) and (conf_high is not None):
                confidence = ConfidenceBounds(conf_low, conf_high, 95)
            else:
                confidence = None

            children.sort(key=lambda s: s.name)
            return Score(score, confidence, title or source.context, name, type_name, children)

        if (score_node is not None) and ((not isinstance(score_node, dict)) or len(score_node) != 0):
            if source.name_source == '*':
                if not isinstance(score_node, dict):
                    raise ValueError(f"Invalid wildcard name source - required dictionary at {score_node}")
                for key, value in score_node.items():
                    yield score_from(value, name=key)
            else:
                yield score_from(score_node)
        else:
            pass


def _flatten_score(score,
                   include_confidence: bool=True,
                   include_score_type: bool=True,
                   include_context: bool=True):
    acc = []
    if include_context:
        acc.append(score.context)
    if include_score_type and score.type_name is not None:
        acc.append(score.type_name)
    if score.value is not None:
        acc.append(score.value)
    if include_confidence and (score.confidence_bounds is not None):
        acc.append(score.confidence_bounds.low)
        acc.append(score.confidence_bounds.high)
    for child in score.children:
        acc.extend(_flatten_score(child, include_confidence=include_confidence, include_context=False))
    return acc


def _flatten_score_names(score,
                         omit_root_context=True,
                         include_confidence: bool=True,
                         include_score_type: bool=True,
                         include_context: bool=True):
    def recurse(score,
                omit_root_context,
                include_score_type: bool,
                include_context: bool,
                parent: Optional[str]):
        acc = []
        if include_context:
            acc.append(('context', parent))
        if include_score_type and score.type_name is not None:
            acc.append(('type', parent))
        name = score.name if (omit_root_context or score.context is None) else f"{score.context} ({score.name})"
        if score.value is not None:
            acc.append((name, parent))
        if include_confidence and (score.confidence_bounds is not None):
            acc.append((name + ' lower bound', parent))
            acc.append((name + ' upper bound', parent))
        for child in score.children:
            acc.extend(recurse(child,
                               False,
                               True,
                               False,
                               name))
        return acc

    raw_results = recurse(score, omit_root_context, include_score_type, include_context, [])

    # It is possible that we wound up with duplicate names when flattening, so handle that
    # by post-processing and adding disambiguation where needed (only)
    # Note - to be completely general here we'd need to apply this recursively so that ambiguous
    # nested sub-trees could be fully disambiguated, but since the problem can only occur at leaf
    # nodes (detailed fairness groups specifically) we do not need complete generality here
    result = []
    all_raw_names = Counter([r[0] for r in raw_results])
    for name, parent in raw_results:
        if all_raw_names[name] > 1:
            if parent is None:
                raise ValueError('Illegal scoring structure whose names cannot be disambiguated')
            result.append(f"{name} in {parent}")
        else:
            result.append(name)
    return result


def scores(evaluation_type: str,
           report: dict,
           max_depth: int=-1) -> Generator[Score, None, None]:
    """Generate scores for a given evaluation type from a report dictionary

    :param evaluation_type: one of 'robustness', 'fairness', 'explainability', 'atx'
    :param report: report dictionary
    :param depth: nesting depth to include sub-scores to (default all)
    :return: generator of `Score` instances
    """
    if (evaluation_type in report) and (evaluation_type in _score_sources):
        for model, info in report[evaluation_type].items():
            for source in _score_sources[evaluation_type]:
                yield from _materialize_scores(source,
                                               info,
                                               title=model,
                                               max_depth=max_depth)
    else:
        yield


def construct_scores_dataframe(scores: Iterable[Score],
                               index_by_root_context: bool=True,
                               include_confidence: bool=True,
                               include_score_type: bool=True,
                               include_context: bool=True,
                               type_match: Optional[str]=None):
    """Construct a Pandas DataFrame with scoring information from a list of `Score`

    :param scores: list of scores to extract information from
    :param index_by_root_context: If True index the dataframe by the contexts of the top level scores (default True)
    :param include_confidence: If True include confidence intervals for scores where available (default True)
    :param type_match: Optional top-level Score type to filter by.  Use to ensure a homogeneous type is selected from a
                 list of scores of many types, such as different fairness measures
    :return: dataframe
    """
    all_scores = [s for s in scores if (type_match is None) or\
                                       ((s.type_name is not None) and (type_match.lower() in s.type_name.lower()))]
    if len(all_scores) == 0:
        columns = []
    else:
        columns = _flatten_score_names(all_scores[0],
                                       index_by_root_context,
                                       include_confidence=include_confidence,
                                       include_score_type=include_score_type,
                                       include_context=include_context)

    flattened = []
    for s in all_scores:
        f_s = _flatten_score(s,
                             include_confidence=include_confidence,
                             include_score_type=include_score_type,
                             include_context=include_context)
        if len(f_s) != len(columns):
            raise ValueError("The set of scores provided must be of a homogeneous type (try using a type_match value to filter)")
        flattened.append(f_s)

    def index_name(score):
        return score.context if score.type_name is None else f"{score.context} ({score.type_name})"
    index = [index_name(s) for s in all_scores] if index_by_root_context else range(len(all_scores))

    return pd.DataFrame(flattened,
                        columns=columns,
                        index=index)
