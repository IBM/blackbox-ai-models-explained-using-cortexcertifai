# CERTIFAI Scanner
**Counterfactual Explanations for Robustness, Transparency, Interpretability, and Fairness of Artificial Intelligence models**

This package contains python modules for the Certifai Scanner. It relies on the [certifai_engine](../certifai_engine/README.md) and [certifai_common](../certifai_common/README.md) packages.

This repository is using [pkgutil-style namespace packges](https://packaging.python.org/guides/packaging-namespace-packages/#pkgutil-style-namespace-packages),
under the `certifai` namespace. Example usage would be:

```
from certifai.scanner.schemas import ModelSchema

model_schema = ModelSchema()
...
```

## Certifai Scanner CLI
The CLI components of the scanner and other utils has been moved from this package to [Certifai Client](../certifai_client/README.md).
This package contains the underlying functionality that is used by the Certifai Client CLI, but the CLI is exposed via
Certifai Client.

However, the example usecases can still be found in this package at `certifai/scanner/usecases`

## Development

You can rely on the provided `Makefile` during development. For descriptions of make targets use: `make help`.

### Installation

`make install`

This will build the package and install `certifai-common`, `certifai-engine`, and `certifai-scanner`, in the `c12e-certifai` conda environment.
If you have already built the package (using `make setup_build_space && make build`), you can instead run `make install_only`.

### Tests

- `make test_recreate` : reserved for running tests in pipeline. Uses `artifacts/packages/` dir to fetch already built `cortex-certifai-reference-model-server-package`
during pipeline builds and runs the scanner tox tests against it  

- `make test_local_recreate` : clones the `CognitiveScale/certifai-reference-models` git repo locally,
re-trains all the models, builds `cortex-certifai-reference-model-server-package` and runs the scanner tox tests against- (fully rebuilds the tox environment)
  > first time users need to run the above command


- `make test_local` :  uses the already built `cortex-certifai-reference-model-server-package` (from above) and runs scanner tox tests against it

- `make test` : alias for `make test_local`

Certain tests rely on example scanner output fixtures (located in `test/unit/scanner/scanner_reports`). When an update is
made to the expected output to the scanner reports (schema change, engine updates, etc.) the reports can be rebuilt via:
`CREATE_REPORTS=1 tox`.

This will recreate and save the report fixtures, then result in a test failure.

