# CERTIFAI Engine
**Counterfactual Explanations for Robustness, Transparency, Interpretability, and Fairness of Artificial Intelligence models**

This repository contains the source code for an application that implements the Certifai research. It relies on the [cortex-certifai-common](../certifai_common/README.md) package.

This repository is using [pkgutil-style namespace packges](https://packaging.python.org/guides/packaging-namespace-packages/#pkgutil-style-namespace-packages),
under the `certifai` namespace.

## Development

You can rely on the provided `Makefile` during development. For descriptions of make targets use: `make help`.

## Installation

`make install`

This will build and install the `cortex-certifai-engine` and `cortex-certifai-common` packages in the `c12e-certifai` conda environment.
If you have already built this package (using `make setup_build_space && make build`), you can instead run `make install_only`.

This requires an up to date version of conda (tested with `4.7.11`).  To ensure you have an updated
conda instllation run the command: `conda update -n base conda`

__Note__: First time run requires build/update conda environment:
`conda env update -f ../environment.yml && conda activate c12e-certifai`

## Obfuscation & Building Cythonized

By default the `cortex-certifai-engine` package will be obfuscated via [PyAmor](https://pyarmor.readthedocs.io/en/latest/)
when running: `make build` or `make install`. However, the package can manually be built either Cythonized or with no obfuscation.

Obfuscate with PyArmor (default):
```
make obfuscate
```
For more details on PyArmor, see the [PyArmor wiki page](../../../wiki/Obfuscation-with-PyArmor).

To build the cythonized engine package:
```
make setup_build_space
make build_cython
```

To build the unobfuscated package:
```
make setup_build_space
make build_dev
```

**Disclaimer: Do not distribute the unobfuscated source**

**Note**: The two above commands will build the package under `build/dist/`, but will NOT install the package or its dependency `cortex-certifai-common` in your conda environment.

## Custom License
See the [Wiki page](../../../wiki/Certifai-Custom-License).

## Tests

`make test`          # uses tox, pytest and more

`make test_recreate` # uses tox, pytest, and more - fully rebuilds the tox environment

New model tests can be added and automatically done when fixtures is included with file name format: `counterfactual-<model>-in.json`

Recreate test fixtures:
`CREATE_FIXTURES=1 tox`

To run a single unit test:

```
pytest test/unit/app_api_test.py
```

## Uninstall / Remove
`pip uninstall cortex-certifai-engine`
`pip uninstall cortex-certifai-common`
`$(dirname $(which python))/pip uninstall certifai-engine`
`$(dirname $(which python))/pip uninstall certifai-common`

## Tutorial

All tutorials are under `../other/tutorials/` [here](../other/tutorials).

Links to notebooks:
* [certifai_tutorial_diabetes.ipynb](../other/tutorials/diabetes/certifai_tutorial_diabetes.ipynb)
* [german_credit.ipynb](../other/tutorials/german_credit/certifai_tutorial_germancredit.ipynb)
* [certifai_tutorial_auto_insurance.ipynb](../other/tutorials/auto_insurance/certifai_tutorial_auto_insurance.ipynb)

## Models

Models are exposed using the [model_server](model_server). Refer to the README in the model_server directory for more info.

Previously: Models were loaded from a python `pickle` file.
