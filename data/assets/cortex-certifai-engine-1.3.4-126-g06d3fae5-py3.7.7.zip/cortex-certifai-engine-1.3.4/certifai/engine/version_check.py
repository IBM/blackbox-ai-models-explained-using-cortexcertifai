"""
Checks that the Python runtime version matches the expected version set 
during builds.
Exit on mismatch.
"""

import sys

def ver_tup2str(tup):
    return ".".join([str(t) for t in tup])

def ver_str2tup(s):
    return tuple([int(v) for v in s.split('.')])

def discard_micro_version(version_tuple):
    major, minor, _micro = (list(version_tuple) + [0,0])[:3]
    return (major, minor)

build_version = ver_str2tup('3.7.7')
runtime_version = (sys.version_info.major, sys.version_info.minor, sys.version_info.micro)

# discard micro version
build_version = discard_micro_version(build_version)
runtime_version = discard_micro_version(runtime_version)

if runtime_version != build_version:
    print(f"Python runtime version: '{ver_tup2str(runtime_version)}' "
          f"doesn't match required build version: '{ver_tup2str(build_version)}'")
    sys.exit(-1)
