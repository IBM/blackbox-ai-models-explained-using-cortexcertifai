"""
Copyright 2019 Cognitive Scale, Inc. All Rights Reserved.

See LICENSE.txt for details.

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
"""

from setuptools import find_packages
from setuptools import setup

__version__ = '1.3.4'

setup(name='cortex-certifai-engine',
      description="Python SDK for the CognitiveScale Certifai AI Auditor",
      long_description="Python SDK for CognitiveScale Certifai AI Auditor",
      version=__version__,
      author='CognitiveScale',
      author_email='info@cognitivescale.com',
      url='https://www.cognitivescale.com/',
      license='LICENSE.txt',
      platforms=['linux', 'osx', 'windows'],
      packages=find_packages(exclude=["test"]),
      include_package_data=True,
      exclude_package_data={'': ['tests', 'model_server', 'cortex', 'archived', 'other']},
      install_requires=[
                        'numpy>=1.16.2,<1.19',
                        'pandas>=0.23.4,<=1.0.3',
                        'scikit-learn>=0.20.3,<0.24',
                        'scipy>=1.1.0,<2.0',
                        'toolz>=0.10.0,<1.0',
                        'rsa>=4.0,<5.0',
                        'cuid>=0.3,<0.4',
                        'pyyaml>=3.13,<6.0',
                        'shap>=0.31.0;platform_system=="Darwin"'
      ],
      extras_require={
      },

      tests_require=['pytest-cov==2.7.1',
                     'pytest==4.6.4',
                     'pytest-mock==1.12.1',
                     'hypothesis==5.5.0', # needed for common testutils
                     'tox==3.14.0',
                     ],

      classifiers=[
          'Operating System :: MacOS :: MacOS X',
          'Operating System :: POSIX',
          'Programming Language :: Python :: 3.6',
          'Operating System :: Microsoft :: Windows :: Windows 10',
      ],

      entry_points={
          'console_scripts': []
      }
      )
